import 'package:flutter/material.dart';

/// Represents a user's theme preference.
enum ThemePreference {
  system,
  light,
  dark,
  amoled;

  ThemeMode get themeMode => switch (this) {
        ThemePreference.system => ThemeMode.system,
        ThemePreference.light => ThemeMode.light,
        ThemePreference.dark => ThemeMode.dark,
        ThemePreference.amoled => ThemeMode.dark, // AMOLED uses dark mode base
      };

  String get label => switch (this) {
        ThemePreference.system => 'Ikuti sistem',
        ThemePreference.light => 'Terang',
        ThemePreference.dark => 'Gelap',
        ThemePreference.amoled => 'Hitam AMOLED',
      };

  String get description => switch (this) {
        ThemePreference.system => 'Otomatis terang atau gelap mengikuti pengaturan HP',
        ThemePreference.light => 'Latar putih, nyaman dipakai siang hari',
        ThemePreference.dark => 'Latar gelap, lebih nyaman di mata saat malam',
        ThemePreference.amoled => 'Hitam pekat, hemat baterai di layar OLED/AMOLED',
      };
}
