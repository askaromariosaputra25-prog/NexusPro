import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../core/audio/voice.dart';
import '../../../../core/routing/route_names.dart';
import '../../../onboarding/presentation/screens/permission_setup_screen.dart';

/// Loading screen shown on every cold start: glowing logo, the NEXUSPRO name,
/// a progress bar with loading messages, and an AI voice saying the name.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  static const Duration _total = Duration(milliseconds: 4200);
  static const List<String> _messages = <String>[
    'Menyiapkan mesin optimasi...',
    'Memeriksa perangkat...',
    'Memuat Game Mode...',
    'Hampir siap...',
  ];

  late final AnimationController _progress = AnimationController(vsync: this, duration: _total);
  late final AnimationController _pulse =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat(reverse: true);
  late final AnimationController _intro =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1100));

  Timer? _voiceTimer;
  bool _left = false;

  @override
  void initState() {
    super.initState();
    _intro.forward();
    _progress.forward().whenComplete(_leave);
    // The voice says the name as soon as the loading screen is on screen
    // (first frame drawn), in step with the logo appearing.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _voiceTimer = Timer(const Duration(milliseconds: 150), () {
        Voice.speak('Nexus Pro', lang: 'en', rate: 0.8, pitch: 0.75);
      });
    });
  }

  Future<void> _leave() async {
    if (_left || !mounted) return;
    _left = true;
    // First run: ask for every permission before the app opens.
    var done = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      done = prefs.getBool(PermissionSetupScreen.doneKey) ?? false;
    } catch (_) {
      done = true;
    }
    if (!mounted) return;
    context.go(done ? RouteNames.home : RouteNames.permissionSetup);
  }

  @override
  void dispose() {
    _voiceTimer?.cancel();
    _progress.dispose();
    _pulse.dispose();
    _intro.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const Color blue = Color(0xFF1E88E5);
    const Color cyan = Color(0xFF00E5FF);

    return Scaffold(
      backgroundColor: const Color(0xFF05080F),
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onDoubleTap: _leave, // double tap to skip
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Soft glow behind the logo.
            AnimatedBuilder(
              animation: _pulse,
              builder: (context, _) {
                final glow = 0.25 + 0.2 * _pulse.value;
                return DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: const Alignment(0, -0.25),
                      radius: 0.9,
                      colors: [blue.withOpacity(glow), const Color(0xFF05080F)],
                    ),
                  ),
                );
              },
            ),
            SafeArea(
              child: Column(
                children: [
                  const Spacer(flex: 3),
                  AnimatedBuilder(
                    animation: Listenable.merge([_intro, _pulse]),
                    builder: (context, _) {
                      final t = Curves.easeOutBack.transform(_intro.value.clamp(0.0, 1.0));
                      final ring = _pulse.value;
                      return Opacity(
                        opacity: _intro.value.clamp(0.0, 1.0),
                        child: Transform.scale(
                          scale: 0.6 + 0.4 * t,
                          child: SizedBox(
                            width: 190,
                            height: 190,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Container(
                                  width: 150 + 40 * ring,
                                  height: 150 + 40 * ring,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: cyan.withOpacity(0.5 * (1 - ring)),
                                      width: 2,
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 128,
                                  height: 128,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color: blue.withOpacity(0.7),
                                        blurRadius: 36,
                                        spreadRadius: 2,
                                      ),
                                    ],
                                  ),
                                  child: ClipOval(
                                    child: Image.asset(
                                      'assets/images/nexus_logo.png',
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => const Icon(
                                        Icons.bolt_rounded,
                                        color: Colors.white,
                                        size: 72,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 28),
                  AnimatedBuilder(
                    animation: _intro,
                    builder: (context, _) {
                      final v = Curves.easeOut.transform(((_intro.value - 0.3) / 0.7).clamp(0.0, 1.0));
                      return Opacity(
                        opacity: v,
                        child: Transform.translate(
                          offset: Offset(0, 14 * (1 - v)),
                          child: Column(
                            children: [
                              ShaderMask(
                                shaderCallback: (rect) => const LinearGradient(
                                  colors: [Colors.white, cyan],
                                ).createShader(rect),
                                child: const Text(
                                  'NEXUSPRO',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 38,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 8,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 6),
                              const Text(
                                'GAMING OPTIMIZATION',
                                style: TextStyle(
                                  color: Color(0xFF8FA3BF),
                                  fontSize: 12,
                                  letterSpacing: 4,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  const Spacer(flex: 3),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40),
                    child: AnimatedBuilder(
                      animation: _progress,
                      builder: (context, _) {
                        final p = _progress.value;
                        final idx = math.min(_messages.length - 1, (p * _messages.length).floor());
                        return Column(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: LinearProgressIndicator(
                                value: p,
                                minHeight: 6,
                                backgroundColor: const Color(0xFF16202E),
                                valueColor: const AlwaysStoppedAnimation<Color>(cyan),
                              ),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  _messages[idx],
                                  style: const TextStyle(color: Color(0xFF8FA3BF), fontSize: 12),
                                ),
                                Text(
                                  '${(p * 100).round()}%',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'by AskaaBeelGaad',
                    style: TextStyle(color: Color(0xFF55657D), fontSize: 11, letterSpacing: 1.5),
                  ),
                  const SizedBox(height: 22),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
