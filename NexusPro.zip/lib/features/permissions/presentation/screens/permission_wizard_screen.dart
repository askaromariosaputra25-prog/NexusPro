import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/audio/voice.dart';
import '../../../../core/routing/route_names.dart';
import '../../../tools/data/system_tools_bridge.dart';

class _Step {
  const _Step(this.key, this.icon, this.title, this.why, this.target);

  final String key;
  final IconData icon;
  final String title;
  final String why;
  final String target;
}

/// Shown after the loading screen when permissions are missing. One button walks the user
/// through every permission, one system page at a time, and comes back automatically.
class PermissionWizardScreen extends StatefulWidget {
  const PermissionWizardScreen({super.key});

  /// Permissions needed for everything to work (Game Mode bubble, auto start, system tweaks).
  static const List<String> required = <String>[
    'notifications',
    'overlay',
    'usageAccess',
    'accessibility',
    'writeSettings',
    'dnd',
    'battery',
  ];

  static bool hasMissing(Map<String, bool> perms) => required.any((k) => perms[k] != true);

  @override
  State<PermissionWizardScreen> createState() => _PermissionWizardScreenState();
}

class _PermissionWizardScreenState extends State<PermissionWizardScreen>
    with WidgetsBindingObserver {
  static const List<_Step> _steps = <_Step>[
    _Step('notifications', Icons.notifications_active_outlined, 'Notifikasi',
        'Menampilkan status Game Mode dan tombol "Ini game".', 'notifications'),
    _Step('overlay', Icons.layers_outlined, 'Tampil di atas aplikasi lain',
        'Wajib agar bubble NexusPro muncul di dalam game.', 'overlay'),
    _Step('usageAccess', Icons.query_stats_rounded, 'Akses penggunaan aplikasi',
        'Mengetahui game yang sedang dibuka (cadangan deteksi).', 'usageAccess'),
    _Step('accessibility', Icons.sensors_rounded, 'Pendeteksi game (Aksesibilitas)',
        'Bubble menyala otomatis saat game dibuka, plus tombol screenshot. Cari "NexusPro Game Detector".',
        'accessibility'),
    _Step('writeSettings', Icons.settings_applications_outlined, 'Ubah pengaturan sistem',
        'Untuk kecerahan, rotasi, dan Pengaturan Cepat.', 'writeSettings'),
    _Step('dnd', Icons.do_not_disturb_on_outlined, 'Jangan ganggu (DND)',
        'Blokir notifikasi saat main game.', 'dnd'),
    _Step('battery', Icons.battery_charging_full_rounded, 'Abaikan optimasi baterai',
        'Supaya HP tidak mematikan bubble di latar belakang.', 'battery'),
  ];

  final SystemToolsBridge _bridge = const SystemToolsBridge();

  Map<String, bool> _perms = <String, bool>{};
  bool _loading = true;
  bool _auto = false;
  String? _opened;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
    Voice.speak(
      'Sebelum mulai, izinkan beberapa akses supaya semua fitur Nexus Pro bekerja penuh. '
      'Tekan tombol Izinkan semua, lalu aktifkan satu per satu.',
    );
  }

  @override
  void dispose() {
    Voice.stop();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _onResumed();
  }

  Future<void> _refresh() async {
    final perms = await _bridge.getPermissions();
    if (!mounted) return;
    setState(() {
      _perms = perms;
      _loading = false;
    });
  }

  Future<void> _onResumed() async {
    await _refresh();
    if (!mounted || !_auto) return;
    final opened = _opened;
    if (opened != null && _perms[opened] != true) {
      // Came back without turning it on: stop the automatic walk.
      setState(() => _auto = false);
      _snack('Belum aktif. Ketuk "Izinkan" lagi, atau lewati dulu.');
      return;
    }
    _next();
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  _Step? _firstMissing() {
    for (final s in _steps) {
      if (_perms[s.key] != true) return s;
    }
    return null;
  }

  Future<void> _next() async {
    final step = _firstMissing();
    if (step == null) {
      setState(() => _auto = false);
      Voice.speak('Semua izin sudah aktif. Nexus Pro siap digunakan.');
      return;
    }
    _opened = step.key;
    final ok = await _bridge.open(step.target);
    if (!ok) {
      _snack('Halaman "${step.title}" tidak bisa dibuka di HP ini.');
      setState(() => _auto = false);
    }
  }

  Future<void> _startAuto() async {
    setState(() => _auto = true);
    await _next();
  }

  Future<void> _openOne(_Step step) async {
    _opened = step.key;
    final ok = await _bridge.open(step.target);
    if (!ok) _snack('Halaman "${step.title}" tidak bisa dibuka di HP ini.');
  }

  void _enter() => context.go(RouteNames.home);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final granted = _steps.where((s) => _perms[s.key] == true).length;
    final all = _steps.every((s) => _perms[s.key] == true);

    return Scaffold(
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
                      children: [
                        Row(
                          children: [
                            ClipOval(
                              child: Image.asset(
                                'assets/images/nexus_logo.png',
                                width: 56,
                                height: 56,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) =>
                                    const Icon(Icons.bolt_rounded, size: 40),
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Izinkan semua akses',
                                    style: theme.textTheme.titleLarge
                                        ?.copyWith(fontWeight: FontWeight.w800),
                                  ),
                                  Text(
                                    'Supaya bubble dan semua fitur NexusPro bekerja penuh.',
                                    style: theme.textTheme.bodySmall,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(
                            value: granted / _steps.length,
                            minHeight: 8,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text('$granted dari ${_steps.length} izin aktif',
                            style: theme.textTheme.labelMedium),
                        const SizedBox(height: 12),
                        for (final s in _steps) _tile(theme, s),
                        const SizedBox(height: 8),
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Text(
                              'Opsional tapi sangat disarankan: install Shizuku untuk FPS, CPU, dan GPU asli di bubble. '
                              'Setelah itu buka Tools > Pusat Izin. Di Oppo/Xiaomi/Vivo, nyalakan juga "Mulai otomatis" '
                              'untuk NexusPro.',
                              style: theme.textTheme.bodySmall,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                    child: Column(
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed: all ? _enter : _startAuto,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              child: Text(all ? 'Masuk ke NexusPro' : 'Izinkan semua'),
                            ),
                          ),
                        ),
                        if (!all)
                          TextButton(onPressed: _enter, child: const Text('Lewati dulu')),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _tile(ThemeData theme, _Step s) {
    final ok = _perms[s.key] == true;
    return Card(
      child: ListTile(
        leading: Icon(s.icon, color: theme.colorScheme.primary),
        title: Text(s.title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(s.why),
        trailing: ok
            ? const Icon(Icons.check_circle_rounded, color: Colors.green)
            : FilledButton.tonal(onPressed: () => _openOne(s), child: const Text('Izinkan')),
      ),
    );
  }
}
