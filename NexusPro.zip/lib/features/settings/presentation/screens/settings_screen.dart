import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/ads/ad_providers.dart';
import '../../../../core/routing/route_names.dart';
import '../../../../core/theme/tokens/app_radius.dart';
import '../../../../core/theme/tokens/app_sizes.dart';
import '../../../../core/theme/tokens/app_spacing.dart';
import '../../../../core/services/nexuspro_notification_service.dart';
import '../../../../domain/entities/app_settings.dart';
import '../../../../domain/entities/theme_preference.dart';
import '../../../onboarding/presentation/tour/feature_tour.dart';
import '../../../../shared/widgets/app_shell.dart';
import '../../../../shared/widgets/app_bars/nexuspro_app_bar.dart';
import '../../../../shared/widgets/indicators/nexuspro_status_badge.dart';
import '../../../../shared/widgets/section_header.dart';
import '../../../../shared/widgets/settings/nexuspro_settings_tile.dart';
import '../providers/app_settings_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final settingsAsync = ref.watch(appSettingsProvider);
    final settings = settingsAsync.valueOrNull ?? const AppSettings();

    return Scaffold(
      appBar: const NexusProAppBar(
        title: 'Settings',
        subtitle: 'Atur tampilan, notifikasi, dan data aplikasi',
      ),
      body: ListView(
        padding: EdgeInsets.only(bottom: AppShell.bottomInset(context)),
        children: [
          // Panduan singkat
          Padding(
            padding: const EdgeInsets.fromLTRB(
                AppSpacing.md, AppSpacing.sm, AppSpacing.md, 0),
            child: Card(
              color: theme.colorScheme.primaryContainer.withAlpha(70),
              child: Padding(
                padding: AppSpacing.cardPadding,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Icon(Icons.lightbulb_outline_rounded,
                          color: theme.colorScheme.primary, size: AppSizes.iconMd),
                      const SizedBox(width: AppSpacing.sm),
                      Expanded(
                        child: Text('Bingung? Ini isi halaman ini',
                            style: theme.textTheme.titleSmall
                                ?.copyWith(fontWeight: FontWeight.w700)),
                      ),
                    ]),
                    const SizedBox(height: AppSpacing.sm),
                    const _PrivacyPoint(
                      icon: Icons.palette_outlined,
                      text: 'Tampilan: ganti tema terang, gelap, atau hitam AMOLED.',
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    const _PrivacyPoint(
                      icon: Icons.notifications_outlined,
                      text: 'Notifikasi dan Pemantauan: atur pemberitahuan dan seberapa sering aplikasi membaca suhu, RAM, dan CPU.',
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    const _PrivacyPoint(
                      icon: Icons.tune_outlined,
                      text: 'Perilaku Optimasi dan Tes Jaringan: atur apa yang terjadi saat optimasi dan tes jaringan dimulai.',
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    const _PrivacyPoint(
                      icon: Icons.lock_outline,
                      text: 'Privasi, Keamanan, dan Kelola Data: info data kamu, reset pengaturan, serta ekspor dan hapus data.',
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    const _PrivacyPoint(
                      icon: Icons.handyman_outlined,
                      text: 'Game Mode, Tes Ping, Tes Touch, dan lainnya ada di tab Tools.',
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.sm),

          // Appearance
          const SectionHeader(
            title: 'Tampilan',
            subtitle: 'Pilih tema aplikasi: terang, gelap, atau hitam AMOLED.',
            icon: Icons.palette_outlined,
          ),
          Padding(
            padding: AppSpacing.screenPadding,
            child: Card(
              child: Column(
                children: ThemePreference.values
                    .asMap()
                    .entries
                    .map((entry) => RadioListTile<ThemePreference>(
                          value: entry.value,
                          groupValue: settings.theme,
                          title: Text(
                            entry.value.label,
                            style:
                                theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            entry.value.description,
                            style: theme.textTheme.bodySmall
                                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                          ),
                          secondary: _IconBox(
                            icon: _iconForTheme(entry.value),
                            isActive: entry.value == settings.theme,
                          ),
                          activeColor: theme.colorScheme.primary,
                          onChanged: (v) {
                            if (v != null) {
                              ref
                                  .read(appSettingsProvider.notifier)
                                  .update((s) => s.copyWith(theme: v));
                            }
                          },
                          shape: const RoundedRectangleBorder(borderRadius: AppRadius.radiusMd),
                        ))
                    .toList(),
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),

          // Language
          const SectionHeader(
            title: 'Bahasa',
            subtitle: 'Pilihan bahasa disiapkan untuk update berikutnya. Saat ini teks aplikasi belum berubah mengikuti pilihan ini.',
            icon: Icons.language_outlined,
          ),
          Padding(
            padding: AppSpacing.screenPadding,
            child: Card(
              child: Column(
                children: LanguagePreference.values
                    .asMap()
                    .entries
                    .map((entry) => RadioListTile<LanguagePreference>(
                          value: entry.value,
                          groupValue: settings.language,
                          title: Text(entry.value.label,
                              style: theme.textTheme.bodyMedium
                                  ?.copyWith(fontWeight: FontWeight.w600)),
                          activeColor: theme.colorScheme.primary,
                          onChanged: (v) {
                            if (v != null) {
                              ref
                                  .read(appSettingsProvider.notifier)
                                  .update((s) => s.copyWith(language: v));
                            }
                          },
                          shape: const RoundedRectangleBorder(borderRadius: AppRadius.radiusMd),
                        ))
                    .toList(),
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),

          // Notifications
          const SectionHeader(
            title: 'Notifikasi',
            subtitle: 'Atur banner dan pemberitahuan di dalam aplikasi.',
            icon: Icons.notifications_outlined,
          ),
          Padding(
            padding: AppSpacing.screenPadding,
            child: Card(
              child: Column(
                children: [
                  SwitchListTile(
                    value: settings.notificationsEnabled,
                    onChanged: (v) => ref
                        .read(appSettingsProvider.notifier)
                        .update((s) => s.copyWith(notificationsEnabled: v)),
                    title: const Text('Notifikasi dalam aplikasi',
                        style: TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: const Text(
                        'Tampilkan banner saat optimasi atau tes selesai'),
                    secondary:
                        const _IconBox(icon: Icons.notifications_active_outlined, isActive: true),
                    activeColor: Theme.of(context).colorScheme.primary,
                    shape: const RoundedRectangleBorder(borderRadius: AppRadius.radiusMd),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const _IconBox(
                      icon: Icons.notification_add_outlined,
                      isActive: false,
                    ),
                    title: const Text(
                      'Coba notifikasi',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    subtitle: const Text(
                      'Kirim contoh notifikasi sekarang untuk mengecek notifikasi berfungsi',
                    ),
                    trailing: const Icon(Icons.send_rounded, size: 20),
                    onTap: () async {
                      await ref.read(notificationServiceProvider).showOptimizationReminder(
                            title: 'Pengingat NexusPro',
                            body:
                                'RAM terpakai di atas 75%. Jalankan optimasi cepat sebelum main game.',
                          );
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                                'Notifikasi tes terkirim! Cek di panel notifikasi HP kamu.'),
                            behavior: SnackBarBehavior.floating,
                          ),
                        );
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),

          // Optimization Behaviour
          const SectionHeader(
            title: 'Perilaku Optimasi Bawaan',
            subtitle: 'Apa yang terjadi saat kamu memulai optimasi.',
            icon: Icons.tune_outlined,
          ),
          Padding(
            padding: AppSpacing.screenPadding,
            child: Card(
              child: Column(
                children: DefaultOptimizationBehaviour.values
                    .asMap()
                    .entries
                    .map((entry) => RadioListTile<DefaultOptimizationBehaviour>(
                          value: entry.value,
                          groupValue: settings.defaultOptimizationBehaviour,
                          title: Text(entry.value.label,
                              style: theme.textTheme.bodyMedium
                                  ?.copyWith(fontWeight: FontWeight.w600)),
                          subtitle: Text(entry.value.description,
                              style: theme.textTheme.bodySmall
                                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                          activeColor: theme.colorScheme.primary,
                          onChanged: (v) {
                            if (v != null) {
                              ref
                                  .read(appSettingsProvider.notifier)
                                  .update((s) => s.copyWith(defaultOptimizationBehaviour: v));
                            }
                          },
                          shape: const RoundedRectangleBorder(borderRadius: AppRadius.radiusMd),
                        ))
                    .toList(),
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),

          // Performance Monitoring
          const SectionHeader(
            title: 'Pemantauan Performa',
            subtitle: 'Seberapa sering aplikasi membaca suhu, RAM, dan CPU di latar belakang. Makin sering, makin boros baterai.',
            icon: Icons.monitor_heart_outlined,
          ),
          Padding(
            padding: AppSpacing.screenPadding,
            child: Card(
              child: Column(
                children: PerformanceMonitoringMode.values
                    .asMap()
                    .entries
                    .map((entry) => RadioListTile<PerformanceMonitoringMode>(
                          value: entry.value,
                          groupValue: settings.performanceMonitoringMode,
                          title: Text(entry.value.label,
                              style: theme.textTheme.bodyMedium
                                  ?.copyWith(fontWeight: FontWeight.w600)),
                          subtitle: Text(entry.value.description,
                              style: theme.textTheme.bodySmall
                                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                          activeColor: theme.colorScheme.primary,
                          onChanged: (v) {
                            if (v != null) {
                              ref
                                  .read(appSettingsProvider.notifier)
                                  .update((s) => s.copyWith(performanceMonitoringMode: v));
                            }
                          },
                          shape: const RoundedRectangleBorder(borderRadius: AppRadius.radiusMd),
                        ))
                    .toList(),
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),

          // Network Test
          const SectionHeader(
            title: 'Tes Jaringan Otomatis',
            subtitle: 'Kapan tes jaringan dijalankan otomatis di halaman Device.',
            icon: Icons.network_check_outlined,
          ),
          Padding(
            padding: AppSpacing.screenPadding,
            child: Card(
              child: Column(
                children: NetworkTestAutoRun.values
                    .asMap()
                    .entries
                    .map((entry) => RadioListTile<NetworkTestAutoRun>(
                          value: entry.value,
                          groupValue: settings.networkTestAutoRun,
                          title: Text(entry.value.label,
                              style: theme.textTheme.bodyMedium
                                  ?.copyWith(fontWeight: FontWeight.w600)),
                          subtitle: Text(entry.value.description,
                              style: theme.textTheme.bodySmall
                                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                          activeColor: theme.colorScheme.primary,
                          onChanged: (v) {
                            if (v != null) {
                              ref
                                  .read(appSettingsProvider.notifier)
                                  .update((s) => s.copyWith(networkTestAutoRun: v));
                            }
                          },
                          shape: const RoundedRectangleBorder(borderRadius: AppRadius.radiusMd),
                        ))
                    .toList(),
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),

          // Privacy
          const SectionHeader(
            title: 'Privasi',
            subtitle: 'Data kamu, dijelaskan dengan jelas.',
            icon: Icons.lock_outline,
          ),
          Padding(
            padding: AppSpacing.screenPadding,
            child: Column(
              children: [
                // Privacy disclosure card
                Card(
                  color: theme.colorScheme.primaryContainer.withAlpha(70),
                  child: Padding(
                    padding: AppSpacing.cardPadding,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Icon(Icons.verified_user_outlined,
                              color: theme.colorScheme.primary, size: AppSizes.iconMd),
                          const SizedBox(width: AppSpacing.sm),
                          Expanded(
                            child: Text('Data Kamu Tetap di HP Kamu',
                                style: theme.textTheme.titleSmall
                                    ?.copyWith(fontWeight: FontWeight.w700)),
                          ),
                        ]),
                        const SizedBox(height: AppSpacing.sm),
                        const _PrivacyPoint(
                          icon: Icons.account_circle_outlined,
                          text: 'Tidak perlu akun untuk memakai aplikasi ini.',
                        ),
                        const SizedBox(height: AppSpacing.xs),
                        const _PrivacyPoint(
                          icon: Icons.storage_outlined,
                          text:
                              'Profil game dan riwayat diagnostik hanya disimpan di HP ini.',
                        ),
                        const SizedBox(height: AppSpacing.xs),
                        const _PrivacyPoint(
                          icon: Icons.campaign_outlined,
                          text:
                              'Iklan ditampilkan oleh Google AdMob, yang dapat memakai ID iklan perangkat. '
                              'Tidak ada layanan analitik lain yang dipakai.',
                        ),
                      ],
                    ),
                  ),
                ),
                const _AdPrivacyOptionsTile(),
                const SizedBox(height: AppSpacing.sm),
                // Crash reporting opt-in
                Card(
                  child: SwitchListTile(
                    value: settings.crashReportingOptIn,
                    onChanged: (v) => ref
                        .read(appSettingsProvider.notifier)
                        .update((s) => s.copyWith(crashReportingOptIn: v)),
                    title: const Text('Laporan crash (opsional)',
                        style: TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: const Text(
                        'Fitur ini belum aktif. Belum ada data yang dikirim, '
                        'bahkan kalau saklar ini dinyalakan.'),
                    secondary: const _IconBox(icon: Icons.bug_report_outlined, isActive: false),
                    activeColor: theme.colorScheme.primary,
                    shape: const RoundedRectangleBorder(borderRadius: AppRadius.radiusMd),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.lg),

          // Safety
          const SectionHeader(
            title: 'Keamanan',
            subtitle: 'Jaminan keamanan yang tidak bisa dimatikan.',
            icon: Icons.security_rounded,
          ),
          Padding(
            padding: AppSpacing.screenPadding,
            child: Card(
              child: Column(
                children: [
                  const NexusProSettingsTile(
                    title: 'Mode Aman Selalu Aktif',
                    subtitle: 'Perubahan sistem tingkat tinggi selalu meminta konfirmasi darimu',
                    leadingIcon: Icons.verified_user_outlined,
                    trailing: NexusProStatusBadge(type: NexusProStatusType.safe, customLabel: 'Aktif'),
                    onTap: null,
                    showDivider: true,
                  ),
                  NexusProSettingsTile(
                    title: 'Reset Pengaturan',
                    subtitle: 'Kembalikan semua pengaturan ke bawaan (profil game dan riwayat tidak dihapus)',
                    leadingIcon: Icons.settings_backup_restore_outlined,
                    onTap: () => _confirmResetSettings(context, ref),
                    showDivider: false,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),

          // Data Management
          const SectionHeader(
            title: 'Kelola Data',
            subtitle: 'Ekspor, impor, atau hapus data yang tersimpan di HP.',
            icon: Icons.folder_outlined,
          ),
          Padding(
            padding: AppSpacing.screenPadding,
            child: Card(
              child: Column(
                children: [
                  NexusProSettingsTile(
                    title: 'Kelola Data Lokal',
                    subtitle: 'Ekspor, impor, hapus riwayat dan profil',
                    leadingIcon: Icons.manage_history_outlined,
                    onTap: () => context.push(RouteNames.dataManagement),
                    showDivider: false,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),

          // Application
          const SectionHeader(
            title: 'Aplikasi',
            subtitle: 'Info produk dan versi.',
            icon: Icons.info_outline,
          ),
          Padding(
            padding: AppSpacing.screenPadding,
            child: Card(
              child: Column(
                children: [
                  NexusProSettingsTile(
                    title: 'Tutorial & Panduan Fitur',
                    subtitle: 'Putar ulang tur panduan semua fitur',
                    leadingIcon: Icons.explore_outlined,
                    onTap: () => ref.read(featureTourProvider.notifier).start(),
                    showDivider: true,
                  ),
                  NexusProSettingsTile(
                    title: 'Tentang NexusPro',
                    subtitle: 'Versi, lisensi, dan info developer',
                    leadingIcon: Icons.info_outline,
                    onTap: () => context.go(RouteNames.about),
                    showDivider: false,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmResetSettings(BuildContext context, WidgetRef ref) {
    showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Reset pengaturan?'),
        content: const Text('Semua pengaturan akan kembali ke bawaan. '
            'Profil game dan riwayat tidak terpengaruh.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              ref.read(appSettingsProvider.notifier).reset();
            },
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }

  IconData _iconForTheme(ThemePreference pref) => switch (pref) {
        ThemePreference.system => Icons.brightness_auto_outlined,
        ThemePreference.light => Icons.light_mode_outlined,
        ThemePreference.dark => Icons.dark_mode_outlined,
        ThemePreference.amoled => Icons.contrast_outlined,
      };
}

class _IconBox extends StatelessWidget {
  const _IconBox({required this.icon, required this.isActive});
  final IconData icon;
  final bool isActive;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: AppRadius.radiusMd,
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Icon(
        icon,
        size: AppSizes.iconSm,
        color: isActive ? theme.colorScheme.primary : theme.colorScheme.onSurfaceVariant,
      ),
    );
  }
}

class _PrivacyPoint extends StatelessWidget {
  const _PrivacyPoint({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 16, color: theme.colorScheme.primary),
        const SizedBox(width: AppSpacing.xs),
        Expanded(
          child: Text(text,
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: theme.colorScheme.onSurface, height: 1.4)),
        ),
      ],
    );
  }
}

/// Lets EEA / UK users reopen Google's ad-consent form (required by the UMP
/// policy). Hidden everywhere Google says it isn't needed.
class _AdPrivacyOptionsTile extends ConsumerWidget {
  const _AdPrivacyOptionsTile();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ads = ref.watch(adServiceProvider);
    return FutureBuilder<bool>(
      future: ads.privacyOptionsRequired(),
      builder: (context, snap) {
        if (snap.data != true) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.only(top: AppSpacing.sm),
          child: Card(
            child: NexusProSettingsTile(
              title: 'Opsi privasi iklan',
              subtitle: 'Ubah izin personalisasi iklan',
              leadingIcon: Icons.privacy_tip_outlined,
              onTap: ads.showPrivacyOptions,
              showDivider: false,
            ),
          ),
        );
      },
    );
  }
}
