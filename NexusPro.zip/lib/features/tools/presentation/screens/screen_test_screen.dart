import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Tes layar: layar penuh warna polos untuk mencari dead pixel dan bercak warna.
class ScreenTestScreen extends StatefulWidget {
  const ScreenTestScreen({super.key});

  @override
  State<ScreenTestScreen> createState() => _ScreenTestScreenState();
}

class _ScreenTestScreenState extends State<ScreenTestScreen> {
  static const List<String> _names = [
    'Merah',
    'Hijau',
    'Biru',
    'Putih',
    'Hitam',
    'Abu-abu',
    'Gradasi pelangi',
  ];
  static const List<Color> _solids = [
    Color(0xFFFF0000),
    Color(0xFF00FF00),
    Color(0xFF0000FF),
    Color(0xFFFFFFFF),
    Color(0xFF000000),
    Color(0xFF808080),
  ];
  static const int _gradientIndex = 6;

  int _index = 0;
  bool _showHint = true;
  Timer? _hintTimer;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _scheduleHintHide();
  }

  @override
  void dispose() {
    _hintTimer?.cancel();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _scheduleHintHide() {
    _hintTimer?.cancel();
    _hintTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) setState(() => _showHint = false);
    });
  }

  void _next() {
    setState(() {
      _index = (_index + 1) % _names.length;
      _showHint = true;
    });
    _scheduleHintHide();
  }

  void _close() {
    Navigator.of(context).maybePop();
  }

  @override
  Widget build(BuildContext context) {
    final bool isGradient = _index == _gradientIndex;

    return Scaffold(
      backgroundColor: isGradient ? Colors.black : _solids[_index],
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _next,
        onLongPress: _close,
        child: Stack(
          children: [
            if (isGradient)
              const Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(0xFFFF0000),
                        Color(0xFFFF8800),
                        Color(0xFFFFFF00),
                        Color(0xFF00FF00),
                        Color(0xFF00FFFF),
                        Color(0xFF0000FF),
                        Color(0xFFFF00FF),
                      ],
                    ),
                  ),
                ),
              ),
            SafeArea(
              child: Align(
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: CircleAvatar(
                    backgroundColor: Colors.black54,
                    child: IconButton(
                      tooltip: 'Keluar',
                      icon: const Icon(Icons.close_rounded, color: Colors.white),
                      onPressed: _close,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 48,
              child: IgnorePointer(
                child: AnimatedOpacity(
                  opacity: _showHint ? 1 : 0,
                  duration: const Duration(milliseconds: 300),
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      margin: const EdgeInsets.symmetric(horizontal: 24),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '${_names[_index]} (${_index + 1}/${_names.length})',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Ketuk untuk ganti warna • tahan atau tombol X untuk keluar',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white70, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
