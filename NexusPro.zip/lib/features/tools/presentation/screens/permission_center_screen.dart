import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../core/theme/tokens/app_spacing.dart';
import '../../../../shared/widgets/app_bars/nexuspro_app_bar.dart';
import '../../../../shared/widgets/section_header.dart';
import '../../data/system_tools_bridge.dart';

/// One screen that shows every permission NexusPro can use, why it is needed,
/// and a button that fixes it.
class PermissionCenterScreen extends StatefulWidget {
  const PermissionCenterScreen({super.key});

  @override
  State<PermissionCenterScreen> createState() => _PermissionCenterScreenState();
}

class _PermissionCenterScreenState extends State<PermissionCenterScreen>
    with WidgetsBindingObserver {
  static const String _adbCommand =
      'adb shell pm grant com.nexuspro.optimization android.permission.WRITE_SECURE_SETTINGS';

  final SystemToolsBridge _bridge = const SystemToolsBridge();

  Map<String, bool> _status = <String, bool>{};
  bool _loading = true;
  bool _granting = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Back from a system settings page: re-check everything.
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    final status = await _bridge.getPermissions();
    if (!mounted) return;
    setState(() {
      _status = status;
      _loading = false;
    });
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  Future<void> _open(String target) async {
    final opened = await _bridge.open(target);
    if (!opened) _snack('Halaman pengaturan tidak bisa dibuka di HP ini.');
  }

  Future<void> _grantSecure() async {
    if (_granting) return;
    setState(() => _granting = true);
    final result = await _bridge.grantSecureSettings();
    if (!mounted) return;
    setState(() => _granting = false);
    _snack(result.message.isEmpty ? (result.ok ? 'Berhasil.' : 'Gagal.') : result.message);
    await _refresh();
  }

  bool _on(String key) => _status[key] == true;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    const keys = <String>[
      'overlay',
      'accessibility',
      'usageAccess',
      'writeSettings',
      'secureSettings',
      'dnd',
      'battery',
      'notifications',
    ];
    final ready = keys.where(_on).length;

    return Scaffold(
      appBar: const NexusProAppBar(
        title: 'Pusat Izin',
        subtitle: 'Semua izin di satu tempat',
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _refresh,
              child: ListView(
                padding: const EdgeInsets.only(bottom: AppSpacing.xl),
                children: [
                  Padding(
                    padding: AppSpacing.screenPadding,
                    child: Card(
                      child: Padding(
                        padding: AppSpacing.cardPadding,
                        child: Row(
                          children: [
                            Icon(
                              ready == keys.length
                                  ? Icons.verified_rounded
                                  : Icons.info_outline_rounded,
                              color: ready == keys.length ? Colors.green : theme.colorScheme.primary,
                            ),
                            const SizedBox(width: AppSpacing.sm),
                            Expanded(
                              child: Text(
                                ready == keys.length
                                    ? 'Semua izin sudah aktif. Semua fitur siap dipakai.'
                                    : '$ready dari ${keys.length} izin aktif. Aktifkan sisanya supaya semua fitur berjalan.',
                                style: theme.textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SectionHeader(
                    title: 'Game Mode',
                    subtitle: 'Supaya bubble muncul di dalam game.',
                    icon: Icons.layers_rounded,
                  ),
                  _PermissionTile(
                    icon: Icons.layers_outlined,
                    title: 'Tampil di atas aplikasi lain',
                    why: 'Wajib agar bubble Game Mode bisa tampil di atas game.',
                    granted: _on('overlay'),
                    actionLabel: 'Aktifkan',
                    onAction: () => _open('overlay'),
                  ),
                  _PermissionTile(
                    icon: Icons.sensors_rounded,
                    title: 'Pendeteksi game (Aksesibilitas)',
                    why: 'Paling pasti: tahu game yang dibuka seketika dan menyalakan bubble otomatis. '
                        'Juga untuk tombol Screenshot di panel. Tidak membaca isi layar. '
                        'Cari "NexusPro Game Detector" lalu nyalakan. Kalau abu-abu: Info aplikasi, '
                        'titik tiga kanan atas, "Izinkan pengaturan terbatas".',
                    granted: _on('accessibility'),
                    actionLabel: 'Buka Aksesibilitas',
                    onAction: () => _open('accessibility'),
                    footer: _on('accessibility')
                        ? null
                        : Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () => _open('appDetails'),
                              child: const Text('Buka Info aplikasi'),
                            ),
                          ),
                  ),
                  _PermissionTile(
                    icon: Icons.query_stats_rounded,
                    title: 'Akses penggunaan aplikasi',
                    why: 'Dipakai untuk tahu game mana yang sedang dibuka, '
                        'jadi bubble muncul otomatis hanya di dalam game.',
                    granted: _on('usageAccess'),
                    actionLabel: 'Aktifkan',
                    onAction: () => _open('usageAccess'),
                  ),
                  _PermissionTile(
                    icon: Icons.battery_charging_full_rounded,
                    title: 'Abaikan optimasi baterai',
                    why: 'Mencegah HP mematikan bubble di latar belakang. Sangat disarankan.',
                    granted: _on('battery'),
                    actionLabel: 'Izinkan',
                    onAction: () => _open('battery'),
                  ),
                  _PermissionTile(
                    icon: Icons.notifications_active_outlined,
                    title: 'Notifikasi',
                    why: 'Menampilkan notifikasi "Game Mode aktif" dengan tombol matikan.',
                    granted: _on('notifications'),
                    actionLabel: 'Izinkan',
                    onAction: () => _open('notifications'),
                  ),
                  _PermissionTile(
                    icon: Icons.rocket_launch_outlined,
                    title: 'Mulai otomatis (Oppo, Xiaomi, Vivo)',
                    why: 'HP merk tertentu mematikan aplikasi latar belakang. '
                        'Nyalakan "Mulai otomatis" untuk NexusPro di halaman ini. '
                        'Statusnya tidak bisa dicek otomatis.',
                    granted: null,
                    actionLabel: 'Buka',
                    onAction: () => _open('autostart'),
                  ),
                  const SectionHeader(
                    title: 'Mengubah pengaturan sistem',
                    subtitle: 'Supaya tweak dan Pengaturan Cepat benar-benar bekerja.',
                    icon: Icons.tune_rounded,
                  ),
                  _PermissionTile(
                    icon: Icons.settings_applications_outlined,
                    title: 'Ubah pengaturan sistem',
                    why: 'Untuk kecerahan, waktu layar mati, tampilkan sentuhan, dan rotasi layar. '
                        'Tanpa root dan tanpa Shizuku.',
                    granted: _on('writeSettings'),
                    actionLabel: 'Izinkan',
                    onAction: () => _open('writeSettings'),
                  ),
                  _PermissionTile(
                    icon: Icons.admin_panel_settings_outlined,
                    title: 'Pengaturan lanjutan (WRITE_SECURE_SETTINGS)',
                    why: 'Untuk animasi, refresh rate, DNS, dan tweak lanjutan. '
                        'Cukup diberikan sekali, lalu bekerja terus tanpa Shizuku.',
                    granted: _on('secureSettings'),
                    actionLabel: _granting ? 'Memproses...' : 'Beri otomatis',
                    onAction: _granting ? null : _grantSecure,
                    footer: _on('secureSettings') ? null : _buildSecureHelp(theme),
                  ),
                  _PermissionTile(
                    icon: Icons.do_not_disturb_on_outlined,
                    title: 'Jangan ganggu (DND)',
                    why: 'Untuk tombol DND di panel overlay dan tweak mode gaming.',
                    granted: _on('dnd'),
                    actionLabel: 'Izinkan',
                    onAction: () => _open('dnd'),
                  ),
                  const SectionHeader(
                    title: 'Shizuku',
                    subtitle: 'Cara termudah memberi izin tingkat tinggi tanpa root.',
                    icon: Icons.bolt_rounded,
                  ),
                  _PermissionTile(
                    icon: Icons.bolt_outlined,
                    title: _on('shizukuGranted')
                        ? 'Shizuku aktif dan sudah diizinkan'
                        : (_on('shizukuRunning')
                            ? 'Shizuku berjalan, belum diizinkan'
                            : 'Shizuku belum berjalan'),
                    why: 'Install Shizuku, nyalakan Wireless debugging, tekan Start di Shizuku, '
                        'lalu buka NexusPro dan izinkan. Setelah itu tekan "Beri otomatis" '
                        'di atas supaya izin pengaturan lanjutan menetap.',
                    granted: _on('shizukuGranted'),
                    actionLabel: _on('shizukuRunning') ? 'Izinkan Shizuku' : 'Buka Shizuku',
                    onAction: () => _open('shizuku'),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildSecureHelp(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.only(top: AppSpacing.xs),
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.sm),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerHighest.withAlpha(120),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Tanpa Shizuku/root, jalankan perintah ini dari PC (ADB) sekali saja:',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 4),
            SelectableText(
              _adbCommand,
              style: theme.textTheme.bodySmall?.copyWith(fontFamily: 'monospace'),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: () async {
                  await Clipboard.setData(const ClipboardData(text: _adbCommand));
                  _snack('Perintah disalin.');
                },
                icon: const Icon(Icons.copy_rounded, size: 16),
                label: const Text('Salin'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PermissionTile extends StatelessWidget {
  const _PermissionTile({
    required this.icon,
    required this.title,
    required this.why,
    required this.granted,
    required this.actionLabel,
    required this.onAction,
    this.footer,
  });

  final IconData icon;
  final String title;
  final String why;

  /// true = active, false = missing, null = cannot be detected.
  final bool? granted;
  final String actionLabel;
  final VoidCallback? onAction;
  final Widget? footer;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final Color statusColor = granted == true
        ? Colors.green
        : (granted == false ? theme.colorScheme.error : theme.colorScheme.outline);
    final String statusText =
        granted == true ? 'Aktif' : (granted == false ? 'Belum aktif' : 'Cek manual');

    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.md, AppSpacing.xxs, AppSpacing.md, AppSpacing.xxs),
      child: Card(
        child: Padding(
          padding: AppSpacing.cardPadding,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, color: theme.colorScheme.primary),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Text(
                      title,
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                    ),
                  ),
                  Text(
                    statusText,
                    style: theme.textTheme.labelMedium
                        ?.copyWith(color: statusColor, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.xs),
              Text(
                why,
                style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
              if (granted != true) ...[
                const SizedBox(height: AppSpacing.xs),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton.tonal(onPressed: onAction, child: Text(actionLabel)),
                ),
              ],
              if (footer != null) footer!,
            ],
          ),
        ),
      ),
    );
  }
}
