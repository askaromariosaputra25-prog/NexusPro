import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/routing/route_names.dart';
import '../../../../core/theme/tokens/app_spacing.dart';
import '../../../../shared/widgets/app_bars/nexuspro_app_bar.dart';
import '../../../../shared/widgets/section_header.dart';
import '../../data/system_tools_bridge.dart';

class _ToggleSpec {
  const _ToggleSpec(this.id, this.icon, this.title, this.subtitle);

  final String id;
  final IconData icon;
  final String title;
  final String subtitle;
}

/// Pengaturan Cepat: real system settings changed from inside the app.
/// Every change is read back from the system, so the switch never lies.
class QuickSettingsScreen extends StatefulWidget {
  const QuickSettingsScreen({super.key});

  @override
  State<QuickSettingsScreen> createState() => _QuickSettingsScreenState();
}

class _QuickSettingsScreenState extends State<QuickSettingsScreen> with WidgetsBindingObserver {
  static const List<_ToggleSpec> _specs = <_ToggleSpec>[
    _ToggleSpec('show_touches', Icons.touch_app_outlined, 'Tampilkan sentuhan',
        'Titik putih muncul di tiap sentuhan jari. Enak buat cek respons layar.'),
    _ToggleSpec('pointer_location', Icons.my_location_rounded, 'Lokasi pointer',
        'Garis dan koordinat sentuhan di bagian atas layar (alat developer).'),
    _ToggleSpec('auto_rotate', Icons.screen_rotation_rounded, 'Rotasi layar otomatis',
        'Layar ikut berputar saat HP dimiringkan.'),
    _ToggleSpec('auto_brightness', Icons.brightness_auto_rounded, 'Kecerahan otomatis',
        'Matikan supaya kecerahan tidak naik turun sendiri saat main game.'),
    _ToggleSpec('haptic', Icons.vibration_rounded, 'Getaran sentuhan',
        'Getar halus saat menyentuh tombol sistem.'),
    _ToggleSpec('touch_sounds', Icons.volume_up_outlined, 'Suara sentuhan',
        'Bunyi klik saat menyentuh layar atau tombol.'),
    _ToggleSpec('stay_awake', Icons.power_settings_new_rounded, 'Layar tetap menyala saat mengisi',
        'Layar tidak mati selama HP dicas. Butuh izin pengaturan lanjutan.'),
  ];

  static const List<(String, int)> _timeouts = <(String, int)>[
    ('15 dtk', 15000),
    ('30 dtk', 30000),
    ('1 mnt', 60000),
    ('2 mnt', 120000),
    ('5 mnt', 300000),
    ('10 mnt', 600000),
    ('30 mnt', 1800000),
  ];

  final SystemToolsBridge _bridge = const SystemToolsBridge();

  bool _loading = true;
  Map<String, bool?> _toggles = <String, bool?>{};
  double _brightness = 128;
  int? _timeoutMs;
  bool _auto = false;
  bool _writeAllowed = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load();
  }

  Future<void> _load() async {
    final toggles = await _bridge.getToggles();
    final display = await _bridge.getDisplay();
    final perms = await _bridge.getPermissions();
    if (!mounted) return;
    setState(() {
      _toggles = toggles;
      final b = display['brightness'];
      if (b is int) _brightness = b.clamp(1, 255).toDouble();
      final t = display['timeoutMs'];
      _timeoutMs = t is int ? t : null;
      _auto = display['autoBrightness'] == true;
      _writeAllowed = perms['writeSettings'] == true;
      _loading = false;
    });
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  Future<void> _setToggle(String id, bool value) async {
    final result = await _bridge.setToggle(id, value);
    if (!result.ok) _snack(result.message);
    await _load();
  }

  Future<void> _applyBrightness(double value) async {
    final result = await _bridge.setBrightness(value.round());
    if (!result.ok) _snack(result.message);
    await _load();
  }

  Future<void> _setTimeout(int ms) async {
    final result = await _bridge.setScreenTimeout(ms);
    if (!result.ok) _snack(result.message);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: const NexusProAppBar(
        title: 'Pengaturan Cepat',
        subtitle: 'Ubah pengaturan sistem langsung dari sini',
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.only(bottom: AppSpacing.xl),
              children: [
                if (!_writeAllowed)
                  Padding(
                    padding: AppSpacing.screenPadding,
                    child: Card(
                      color: theme.colorScheme.errorContainer.withAlpha(120),
                      child: Padding(
                        padding: AppSpacing.cardPadding,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Izin "Ubah pengaturan sistem" belum aktif.',
                              style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Tanpa izin ini, sebagian besar pengaturan di bawah tidak bisa diubah.',
                              style: theme.textTheme.bodySmall,
                            ),
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.tonal(
                                onPressed: () => context.push(RouteNames.toolPermissions),
                                child: const Text('Buka Pusat Izin'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                const SectionHeader(
                  title: 'Layar',
                  subtitle: 'Kecerahan dan waktu layar mati.',
                  icon: Icons.brightness_6_outlined,
                ),
                Padding(
                  padding: AppSpacing.screenPadding,
                  child: Card(
                    child: Padding(
                      padding: AppSpacing.cardPadding,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Kecerahan: ${_brightness.round()} / 255'
                            '${_auto ? ' (otomatis aktif, geser untuk mode manual)' : ''}',
                            style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                          ),
                          Slider(
                            value: _brightness,
                            min: 1,
                            max: 255,
                            divisions: 254,
                            label: _brightness.round().toString(),
                            onChanged: (v) => setState(() => _brightness = v),
                            onChangeEnd: _applyBrightness,
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          Text(
                            'Layar mati otomatis setelah',
                            style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          Wrap(
                            spacing: 8,
                            runSpacing: 4,
                            children: [
                              for (final t in _timeouts)
                                ChoiceChip(
                                  label: Text(t.$1),
                                  selected: _timeoutMs == t.$2,
                                  onSelected: (_) => _setTimeout(t.$2),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SectionHeader(
                  title: 'Sentuhan & sistem',
                  subtitle: 'Saklar ini membaca dan menulis pengaturan HP yang sebenarnya.',
                  icon: Icons.tune_rounded,
                ),
                Padding(
                  padding: AppSpacing.screenPadding,
                  child: Card(
                    child: Column(
                      children: [
                        for (int i = 0; i < _specs.length; i++) ...[
                          if (i > 0) const Divider(height: 1),
                          _buildToggle(_specs[i]),
                        ],
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildToggle(_ToggleSpec spec) {
    final value = _toggles[spec.id];
    return SwitchListTile(
      secondary: Icon(spec.icon),
      title: Text(spec.title),
      subtitle: Text(value == null ? '${spec.subtitle}\nTidak tersedia di HP ini.' : spec.subtitle),
      value: value ?? false,
      onChanged: value == null ? null : (v) => _setToggle(spec.id, v),
    );
  }
}
