import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../../../../core/theme/tokens/app_radius.dart';
import '../../../../core/theme/tokens/app_spacing.dart';
import '../../../../shared/widgets/app_bars/nexuspro_app_bar.dart';

/// FPS meter: menghitung frame yang benar-benar dirender per detik.
class FpsMeterScreen extends StatefulWidget {
  const FpsMeterScreen({super.key});

  @override
  State<FpsMeterScreen> createState() => _FpsMeterScreenState();
}

class _FpsMeterScreenState extends State<FpsMeterScreen> with SingleTickerProviderStateMixin {
  static const int _historyLength = 30;

  late final Ticker _ticker;
  final ValueNotifier<double> _time = ValueNotifier<double>(0);

  Duration _windowStart = Duration.zero;
  int _frames = 0;
  double _fps = 0;
  final List<double> _history = <double>[];

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_onTick)..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    _time.dispose();
    super.dispose();
  }

  void _onTick(Duration elapsed) {
    _time.value = elapsed.inMicroseconds / 1000000.0;
    _frames++;
    final Duration window = elapsed - _windowStart;
    if (window >= const Duration(seconds: 1)) {
      final double fps = _frames * 1000000.0 / window.inMicroseconds;
      _frames = 0;
      _windowStart = elapsed;
      if (!mounted) return;
      setState(() {
        _fps = fps;
        _history.add(fps);
        if (_history.length > _historyLength) {
          _history.removeAt(0);
        }
      });
    }
  }

  void _reset() {
    setState(() {
      _history.clear();
      _fps = 0;
    });
  }

  double? get _min => _history.isEmpty ? null : _history.reduce(math.min);
  double? get _max => _history.isEmpty ? null : _history.reduce(math.max);
  double? get _avg {
    if (_history.isEmpty) return null;
    double sum = 0;
    for (final v in _history) {
      sum += v;
    }
    return sum / _history.length;
  }

  ({String label, Color color}) _verdict() {
    if (_history.isEmpty) return (label: 'Mengukur...', color: Colors.grey);
    if (_fps >= 110) return (label: 'Super halus (sekitar 120 Hz)', color: Colors.green);
    if (_fps >= 85) return (label: 'Halus (sekitar 90 Hz)', color: Colors.green);
    if (_fps >= 55) return (label: 'Normal (sekitar 60 Hz)', color: Colors.lightGreen);
    if (_fps >= 40) return (label: 'Agak patah-patah', color: Colors.orange);
    return (label: 'Patah-patah', color: Colors.red);
  }

  String _fmt(double? v) => v == null ? '-' : v.toStringAsFixed(0);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final verdict = _verdict();

    return Scaffold(
      appBar: NexusProAppBar(
        title: 'FPS Meter',
        subtitle: 'Frame per detik yang dirender HP',
        actions: [
          IconButton(
            tooltip: 'Reset',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _reset,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.md),
        children: [
          Card(
            child: Padding(
              padding: AppSpacing.cardPadding,
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        _history.isEmpty ? '--' : _fps.toStringAsFixed(0),
                        style: theme.textTheme.displayLarge?.copyWith(
                          fontWeight: FontWeight.w800,
                          color: verdict.color,
                        ),
                      ),
                      const SizedBox(width: AppSpacing.xs),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 14),
                        child: Text('FPS', style: theme.textTheme.titleMedium),
                      ),
                    ],
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      verdict.label,
                      style: theme.textTheme.titleSmall?.copyWith(
                        color: verdict.color,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  Row(
                    children: [
                      _Stat(label: 'Min', value: _fmt(_min)),
                      _Stat(label: 'Rata-rata', value: _fmt(_avg)),
                      _Stat(label: 'Maks', value: _fmt(_max)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          Card(
            child: Padding(
              padding: AppSpacing.cardPadding,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Riwayat 30 detik terakhir',
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: AppSpacing.xs),
                  SizedBox(
                    height: 110,
                    width: double.infinity,
                    child: ClipRRect(
                      borderRadius: AppRadius.radiusMd,
                      child: CustomPaint(
                        painter: _BarsPainter(
                          values: List<double>.from(_history),
                          barColor: scheme.primary,
                          backgroundColor: scheme.surfaceContainerHighest.withOpacity(0.5),
                          slots: _historyLength,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          Card(
            child: Padding(
              padding: AppSpacing.cardPadding,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Animasi uji',
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: AppSpacing.xs),
                  SizedBox(
                    height: 160,
                    width: double.infinity,
                    child: ClipRRect(
                      borderRadius: AppRadius.radiusMd,
                      child: CustomPaint(
                        painter: _BouncePainter(
                          time: _time,
                          color: scheme.primary,
                          secondaryColor: scheme.tertiary,
                          backgroundColor: scheme.surfaceContainerHighest.withOpacity(0.5),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            'Layar 60Hz/90Hz/120Hz: kalau angka FPS mendekati refresh rate layarmu berarti lancar. '
            'Angka ini hanya mengukur aplikasi ini, bukan game lain. '
            'Kalau jauh di bawah refresh rate padahal tidak ada beban, cek mode hemat baterai atau refresh rate di pengaturan layar.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: scheme.onSurfaceVariant,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}

class _BarsPainter extends CustomPainter {
  _BarsPainter({
    required this.values,
    required this.barColor,
    required this.backgroundColor,
    required this.slots,
  });

  final List<double> values;
  final Color barColor;
  final Color backgroundColor;
  final int slots;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = backgroundColor);
    if (values.isEmpty) return;

    double maxVal = 60;
    for (final v in values) {
      if (v > maxVal) maxVal = v;
    }
    final double slotW = size.width / slots;
    final double barW = slotW * 0.7;
    final paint = Paint()..color = barColor;
    for (int i = 0; i < values.length; i++) {
      final double h = size.height * (values[i] / maxVal).clamp(0.0, 1.0).toDouble();
      final double x = i * slotW + (slotW - barW) / 2;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, size.height - h, barW, h),
          const Radius.circular(2),
        ),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _BarsPainter oldDelegate) => true;
}

class _BouncePainter extends CustomPainter {
  _BouncePainter({
    required this.time,
    required this.color,
    required this.secondaryColor,
    required this.backgroundColor,
  }) : super(repaint: time);

  final ValueNotifier<double> time;
  final Color color;
  final Color secondaryColor;
  final Color backgroundColor;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = backgroundColor);

    final double t = time.value;
    const double r = 16;
    final double x = r + (math.sin(t * 2.1) + 1) / 2 * (size.width - r * 2);
    final double y = r + (math.sin(t * 2.9 + 1) + 1) / 2 * (size.height - r * 2);
    canvas.drawCircle(Offset(x, y), r, Paint()..color = color);

    canvas.save();
    canvas.translate(size.width / 2, size.height / 2);
    canvas.rotate(t * 3);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(-24, -24, 48, 48),
        const Radius.circular(8),
      ),
      Paint()..color = secondaryColor.withOpacity(0.8),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _BouncePainter oldDelegate) => true;
}
