import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../../core/theme/tokens/app_radius.dart';
import '../../../../core/theme/tokens/app_spacing.dart';
import '../../../../shared/widgets/app_bars/nexuspro_app_bar.dart';

class _PingTarget {
  const _PingTarget(this.label, this.host, this.port);
  final String label;
  final String host;
  final int port;
}

/// Tes ping berbasis TCP connect (tanpa ICMP, jadi jalan di semua HP tanpa root).
class PingTestScreen extends StatefulWidget {
  const PingTestScreen({super.key});

  @override
  State<PingTestScreen> createState() => _PingTestScreenState();
}

class _PingTestScreenState extends State<PingTestScreen> {
  static const List<_PingTarget> _targets = [
    _PingTarget('Google DNS', '8.8.8.8', 53),
    _PingTarget('Cloudflare', '1.1.1.1', 443),
    _PingTarget('Quad9', '9.9.9.9', 53),
  ];
  static const int _customIndex = 3;
  static const int _maxSamples = 50;
  static const int _chartSamples = 40;

  final TextEditingController _hostCtl = TextEditingController();
  final TextEditingController _portCtl = TextEditingController();

  int _targetIndex = 0;
  bool _running = false;
  int _session = 0;
  int _sent = 0;
  int _failed = 0;
  String? _error;
  final List<double?> _history = <double?>[];

  @override
  void dispose() {
    _running = false;
    _session++;
    _hostCtl.dispose();
    _portCtl.dispose();
    super.dispose();
  }

  List<double> get _okValues {
    final out = <double>[];
    for (final v in _history) {
      if (v != null) out.add(v);
    }
    return out;
  }

  double? get _current {
    if (_history.isEmpty) return null;
    return _history.last;
  }

  double? get _min {
    final ok = _okValues;
    if (ok.isEmpty) return null;
    return ok.reduce(math.min);
  }

  double? get _max {
    final ok = _okValues;
    if (ok.isEmpty) return null;
    return ok.reduce(math.max);
  }

  double? get _avg {
    final ok = _okValues;
    if (ok.isEmpty) return null;
    double sum = 0;
    for (final v in ok) {
      sum += v;
    }
    return sum / ok.length;
  }

  double? get _jitter {
    final ok = _okValues;
    if (ok.length < 2) return null;
    double sum = 0;
    for (int i = 1; i < ok.length; i++) {
      sum += (ok[i] - ok[i - 1]).abs();
    }
    return sum / (ok.length - 1);
  }

  double get _lossPercent {
    if (_sent == 0) return 0;
    return _failed * 100.0 / _sent;
  }

  _PingTarget? _resolveTarget() {
    if (_targetIndex != _customIndex) return _targets[_targetIndex];
    final host = _hostCtl.text.trim();
    if (host.isEmpty) {
      setState(() => _error = 'Isi dulu host atau IP-nya.');
      return null;
    }
    if (RegExp(r'\s').hasMatch(host) || host.length > 253) {
      setState(() => _error = 'Host tidak valid (jangan pakai spasi, maksimal 253 karakter).');
      return null;
    }
    int port = 443;
    final portText = _portCtl.text.trim();
    if (portText.isNotEmpty) {
      final parsed = int.tryParse(portText);
      if (parsed == null || parsed < 1 || parsed > 65535) {
        setState(() => _error = 'Port harus angka 1 sampai 65535.');
        return null;
      }
      port = parsed;
    }
    return _PingTarget('Custom', host, port);
  }

  Future<double?> _probe(String host, int port) async {
    final sw = Stopwatch()..start();
    try {
      final socket = await Socket.connect(
        host,
        port,
        timeout: const Duration(seconds: 2),
      );
      sw.stop();
      socket.destroy();
      return sw.elapsedMicroseconds / 1000.0;
    } catch (_) {
      return null;
    }
  }

  Future<void> _start() async {
    final target = _resolveTarget();
    if (target == null) return;

    final session = ++_session;
    setState(() {
      _history.clear();
      _sent = 0;
      _failed = 0;
      _error = null;
      _running = true;
    });

    while (mounted && _running && session == _session && _sent < _maxSamples) {
      final ms = await _probe(target.host, target.port);
      if (!mounted || session != _session) return;
      setState(() {
        _sent++;
        if (ms == null) {
          _failed++;
        }
        _history.add(ms);
      });
      await Future<void>.delayed(const Duration(milliseconds: 700));
    }

    if (mounted && session == _session) {
      setState(() => _running = false);
    }
  }

  void _stop() {
    _session++;
    setState(() => _running = false);
  }

  ({String label, Color color}) _verdict(double avg) {
    if (avg < 50) return (label: 'Mantap', color: Colors.green);
    if (avg < 100) return (label: 'Oke', color: Colors.lightGreen);
    if (avg < 150) return (label: 'Lumayan', color: Colors.orange);
    return (label: 'Lag', color: Colors.red);
  }

  String _fmt(double? v) => v == null ? '-' : v.toStringAsFixed(0);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final avg = _avg;
    final current = _current;

    final chartValues = _history.length > _chartSamples
        ? _history.sublist(_history.length - _chartSamples)
        : List<double?>.from(_history);

    return Scaffold(
      appBar: const NexusProAppBar(
        title: 'Tes Ping',
        subtitle: 'Ukur kecepatan respon koneksi',
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.md),
        children: [
          Card(
            child: Padding(
              padding: AppSpacing.cardPadding,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Pilih target',
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: AppSpacing.xs),
                  Wrap(
                    spacing: AppSpacing.xs,
                    runSpacing: AppSpacing.xs,
                    children: [
                      for (int i = 0; i < _targets.length; i++)
                        ChoiceChip(
                          label: Text('${_targets[i].label} ${_targets[i].host}:${_targets[i].port}'),
                          selected: _targetIndex == i,
                          onSelected: _running ? null : (_) => setState(() => _targetIndex = i),
                        ),
                      ChoiceChip(
                        label: const Text('Custom'),
                        selected: _targetIndex == _customIndex,
                        onSelected:
                            _running ? null : (_) => setState(() => _targetIndex = _customIndex),
                      ),
                    ],
                  ),
                  if (_targetIndex == _customIndex) ...[
                    const SizedBox(height: AppSpacing.sm),
                    TextField(
                      controller: _hostCtl,
                      enabled: !_running,
                      keyboardType: TextInputType.url,
                      decoration: const InputDecoration(
                        labelText: 'Host / IP',
                        hintText: 'contoh: 8.8.8.8 atau google.com',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    TextField(
                      controller: _portCtl,
                      enabled: !_running,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Port (opsional)',
                        hintText: 'default 443',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                  if (_error != null) ...[
                    const SizedBox(height: AppSpacing.xs),
                    Text(_error!, style: TextStyle(color: scheme.error)),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          Card(
            child: Padding(
              padding: AppSpacing.cardPadding,
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        current == null
                            ? (_history.isEmpty ? '--' : 'Timeout')
                            : current.toStringAsFixed(0),
                        style: theme.textTheme.displayMedium?.copyWith(
                          fontWeight: FontWeight.w800,
                          color: current == null && _history.isNotEmpty
                              ? scheme.error
                              : scheme.primary,
                        ),
                      ),
                      const SizedBox(width: AppSpacing.xs),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Text('ms', style: theme.textTheme.titleMedium),
                      ),
                      const Spacer(),
                      if (avg != null)
                        Chip(
                          label: Text(
                            _verdict(avg).label,
                            style: const TextStyle(
                                color: Colors.white, fontWeight: FontWeight.w700),
                          ),
                          backgroundColor: _verdict(avg).color,
                        ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  SizedBox(
                    height: 120,
                    width: double.infinity,
                    child: ClipRRect(
                      borderRadius: AppRadius.radiusMd,
                      child: CustomPaint(
                        painter: _PingChartPainter(
                          values: chartValues,
                          lineColor: scheme.primary,
                          failColor: scheme.error,
                          gridColor: scheme.outlineVariant,
                          backgroundColor: scheme.surfaceContainerHighest.withOpacity(0.5),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  Row(
                    children: [
                      _Stat(label: 'Min', value: '${_fmt(_min)} ms'),
                      _Stat(label: 'Rata-rata', value: '${_fmt(avg)} ms'),
                      _Stat(label: 'Maks', value: '${_fmt(_max)} ms'),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.xs),
                  Row(
                    children: [
                      _Stat(
                        label: 'Jitter',
                        value: _jitter == null ? '-' : '${_jitter!.toStringAsFixed(1)} ms',
                      ),
                      _Stat(label: 'Packet loss', value: '${_lossPercent.toStringAsFixed(0)}%'),
                      _Stat(label: 'Sampel', value: '$_sent/$_maxSamples'),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.md),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: _running ? _stop : _start,
              icon: Icon(_running ? Icons.stop_rounded : Icons.play_arrow_rounded),
              label: Text(_running ? 'Stop' : 'Mulai tes'),
            ),
          ),
          const SizedBox(height: AppSpacing.md),
          Text(
            'Tes ini mengukur waktu sambung TCP ke server, jadi angkanya mirip ping asli. '
            'Di bawah 50 ms mantap untuk game online, di atas 150 ms biasanya terasa lag.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: scheme.onSurfaceVariant,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}

class _PingChartPainter extends CustomPainter {
  _PingChartPainter({
    required this.values,
    required this.lineColor,
    required this.failColor,
    required this.gridColor,
    required this.backgroundColor,
  });

  final List<double?> values;
  final Color lineColor;
  final Color failColor;
  final Color gridColor;
  final Color backgroundColor;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = backgroundColor);

    final gridPaint = Paint()
      ..color = gridColor.withOpacity(0.5)
      ..strokeWidth = 1;
    for (int i = 1; i < 4; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    if (values.isEmpty) return;

    double maxVal = 100;
    for (final v in values) {
      if (v != null && v * 1.2 > maxVal) maxVal = v * 1.2;
    }

    const double padding = 10;
    final double usableH = size.height - padding * 2;
    final int slots = math.max(values.length, 2);
    final double stepX = size.width / (slots - 1);

    final linePaint = Paint()
      ..color = lineColor
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeJoin = StrokeJoin.round;
    final dotPaint = Paint()..color = lineColor;
    final failPaint = Paint()..color = failColor;

    Path? path;
    for (int i = 0; i < values.length; i++) {
      final v = values[i];
      final x = stepX * i;
      if (v == null) {
        if (path != null) {
          canvas.drawPath(path, linePaint);
          path = null;
        }
        canvas.drawCircle(Offset(x, padding), 4, failPaint);
        continue;
      }
      final y = padding + usableH * (1 - (v / maxVal).clamp(0.0, 1.0));
      if (path == null) {
        path = Path()..moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
      canvas.drawCircle(Offset(x, y), 2.5, dotPaint);
    }
    if (path != null) {
      canvas.drawPath(path, linePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _PingChartPainter oldDelegate) => true;
}
