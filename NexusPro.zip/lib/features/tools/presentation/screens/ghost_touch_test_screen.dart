import 'dart:async';

import 'package:flutter/material.dart';

import '../../../../core/theme/tokens/app_radius.dart';
import '../../../../core/theme/tokens/app_spacing.dart';
import '../../../../shared/widgets/app_bars/nexuspro_app_bar.dart';

enum _GhostPhase { idle, running, done }

class _GhostEvent {
  const _GhostEvent(this.elapsedMs, this.position);
  final int elapsedMs;
  final Offset position;
}

/// Tes ghost touch: diamkan HP di meja, semua sentuhan yang terdeteksi dihitung.
class GhostTouchTestScreen extends StatefulWidget {
  const GhostTouchTestScreen({super.key});

  @override
  State<GhostTouchTestScreen> createState() => _GhostTouchTestScreenState();
}

class _GhostTouchTestScreenState extends State<GhostTouchTestScreen> {
  static const List<int> _durations = [15, 30, 60, 120];
  static const int _maxLog = 200;
  static const int _maxPoints = 500;

  _GhostPhase _phase = _GhostPhase.idle;
  int _duration = 30;
  int _remaining = 30;
  int _count = 0;
  Timer? _timer;
  final Stopwatch _sw = Stopwatch();
  final List<_GhostEvent> _log = <_GhostEvent>[];
  final List<Offset> _points = <Offset>[]; // dinormalisasi 0..1
  Size _area = Size.zero;

  @override
  void dispose() {
    _timer?.cancel();
    _sw.stop();
    super.dispose();
  }

  void _start() {
    _timer?.cancel();
    _sw
      ..reset()
      ..start();
    setState(() {
      _phase = _GhostPhase.running;
      _remaining = _duration;
      _count = 0;
      _log.clear();
      _points.clear();
    });
    _timer = Timer.periodic(const Duration(milliseconds: 250), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      final int left = _duration - _sw.elapsed.inSeconds;
      if (left <= 0) {
        _finish();
      } else if (left != _remaining) {
        setState(() => _remaining = left);
      }
    });
  }

  void _finish() {
    _timer?.cancel();
    _timer = null;
    _sw.stop();
    if (!mounted) return;
    setState(() => _phase = _GhostPhase.done);
  }

  void _addPoint(Offset local) {
    if (_area.width <= 0 || _area.height <= 0) return;
    if (_points.length >= _maxPoints) return;
    final double nx = (local.dx / _area.width).clamp(0.0, 1.0).toDouble();
    final double ny = (local.dy / _area.height).clamp(0.0, 1.0).toDouble();
    _points.add(Offset(nx, ny));
  }

  void _onDown(PointerDownEvent e) {
    setState(() {
      _count++;
      if (_log.length < _maxLog) {
        _log.add(_GhostEvent(_sw.elapsedMilliseconds, e.localPosition));
      }
      _addPoint(e.localPosition);
    });
  }

  void _onMove(PointerMoveEvent e) {
    // Gerakan tidak menambah hitungan, tapi dicatat untuk heatmap.
    _addPoint(e.localPosition);
  }

  String _seconds(int ms) => '${(ms / 1000).toStringAsFixed(1)} dtk';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const NexusProAppBar(
        title: 'Tes Ghost Touch',
        subtitle: 'Deteksi layar yang kesentuh sendiri',
      ),
      body: switch (_phase) {
        _GhostPhase.idle => _buildIdle(context),
        _GhostPhase.running => _buildRunning(context),
        _GhostPhase.done => _buildDone(context),
      },
    );
  }

  Widget _buildIdle(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return ListView(
      padding: const EdgeInsets.all(AppSpacing.md),
      children: [
        Card(
          color: scheme.primaryContainer.withAlpha(70),
          child: Padding(
            padding: AppSpacing.cardPadding,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Apa itu ghost touch?',
                    style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: AppSpacing.xs),
                Text(
                  'Ghost touch adalah layar yang menganggap ada sentuhan padahal kamu tidak menyentuhnya. '
                  'Biasanya karena layar rusak, protector jelek, atau charger tidak cocok.\n\n'
                  'Cara tes: taruh HP di meja, mulai tes, lalu JANGAN sentuh layar. '
                  'Setiap sentuhan yang terdeteksi akan dihitung. Kalau ada yang masuk, '
                  'berarti ada ghost touch (atau kamu tidak sengaja menyentuhnya).',
                  style: theme.textTheme.bodySmall?.copyWith(height: 1.45),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.sm),
        Card(
          child: Padding(
            padding: AppSpacing.cardPadding,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Durasi tes',
                    style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: AppSpacing.xs),
                Wrap(
                  spacing: AppSpacing.xs,
                  children: [
                    for (final d in _durations)
                      ChoiceChip(
                        label: Text('$d detik'),
                        selected: _duration == d,
                        onSelected: (_) => setState(() {
                          _duration = d;
                          _remaining = d;
                        }),
                      ),
                  ],
                ),
                const SizedBox(height: AppSpacing.xs),
                Text(
                  'Tips: atur waktu layar mati (screen timeout) lebih lama dari durasi tes supaya layar tidak padam.',
                  style: theme.textTheme.bodySmall?.copyWith(color: scheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.md),
        SizedBox(
          height: 52,
          child: FilledButton.icon(
            onPressed: _start,
            icon: const Icon(Icons.play_arrow_rounded),
            label: const Text('Mulai tes'),
          ),
        ),
      ],
    );
  }

  Widget _buildRunning(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return Column(
      children: [
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.xs),
            child: ClipRRect(
              borderRadius: AppRadius.radiusLg,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: scheme.surfaceContainerHighest.withOpacity(0.35),
                  border: Border.all(color: scheme.outlineVariant),
                  borderRadius: AppRadius.radiusLg,
                ),
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    _area = Size(constraints.maxWidth, constraints.maxHeight);
                    return Listener(
                      behavior: HitTestBehavior.opaque,
                      onPointerDown: _onDown,
                      onPointerMove: _onMove,
                      child: SizedBox.expand(
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '$_remaining',
                                style: theme.textTheme.displayLarge?.copyWith(
                                  fontWeight: FontWeight.w800,
                                  color: scheme.primary,
                                ),
                              ),
                              const SizedBox(height: AppSpacing.xs),
                              Text('Jangan sentuh layar!', style: theme.textTheme.titleMedium),
                              const SizedBox(height: AppSpacing.xs),
                              Text(
                                'Sentuhan terdeteksi: $_count',
                                style: theme.textTheme.titleSmall?.copyWith(
                                  color: _count > 0 ? scheme.error : scheme.onSurfaceVariant,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.md,
            AppSpacing.xs,
            AppSpacing.md,
            AppSpacing.md,
          ),
          child: SizedBox(
            width: double.infinity,
            height: 48,
            child: OutlinedButton.icon(
              onPressed: _finish,
              icon: const Icon(Icons.stop_rounded),
              label: const Text('Berhenti sekarang'),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDone(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final bool safe = _count == 0;
    final Color verdictColor = safe ? Colors.green : scheme.error;
    final int shown = _log.length < 20 ? _log.length : 20;

    return ListView(
      padding: const EdgeInsets.all(AppSpacing.md),
      children: [
        Card(
          child: Padding(
            padding: AppSpacing.cardPadding,
            child: Row(
              children: [
                Icon(
                  safe ? Icons.check_circle_rounded : Icons.warning_amber_rounded,
                  color: verdictColor,
                  size: 40,
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Text(
                    safe
                        ? 'Aman, tidak ada ghost touch'
                        : 'Terdeteksi $_count sentuhan tanpa disentuh — layar mungkin bermasalah',
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: verdictColor,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        if (!safe) ...[
          const SizedBox(height: AppSpacing.sm),
          Text('Peta lokasi sentuhan',
              style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: AppSpacing.xs),
          AspectRatio(
            aspectRatio: 0.6,
            child: ClipRRect(
              borderRadius: AppRadius.radiusMd,
              child: CustomPaint(
                painter: _HeatmapPainter(
                  points: List<Offset>.from(_points),
                  backgroundColor: scheme.surfaceContainerHighest.withOpacity(0.5),
                  borderColor: scheme.outlineVariant,
                  dotColor: scheme.error,
                ),
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          Text('Catatan sentuhan (maks 20 pertama)',
              style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: AppSpacing.xs),
          Card(
            child: Column(
              children: [
                for (int i = 0; i < shown; i++)
                  ListTile(
                    dense: true,
                    leading: Text('#${i + 1}'),
                    title: Text('Detik ke ${_seconds(_log[i].elapsedMs)}'),
                    subtitle: Text(
                      'x ${_log[i].position.dx.toStringAsFixed(0)}, y ${_log[i].position.dy.toStringAsFixed(0)}',
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.xs),
          Text(
            'Kalau sentuhan terus muncul tanpa kamu pegang, coba lepas charger, '
            'ganti atau lepas anti gores, lalu tes lagi. Kalau masih ada, kemungkinan layarnya bermasalah.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: scheme.onSurfaceVariant,
              height: 1.4,
            ),
          ),
        ],
        const SizedBox(height: AppSpacing.md),
        SizedBox(
          height: 52,
          child: FilledButton.icon(
            onPressed: () => setState(() => _phase = _GhostPhase.idle),
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Tes lagi'),
          ),
        ),
      ],
    );
  }
}

class _HeatmapPainter extends CustomPainter {
  _HeatmapPainter({
    required this.points,
    required this.backgroundColor,
    required this.borderColor,
    required this.dotColor,
  });

  final List<Offset> points;
  final Color backgroundColor;
  final Color borderColor;
  final Color dotColor;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = backgroundColor);
    canvas.drawRect(
      rect.deflate(0.5),
      Paint()
        ..color = borderColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );
    final dot = Paint()..color = dotColor.withOpacity(0.35);
    for (final p in points) {
      canvas.drawCircle(Offset(p.dx * size.width, p.dy * size.height), 7, dot);
    }
  }

  @override
  bool shouldRepaint(covariant _HeatmapPainter oldDelegate) => true;
}
