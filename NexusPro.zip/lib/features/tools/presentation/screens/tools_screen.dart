import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/routing/route_names.dart';
import '../../../../core/theme/tokens/app_radius.dart';
import '../../../../core/theme/tokens/app_spacing.dart';
import '../../../../shared/widgets/app_bars/nexuspro_app_bar.dart';
import '../../../../shared/widgets/app_shell.dart';
import '../../../../shared/widgets/section_header.dart';

/// Tab "Tools": kumpulan alat bantu untuk ngetes HP dan mode gaming.
class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const NexusProAppBar(
        title: 'Tools',
        subtitle: 'Alat bantu gaming dan tes HP',
      ),
      body: ListView(
        padding: EdgeInsets.only(bottom: AppShell.bottomInset(context)),
        children: const [
          SectionHeader(
            title: 'Game Mode',
            subtitle: 'Panel mengambang yang muncul di atas game kamu.',
            icon: Icons.videogame_asset_outlined,
          ),
          _ToolCard(
            icon: Icons.layers_rounded,
            title: 'Game Mode Overlay',
            subtitle:
                'Bubble mengambang: status sistem, boost RAM, hapus cache, dan aplikasi cepat.',
            route: RouteNames.gameMode,
            highlight: true,
          ),
          _ToolCard(
            icon: Icons.admin_panel_settings_rounded,
            title: 'Pusat Izin',
            subtitle:
                'Cek dan aktifkan semua izin di satu tempat, termasuk izin ubah pengaturan sistem.',
            route: RouteNames.toolPermissions,
          ),
          SizedBox(height: AppSpacing.md),
          SectionHeader(
            title: 'Pengaturan Sistem',
            subtitle: 'Ubah pengaturan HP langsung dari aplikasi.',
            icon: Icons.tune_rounded,
          ),
          _ToolCard(
            icon: Icons.tune_rounded,
            title: 'Pengaturan Cepat',
            subtitle:
                'Kecerahan, waktu layar mati, tampilkan sentuhan, rotasi layar, dan lainnya.',
            route: RouteNames.toolQuickSettings,
          ),
          SizedBox(height: AppSpacing.md),
          SectionHeader(
            title: 'Tes Jaringan',
            subtitle: 'Cek koneksi sebelum push rank.',
            icon: Icons.network_ping_outlined,
          ),
          _ToolCard(
            icon: Icons.network_ping_rounded,
            title: 'Tes Ping',
            subtitle: 'Ukur ping, jitter, dan packet loss ke server DNS atau host pilihanmu.',
            route: RouteNames.toolPing,
          ),
          SizedBox(height: AppSpacing.md),
          SectionHeader(
            title: 'Tes Layar & Sentuhan',
            subtitle: 'Pastikan layar HP sehat dan responsif.',
            icon: Icons.touch_app_outlined,
          ),
          _ToolCard(
            icon: Icons.touch_app_rounded,
            title: 'Tes Touch',
            subtitle: 'Cek multi-touch, jejak jari, dan area layar yang tidak merespon.',
            route: RouteNames.toolTouch,
          ),
          _ToolCard(
            icon: Icons.back_hand_outlined,
            title: 'Tes Ghost Touch',
            subtitle: 'Deteksi layar yang kesentuh sendiri tanpa dipegang.',
            route: RouteNames.toolGhost,
          ),
          _ToolCard(
            icon: Icons.palette_outlined,
            title: 'Tes Layar',
            subtitle: 'Cek dead pixel dan bercak warna dengan layar penuh.',
            route: RouteNames.toolScreen,
          ),
          _ToolCard(
            icon: Icons.speed_rounded,
            title: 'FPS Meter',
            subtitle: 'Lihat frame per detik asli yang dirender HP kamu.',
            route: RouteNames.toolFps,
          ),
        ],
      ),
    );
  }
}

class _ToolCard extends StatelessWidget {
  const _ToolCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.route,
    this.highlight = false,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String route;
  final bool highlight;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.md,
        AppSpacing.xxs,
        AppSpacing.md,
        AppSpacing.xxs,
      ),
      child: Card(
        clipBehavior: Clip.antiAlias,
        color: highlight ? scheme.primaryContainer.withAlpha(90) : null,
        child: InkWell(
          borderRadius: AppRadius.radiusLg,
          onTap: () => context.push(route),
          child: Padding(
            padding: AppSpacing.cardPadding,
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: scheme.primary.withOpacity(highlight ? 0.22 : 0.12),
                    borderRadius: AppRadius.radiusMd,
                  ),
                  child: Icon(icon, color: scheme.primary),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: AppSpacing.xxxs),
                      Text(
                        subtitle,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: scheme.onSurfaceVariant,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: AppSpacing.xs),
                Icon(Icons.chevron_right_rounded, color: scheme.onSurfaceVariant),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
