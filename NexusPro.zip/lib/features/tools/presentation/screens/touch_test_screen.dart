import 'package:flutter/material.dart';

import '../../../../core/theme/tokens/app_spacing.dart';
import '../../../../shared/widgets/app_bars/nexuspro_app_bar.dart';

enum _TouchMode { trail, grid }

/// Tes touch: multi-touch (jejak jari) dan grid (cek area layar yang mati).
class TouchTestScreen extends StatefulWidget {
  const TouchTestScreen({super.key});

  @override
  State<TouchTestScreen> createState() => _TouchTestScreenState();
}

class _TouchTestScreenState extends State<TouchTestScreen> {
  static const int _cols = 6;
  static const int _rows = 10;
  static const int _maxTrailPoints = 300;
  static const List<Color> _palette = [
    Colors.redAccent,
    Colors.lightBlueAccent,
    Colors.greenAccent,
    Colors.orangeAccent,
    Colors.purpleAccent,
    Colors.yellowAccent,
    Colors.tealAccent,
    Colors.pinkAccent,
    Colors.limeAccent,
    Colors.cyanAccent,
  ];

  _TouchMode _mode = _TouchMode.trail;

  final Map<int, List<Offset>> _trails = <int, List<Offset>>{};
  final Map<int, Offset> _active = <int, Offset>{};
  int _maxTouches = 0;
  Offset? _last;
  double _pressure = 0;

  final Set<int> _cells = <int>{};
  Size _area = Size.zero;

  void _reset() {
    setState(() {
      _trails.clear();
      _active.clear();
      _maxTouches = 0;
      _last = null;
      _pressure = 0;
      _cells.clear();
    });
  }

  void _markCell(Offset pos) {
    if (_area.width <= 0 || _area.height <= 0) return;
    final int col = (pos.dx / _area.width * _cols).floor().clamp(0, _cols - 1).toInt();
    final int row = (pos.dy / _area.height * _rows).floor().clamp(0, _rows - 1).toInt();
    _cells.add(row * _cols + col);
  }

  void _onDown(PointerDownEvent e) {
    setState(() {
      _active[e.pointer] = e.localPosition;
      _trails[e.pointer] = <Offset>[e.localPosition];
      if (_active.length > _maxTouches) _maxTouches = _active.length;
      _last = e.localPosition;
      _pressure = e.pressure;
      _markCell(e.localPosition);
    });
  }

  void _onMove(PointerMoveEvent e) {
    setState(() {
      _active[e.pointer] = e.localPosition;
      final trail = _trails.putIfAbsent(e.pointer, () => <Offset>[]);
      trail.add(e.localPosition);
      if (trail.length > _maxTrailPoints) {
        trail.removeAt(0);
      }
      _last = e.localPosition;
      _pressure = e.pressure;
      _markCell(e.localPosition);
    });
  }

  void _onUp(PointerEvent e) {
    setState(() {
      _active.remove(e.pointer);
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final int total = _cols * _rows;
    final int covered = _cells.length;
    final int percent = (covered * 100 / total).floor();
    final bool allCovered = covered >= total;

    final String lastText = _last == null
        ? '-'
        : '${_last!.dx.toStringAsFixed(0)}, ${_last!.dy.toStringAsFixed(0)}';

    return Scaffold(
      appBar: NexusProAppBar(
        title: 'Tes Touch',
        subtitle: 'Cek multi-touch dan area layar',
        actions: [
          IconButton(
            tooltip: 'Reset',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _reset,
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
              AppSpacing.md,
              AppSpacing.xs,
              AppSpacing.md,
              AppSpacing.xs,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: AppSpacing.xs,
                  children: [
                    ChoiceChip(
                      label: const Text('Jejak'),
                      selected: _mode == _TouchMode.trail,
                      onSelected: (_) => setState(() => _mode = _TouchMode.trail),
                    ),
                    ChoiceChip(
                      label: const Text('Grid'),
                      selected: _mode == _TouchMode.grid,
                      onSelected: (_) => setState(() => _mode = _TouchMode.grid),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.xs),
                if (_mode == _TouchMode.trail)
                  Text(
                    'Sentuhan: ${_active.length}  •  Maks sekaligus: $_maxTouches\n'
                    'Posisi terakhir: $lastText  •  Tekanan: ${_pressure.toStringAsFixed(2)}',
                    style: theme.textTheme.bodySmall?.copyWith(height: 1.4),
                  )
                else
                  Text(
                    allCovered
                        ? 'Semua area layar responsif!'
                        : 'Tercakup: $percent% ($covered/$total kotak). Usap seluruh layar sampai hijau semua.',
                    style: theme.textTheme.bodySmall?.copyWith(
                      height: 1.4,
                      color: allCovered ? Colors.green : null,
                      fontWeight: allCovered ? FontWeight.w700 : null,
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.xs,
                0,
                AppSpacing.xs,
                AppSpacing.xs,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: scheme.surfaceContainerHighest.withOpacity(0.35),
                    border: Border.all(color: scheme.outlineVariant),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      _area = Size(constraints.maxWidth, constraints.maxHeight);
                      return Listener(
                        behavior: HitTestBehavior.opaque,
                        onPointerDown: _onDown,
                        onPointerMove: _onMove,
                        onPointerUp: _onUp,
                        onPointerCancel: _onUp,
                        child: SizedBox.expand(
                          child: CustomPaint(
                            painter: _mode == _TouchMode.trail
                                ? _TrailPainter(
                                    trails: _trails,
                                    active: _active,
                                    palette: _palette,
                                  )
                                : _GridPainter(
                                    cells: _cells,
                                    cols: _cols,
                                    rows: _rows,
                                    lineColor: scheme.outlineVariant,
                                    fillColor: Colors.green.withOpacity(0.55),
                                  ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TrailPainter extends CustomPainter {
  _TrailPainter({required this.trails, required this.active, required this.palette});

  final Map<int, List<Offset>> trails;
  final Map<int, Offset> active;
  final List<Color> palette;

  @override
  void paint(Canvas canvas, Size size) {
    trails.forEach((pointer, points) {
      if (points.isEmpty) return;
      final color = palette[pointer % palette.length];
      final linePaint = Paint()
        ..color = color
        ..strokeWidth = 5
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;
      if (points.length > 1) {
        final path = Path()..moveTo(points.first.dx, points.first.dy);
        for (int i = 1; i < points.length; i++) {
          path.lineTo(points[i].dx, points[i].dy);
        }
        canvas.drawPath(path, linePaint);
      }
    });

    active.forEach((pointer, pos) {
      final color = palette[pointer % palette.length];
      canvas.drawCircle(pos, 34, Paint()..color = color.withOpacity(0.25));
      canvas.drawCircle(pos, 18, Paint()..color = color);
    });
  }

  @override
  bool shouldRepaint(covariant _TrailPainter oldDelegate) => true;
}

class _GridPainter extends CustomPainter {
  _GridPainter({
    required this.cells,
    required this.cols,
    required this.rows,
    required this.lineColor,
    required this.fillColor,
  });

  final Set<int> cells;
  final int cols;
  final int rows;
  final Color lineColor;
  final Color fillColor;

  @override
  void paint(Canvas canvas, Size size) {
    final double cw = size.width / cols;
    final double ch = size.height / rows;
    final fill = Paint()..color = fillColor;
    for (final index in cells) {
      final int row = index ~/ cols;
      final int col = index % cols;
      canvas.drawRect(Rect.fromLTWH(col * cw, row * ch, cw, ch), fill);
    }

    final line = Paint()
      ..color = lineColor
      ..strokeWidth = 1;
    for (int c = 1; c < cols; c++) {
      canvas.drawLine(Offset(c * cw, 0), Offset(c * cw, size.height), line);
    }
    for (int r = 1; r < rows; r++) {
      canvas.drawLine(Offset(0, r * ch), Offset(size.width, r * ch), line);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter oldDelegate) => true;
}
