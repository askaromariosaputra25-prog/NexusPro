import 'package:flutter/services.dart';

/// Result of a native action: did it work, and a message the user can read.
class ToolResult {
  const ToolResult(this.ok, this.message);

  final bool ok;
  final String message;
}

/// Dart side of SystemToolsChannel.kt (Permission Center and Quick Settings).
///
/// Every call is defensive: a missing or failing native side returns a safe
/// default instead of throwing.
class SystemToolsBridge {
  const SystemToolsBridge();

  static const MethodChannel _channel = MethodChannel('com.nexuspro.optimization/system_tools');

  Future<ToolResult> _result(String method, [Object? arguments]) async {
    try {
      final map = await _channel.invokeMapMethod<String, dynamic>(method, arguments);
      if (map == null) return const ToolResult(false, 'Tidak ada respons dari sistem.');
      return ToolResult(map['ok'] == true, (map['message'] as String?) ?? '');
    } on PlatformException catch (e) {
      return ToolResult(false, e.message ?? 'Terjadi kesalahan.');
    } on MissingPluginException {
      return const ToolResult(false, 'Fitur ini hanya tersedia di Android.');
    }
  }

  /// Status of every permission the app can use. Missing keys mean "unknown".
  Future<Map<String, bool>> getPermissions() async {
    try {
      final map = await _channel.invokeMapMethod<String, dynamic>('getPermissions');
      if (map == null) return <String, bool>{};
      return map.map((k, v) => MapEntry(k, v == true));
    } on PlatformException {
      return <String, bool>{};
    } on MissingPluginException {
      return <String, bool>{};
    }
  }

  /// Opens the system page for [target]: overlay, usageAccess, writeSettings,
  /// dnd, battery, notifications, autostart or appDetails.
  Future<bool> open(String target) async {
    try {
      final r = await _channel.invokeMethod<bool>('open', <String, dynamic>{'target': target});
      return r ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  /// Self-grants WRITE_SECURE_SETTINGS through Shizuku or root.
  Future<ToolResult> grantSecureSettings() => _result('grantSecureSettings');

  /// Current state of each quick toggle. A null value means the phone does not expose it.
  Future<Map<String, bool?>> getToggles() async {
    try {
      final map = await _channel.invokeMapMethod<String, dynamic>('getToggles');
      if (map == null) return <String, bool?>{};
      return map.map((k, v) => MapEntry(k, v is bool ? v : null));
    } on PlatformException {
      return <String, bool?>{};
    } on MissingPluginException {
      return <String, bool?>{};
    }
  }

  Future<ToolResult> setToggle(String id, bool enabled) =>
      _result('setToggle', <String, dynamic>{'id': id, 'enabled': enabled});

  /// brightness (1..255), timeoutMs and autoBrightness; null when unreadable.
  Future<Map<String, dynamic>> getDisplay() async {
    try {
      final map = await _channel.invokeMapMethod<String, dynamic>('getDisplay');
      return map ?? <String, dynamic>{};
    } on PlatformException {
      return <String, dynamic>{};
    } on MissingPluginException {
      return <String, dynamic>{};
    }
  }

  Future<ToolResult> setBrightness(int value) =>
      _result('setBrightness', <String, dynamic>{'value': value});

  Future<ToolResult> setScreenTimeout(int ms) =>
      _result('setScreenTimeout', <String, dynamic>{'ms': ms});
}
