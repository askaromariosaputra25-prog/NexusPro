import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../core/audio/voice.dart';
import '../../../../core/routing/route_names.dart';
import '../../../tools/data/system_tools_bridge.dart';

class _Perm {
  const _Perm({
    required this.id,
    required this.target,
    required this.icon,
    required this.title,
    required this.why,
    this.required = true,
    this.hint,
    this.button = 'Izinkan',
  });

  final String id;
  final String target;
  final IconData icon;
  final String title;
  final String why;
  final bool required;
  final String? hint;
  final String button;
}

/// Shown after the loading screen on the first run: asks for every permission
/// NexusPro needs, one after another, and tells the user why each one matters.
class PermissionSetupScreen extends StatefulWidget {
  const PermissionSetupScreen({super.key});

  /// SharedPreferences key: true once the user finished (or skipped) this screen.
  static const String doneKey = 'permission_setup_done_v1';

  @override
  State<PermissionSetupScreen> createState() => _PermissionSetupScreenState();
}

class _PermissionSetupScreenState extends State<PermissionSetupScreen> with WidgetsBindingObserver {
  static const Color _bg = Color(0xFF05080F);
  static const Color _card = Color(0xFF0E1522);
  static const Color _border = Color(0xFF1B2638);
  static const Color _muted = Color(0xFF8FA3BF);
  static const Color _cyan = Color(0xFF00E5FF);
  static const Color _green = Color(0xFF2ECC71);

  static const List<_Perm> _perms = <_Perm>[
    _Perm(
      id: 'notifications',
      target: 'notifications',
      icon: Icons.notifications_active_rounded,
      title: 'Notifikasi',
      why: 'Game Mode berjalan di latar belakang dan bisa kamu matikan dari notifikasinya.',
    ),
    _Perm(
      id: 'overlay',
      target: 'overlay',
      icon: Icons.layers_rounded,
      title: 'Tampil di atas aplikasi lain',
      why: 'Wajib. Tanpa ini bubble dan panel tidak bisa muncul di atas game.',
    ),
    _Perm(
      id: 'usageAccess',
      target: 'usageAccess',
      icon: Icons.query_stats_rounded,
      title: 'Akses penggunaan aplikasi',
      why: 'Supaya NexusPro tahu game mana yang sedang terbuka dan bubble hilang saat kamu keluar.',
    ),
    _Perm(
      id: 'accessibility',
      target: 'accessibility',
      icon: Icons.accessibility_new_rounded,
      title: 'Aksesibilitas (NexusPro Game Detector)',
      why: 'Mendeteksi game seketika dan dipakai tombol Screenshot. Tidak membaca isi layar.',
      hint: 'Kalau tombolnya abu-abu (Android 13 ke atas, APK di luar Play Store): buka Info aplikasi, '
          'ketuk titik tiga di pojok kanan atas, pilih "Izinkan pengaturan terbatas", lalu coba lagi.',
    ),
    _Perm(
      id: 'writeSettings',
      target: 'writeSettings',
      icon: Icons.tune_rounded,
      title: 'Ubah pengaturan sistem',
      why: 'Untuk slider Kecerahan dan Kunci rotasi di panel Game Mode.',
    ),
    _Perm(
      id: 'dnd',
      target: 'dnd',
      icon: Icons.do_not_disturb_on_rounded,
      title: 'Jangan ganggu',
      why: 'Supaya tombol DND di panel bisa menahan notifikasi saat kamu main.',
    ),
    _Perm(
      id: 'battery',
      target: 'battery',
      icon: Icons.battery_charging_full_rounded,
      title: 'Abaikan optimasi baterai',
      why: 'Mencegah sistem mematikan bubble saat game berat berjalan.',
    ),
    _Perm(
      id: 'autostart',
      target: 'autostart',
      icon: Icons.play_circle_outline_rounded,
      title: 'Mulai otomatis (HP Oppo, Xiaomi, Vivo)',
      why: 'Di sebagian HP ini mencegah NexusPro dimatikan saat aplikasi dibersihkan dari recent.',
      required: false,
      button: 'Buka',
    ),
  ];

  final SystemToolsBridge _bridge = const SystemToolsBridge();

  Map<String, bool> _status = <String, bool>{};
  final Set<String> _tapped = <String>{};
  final Map<String, int> _attempts = <String, int>{};
  bool _flow = false;
  bool _loading = true;
  DateTime _lastOpen = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
    Voice.speak('Sebelum mulai, izinkan semua akses supaya bubble Game Mode bisa bekerja di dalam game.');
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    Voice.stop();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) unawaited(_afterReturn());
  }

  Future<void> _refresh() async {
    final status = await _bridge.getPermissions();
    if (!mounted) return;
    setState(() {
      _status = status;
      _loading = false;
    });
  }

  bool _isDone(_Perm p) => p.id == 'autostart' ? _tapped.contains(p.id) : _status[p.id] == true;

  int get _requiredTotal => _perms.where((p) => p.required).length;
  int get _requiredDone => _perms.where((p) => p.required && _isDone(p)).length;
  bool get _allRequiredDone => _requiredDone == _requiredTotal;

  Future<void> _afterReturn() async {
    await _refresh();
    if (_flow && mounted) {
      await Future<void>.delayed(const Duration(milliseconds: 500));
      if (mounted && _flow) await _next();
    }
  }

  /// Opens the system page for the next permission that is still missing.
  Future<void> _next() async {
    if (DateTime.now().difference(_lastOpen) < const Duration(milliseconds: 900)) return;
    final missing = _perms
        .where((p) => p.required && !_isDone(p) && (_attempts[p.id] ?? 0) < 2)
        .toList();
    if (missing.isEmpty) {
      if (mounted) setState(() => _flow = false);
      if (!_allRequiredDone && mounted) {
        _snack('Beberapa izin belum aktif. Ketuk "Izinkan" pada izin yang masih kosong.');
      }
      return;
    }
    await _open(missing.first);
  }

  Future<void> _open(_Perm p) async {
    _lastOpen = DateTime.now();
    _attempts[p.id] = (_attempts[p.id] ?? 0) + 1;
    if (p.id == 'autostart') _tapped.add(p.id);
    await _bridge.open(p.target);
    if (p.id == 'notifications') {
      // The notification permission is a pop-up, not a settings page: check again shortly.
      await Future<void>.delayed(const Duration(milliseconds: 1500));
      await _refresh();
      if (_flow && mounted) await _next();
    }
  }

  Future<void> _grantAll() async {
    setState(() {
      _flow = true;
      _attempts.clear();
    });
    await _next();
  }

  Future<void> _finish() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(PermissionSetupScreen.doneKey, true);
    } catch (_) {
      // Not saving only means the screen can appear once more.
    }
    unawaited(Voice.stop());
    if (!mounted) return;
    context.go(RouteNames.home);
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    final done = _requiredDone;
    final total = _requiredTotal;
    final ready = _allRequiredDone;

    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(color: _cyan.withOpacity(0.35), blurRadius: 18),
                      ],
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/images/nexus_logo.png',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) =>
                            const Icon(Icons.bolt_rounded, color: Colors.white, size: 28),
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Izinkan semua akses',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '$done dari $total izin wajib aktif',
                          style: const TextStyle(color: _muted, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: total == 0 ? 0 : done / total,
                  minHeight: 6,
                  backgroundColor: const Color(0xFF16202E),
                  valueColor: const AlwaysStoppedAnimation<Color>(_cyan),
                ),
              ),
            ),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                      children: [
                        for (final p in _perms) _buildTile(p),
                        _buildShizukuTile(),
                      ],
                    ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: ready ? _green : const Color(0xFF1E88E5),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: ready ? _finish : _grantAll,
                      child: Text(
                        ready
                            ? 'Masuk NexusPro'
                            : (_flow ? 'Mengikuti satu per satu...' : 'Izinkan semua'),
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                  if (!ready)
                    TextButton(
                      onPressed: _finish,
                      child: const Text(
                        'Lewati dulu (bubble mungkin tidak bisa muncul)',
                        style: TextStyle(color: _muted, fontSize: 12),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTile(_Perm p) {
    final ok = _isDone(p);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ok ? _green.withOpacity(0.5) : _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: (ok ? _green : _cyan).withOpacity(0.14),
                ),
                child: Icon(p.icon, color: ok ? _green : _cyan, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(p.why, style: const TextStyle(color: _muted, fontSize: 12, height: 1.35)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              if (ok && p.id != 'autostart')
                const Icon(Icons.check_circle_rounded, color: _green)
              else
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _cyan,
                    side: const BorderSide(color: _cyan),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                  ),
                  onPressed: () => _open(p),
                  child: Text(p.button),
                ),
            ],
          ),
          if (!ok && p.hint != null) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFF16202E),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.info_outline_rounded, color: _cyan, size: 16),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      p.hint!,
                      style: const TextStyle(color: _muted, fontSize: 11.5, height: 1.35),
                    ),
                  ),
                  TextButton(
                    onPressed: () => _bridge.open('appDetails'),
                    child: const Text('Info aplikasi', style: TextStyle(fontSize: 11)),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  /// Optional: Shizuku unlocks real FPS, CPU and GPU numbers and full cache cleaning.
  Widget _buildShizukuTile() {
    final ok = _status['shizukuGranted'] == true;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ok ? _green.withOpacity(0.5) : _border),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: (ok ? _green : _cyan).withOpacity(0.14),
            ),
            child: Icon(Icons.bolt_rounded, color: ok ? _green : _cyan, size: 22),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Shizuku (opsional)',
                  style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 3),
                Text(
                  'Membuka FPS, CPU, GPU asli di panel, dan bersihkan cache semua aplikasi.',
                  style: TextStyle(color: _muted, fontSize: 12, height: 1.35),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          if (ok)
            const Icon(Icons.check_circle_rounded, color: _green)
          else
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                foregroundColor: _cyan,
                side: const BorderSide(color: _cyan),
                padding: const EdgeInsets.symmetric(horizontal: 12),
              ),
              onPressed: () => context.push(RouteNames.toolPermissions),
              child: const Text('Atur'),
            ),
        ],
      ),
    );
  }
}
