import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/audio/voice.dart';
import '../../../../core/routing/route_names.dart';
import '../../../../core/theme/tokens/app_radius.dart';
import '../../../../core/theme/tokens/app_spacing.dart';
import '../providers/onboarding_provider.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  static const List<String> _voice = <String>[
    'Selamat datang di Nexus Pro. Optimasi performa presisi untuk HP Android kamu. Ada profil Balanced, Extreme, dan Battery, semuanya transparan.',
    'Laboratorium gaming. Atur FPS, respons sentuhan, dan memori untuk setiap game, lalu luncurkan dengan sekali ketuk.',
    'Diagnostik dan keamanan. Pantau CPU, penyimpanan, dan jaringan, dengan cadangan untuk setiap tweak. Ayo mulai!',
  ];

  @override
  void initState() {
    super.initState();
    Voice.speak(_voice[0]);
  }

  final List<_OnboardingPageData> _pages = const [
    _OnboardingPageData(
      badge: 'DEVICE ENGINE',
      title: 'Optimasi Performa\nPresisi',
      description:
          'Kendalikan hardware Android kamu dengan tuning proses latar belakang yang aman, dirancang untuk respons maksimal.',
      icon: Icons.tune_rounded,
      accentColor: Color(0xFF1E56DE),
      bulletPoints: [
        'Profil Balanced, Extreme, dan Battery',
        'Transparan, tanpa trik tersembunyi',
        'Terhubung dengan Shizuku',
      ],
    ),
    _OnboardingPageData(
      badge: 'GAMING LAB',
      title: 'Preset Per Game &\nLuncurkan Instan',
      description:
          'Atur FPS, respons sentuhan, dan prioritas memori untuk tiap game, lalu luncurkan langsung dengan pengaturan optimal.',
      icon: Icons.sports_esports_rounded,
      accentColor: Color(0xFF10B981),
      bulletPoints: [
        'Deteksi game otomatis dan tambah manual',
        'Statistik peluncuran dan waktu bermain',
        'Boost satu ketukan dari beranda',
      ],
    ),
    _OnboardingPageData(
      badge: 'LABORATORY SAFETY',
      title: 'Diagnostik, Keamanan\n& Kontrol Penuh',
      description:
          'Pantau frekuensi CPU, kesehatan penyimpanan, dan latensi jaringan, dengan cadangan dan pemulihan untuk setiap tweak.',
      icon: Icons.security_rounded,
      accentColor: Color(0xFF6366F1),
      bulletPoints: [
        'Telemetri hardware langsung dan pembersih penyimpanan',
        'Optimasi otomatis terjadwal',
        'Ekspor dan pulihkan cadangan kapan saja',
      ],
    ),
  ];

  void _onNext() {
    if (_currentPage < _pages.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeInOutCubic,
      );
    } else {
      _finishOnboarding();
    }
  }

  void _finishOnboarding() {
    Voice.stop();
    ref.read(onboardingProvider.notifier).completeOnboarding();
    context.go(RouteNames.home);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLastPage = _currentPage == _pages.length - 1;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // Top action bar
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.md,
                vertical: AppSpacing.sm,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.primaryContainer,
                          borderRadius: BorderRadius.circular(AppRadius.xs),
                        ),
                        child: Text(
                          'NEXUSPRO LAB',
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: theme.colorScheme.onPrimaryContainer,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ),
                    ],
                  ),
                  TextButton(
                    onPressed: _finishOnboarding,
                    child: Text(
                      'Lewati',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Page carousel
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                itemCount: _pages.length,
                onPageChanged: (index) {
                  setState(() => _currentPage = index);
                  Voice.speak(_voice[index]);
                },
                itemBuilder: (context, index) {
                  final page = _pages[index];
                  return _OnboardingSlide(page: page);
                },
              ),
            ),

            // Bottom controls: Indicator + Continue button
            Padding(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Indicators
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(_pages.length, (index) {
                      final isActive = index == _currentPage;
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: isActive ? 28 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: isActive
                              ? theme.colorScheme.primary
                              : theme.colorScheme.outlineVariant,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      );
                    }),
                  ),
                  const SizedBox(height: AppSpacing.lg),

                  // Button
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: FilledButton(
                      onPressed: _onNext,
                      style: FilledButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppRadius.md),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            isLastPage ? 'Mulai' : 'Lanjut',
                            style: theme.textTheme.titleSmall?.copyWith(
                              color: theme.colorScheme.onPrimary,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5,
                            ),
                          ),
                          const SizedBox(width: AppSpacing.xs),
                          Icon(
                            isLastPage ? Icons.rocket_launch_rounded : Icons.arrow_forward_rounded,
                            size: 18,
                            color: theme.colorScheme.onPrimary,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnboardingPageData {
  const _OnboardingPageData({
    required this.badge,
    required this.title,
    required this.description,
    required this.icon,
    required this.accentColor,
    required this.bulletPoints,
  });

  final String badge;
  final String title;
  final String description;
  final IconData icon;
  final Color accentColor;
  final List<String> bulletPoints;
}

class _OnboardingSlide extends StatelessWidget {
  const _OnboardingSlide({required this.page});

  final _OnboardingPageData page;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // Scrolls on short screens / large text, stays centred when it fits.
    return LayoutBuilder(
      builder: (context, constraints) => SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
        child: ConstrainedBox(
          constraints: BoxConstraints(minHeight: constraints.maxHeight),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Graphic hero icon container
              Container(
                width: 110,
                height: 110,
                decoration: BoxDecoration(
                  color: page.accentColor.withAlpha(30),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: page.accentColor.withAlpha(60),
                    width: 2,
                  ),
                ),
                child: Icon(
                  page.icon,
                  size: 52,
                  color: page.accentColor,
                ),
              ),
              const SizedBox(height: AppSpacing.xl),

              // Category badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerHigh,
                  borderRadius: BorderRadius.circular(AppRadius.xs),
                  border: Border.all(color: theme.colorScheme.outlineVariant),
                ),
                child: Text(
                  page.badge,
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: page.accentColor,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.1,
                  ),
                ),
              ),
              const SizedBox(height: AppSpacing.sm),

              // Title
              Text(
                page.title,
                textAlign: TextAlign.center,
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.5,
                  height: 1.25,
                ),
              ),
              const SizedBox(height: AppSpacing.md),

              // Description
              Text(
                page.description,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                  height: 1.45,
                ),
              ),
              const SizedBox(height: AppSpacing.lg),

              // Bullet feature cards
              Container(
                padding: const EdgeInsets.all(AppSpacing.md),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerLowest,
                  borderRadius: BorderRadius.circular(AppRadius.md),
                  border: Border.all(color: theme.colorScheme.outlineVariant),
                ),
                child: Column(
                  children: page.bulletPoints.map((point) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: [
                          Icon(
                            Icons.check_circle_rounded,
                            size: 16,
                            color: page.accentColor,
                          ),
                          const SizedBox(width: AppSpacing.sm),
                          Expanded(
                            child: Text(
                              point,
                              style: theme.textTheme.bodySmall?.copyWith(
                                fontWeight: FontWeight.w500,
                                color: theme.colorScheme.onSurface,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
