import 'package:flutter/services.dart';

/// Which values the overlay panel shows in its status block.
class OverlayOptions {
  const OverlayOptions({this.ram = true, this.battery = true, this.temp = true});

  final bool ram;
  final bool battery;
  final bool temp;

  OverlayOptions copyWith({bool? ram, bool? battery, bool? temp}) => OverlayOptions(
        ram: ram ?? this.ram,
        battery: battery ?? this.battery,
        temp: temp ?? this.temp,
      );
}

/// Dart side of the native Game Mode overlay (see OverlayChannel.kt).
///
/// Every call is defensive: when the native side is missing or throws, the
/// call returns a safe default instead of crashing the screen.
class OverlayBridge {
  const OverlayBridge();

  static const MethodChannel _channel = MethodChannel('com.nexuspro.optimization/overlay');
  static const MethodChannel _games = MethodChannel('com.nexuspro.optimization/game_discovery');

  Future<bool> _bool(String method, [Object? arguments]) async {
    try {
      final result = await _channel.invokeMethod<bool>(method, arguments);
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  /// "Display over other apps" permission granted?
  Future<bool> hasPermission() => _bool('hasPermission');

  /// Opens the system page where the user grants the overlay permission.
  Future<bool> requestPermission() => _bool('requestPermission');

  Future<bool> isRunning() => _bool('isRunning');

  /// Starts the overlay. Returns false when the permission is missing.
  Future<bool> start() => _bool('start');

  Future<bool> stop() => _bool('stop');

  Future<bool> hasDndAccess() => _bool('hasDndAccess');

  Future<bool> openDndSettings() => _bool('openDndSettings');

  Future<bool> setQuickApps(List<String> packages) =>
      _bool('setQuickApps', <String, dynamic>{'packages': packages});

  Future<List<String>> getQuickApps() async {
    try {
      final result = await _channel.invokeListMethod<String>('getQuickApps');
      return result ?? <String>[];
    } on PlatformException {
      return <String>[];
    } on MissingPluginException {
      return <String>[];
    }
  }

  Future<bool> setOptions(OverlayOptions options) => _bool('setOptions', <String, dynamic>{
        'ram': options.ram,
        'battery': options.battery,
        'temp': options.temp,
      });

  Future<OverlayOptions> getOptions() async {
    try {
      final map = await _channel.invokeMapMethod<String, dynamic>('getOptions');
      if (map == null) return const OverlayOptions();
      return OverlayOptions(
        ram: map['ram'] != false,
        battery: map['battery'] != false,
        temp: map['temp'] != false,
      );
    } on PlatformException {
      return const OverlayOptions();
    } on MissingPluginException {
      return const OverlayOptions();
    }
  }

  /// Opens another app by package name (same call the Games tab uses).
  Future<bool> launchApp(String packageName) async {
    try {
      final result = await _games.invokeMethod<bool>(
        'launchApp',
        <String, dynamic>{'packageName': packageName},
      );
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }
}
