import 'package:flutter/services.dart';

/// Which values the overlay panel shows in its status block.
class OverlayOptions {
  const OverlayOptions({
    this.ram = true,
    this.battery = true,
    this.temp = true,
    this.auto = true,
    this.boot = false,
  });

  final bool ram;
  final bool battery;
  final bool temp;

  /// Show the bubble only while one of the user's games is in the foreground.
  final bool auto;

  /// Start the overlay again after the phone reboots.
  final bool boot;

  OverlayOptions copyWith({bool? ram, bool? battery, bool? temp, bool? auto, bool? boot}) =>
      OverlayOptions(
        ram: ram ?? this.ram,
        battery: battery ?? this.battery,
        temp: temp ?? this.temp,
        auto: auto ?? this.auto,
        boot: boot ?? this.boot,
      );
}

/// Dart side of the native Game Mode overlay (see OverlayChannel.kt).
///
/// Every call is defensive: when the native side is missing or throws, the
/// call returns a safe default instead of crashing the screen.
class OverlayBridge {
  const OverlayBridge();

  static const MethodChannel _channel = MethodChannel('com.nexuspro.optimization/overlay');
  static const MethodChannel _games = MethodChannel('com.nexuspro.optimization/game_discovery');

  Future<bool> _bool(String method, [Object? arguments]) async {
    try {
      final result = await _channel.invokeMethod<bool>(method, arguments);
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  /// "Display over other apps" permission granted?
  Future<bool> hasPermission() => _bool('hasPermission');

  /// Opens the system page where the user grants the overlay permission.
  Future<bool> requestPermission() => _bool('requestPermission');

  Future<bool> isRunning() => _bool('isRunning');

  /// Starts the overlay. Returns false when the permission is missing.
  Future<bool> start() => _bool('start');

  Future<bool> stop() => _bool('stop');

  Future<bool> hasDndAccess() => _bool('hasDndAccess');

  Future<bool> openDndSettings() => _bool('openDndSettings');

  Future<bool> setQuickApps(List<String> packages) =>
      _bool('setQuickApps', <String, dynamic>{'packages': packages});

  Future<List<String>> getQuickApps() async {
    try {
      final result = await _channel.invokeListMethod<String>('getQuickApps');
      return result ?? <String>[];
    } on PlatformException {
      return <String>[];
    } on MissingPluginException {
      return <String>[];
    }
  }

  Future<bool> setOptions(OverlayOptions options) => _bool('setOptions', <String, dynamic>{
        'ram': options.ram,
        'battery': options.battery,
        'temp': options.temp,
        'auto': options.auto,
        'boot': options.boot,
      });

  /// Tells the overlay which packages count as "games" for auto show.
  /// Never throws (it is also called from background providers and tests).
  Future<bool> setGamePackages(List<String> packages) async {
    try {
      return await _bool('setGamePackages', <String, dynamic>{'packages': packages});
    } catch (_) {
      return false;
    }
  }

  Future<bool> hasUsageAccess() => _bool('hasUsageAccess');

  Future<bool> openUsageAccess() => _bool('openUsageAccess');

  /// Accessibility service ("NexusPro Game Detector") enabled? It detects games instantly
  /// and starts the overlay by itself when a game opens.
  Future<bool> hasAccessibility() => _bool('hasAccessibility');

  Future<bool> openAccessibility() => _bool('openAccessibility');

  /// Marks [packageName] as a game (or not) by hand, on top of automatic detection.
  Future<bool> markGame(String packageName, {bool game = true}) =>
      _bool('markGame', <String, dynamic>{'package': packageName, 'game': game});

  /// Live detection info for the diagnostics card:
  /// running, package, label, isGame, source.
  Future<Map<String, dynamic>> getForeground() async {
    try {
      final map = await _channel.invokeMapMethod<String, dynamic>('getForeground');
      return map ?? <String, dynamic>{};
    } on PlatformException {
      return <String, dynamic>{};
    } on MissingPluginException {
      return <String, dynamic>{};
    }
  }

  Future<OverlayOptions> getOptions() async {
    try {
      final map = await _channel.invokeMapMethod<String, dynamic>('getOptions');
      if (map == null) return const OverlayOptions();
      return OverlayOptions(
        ram: map['ram'] != false,
        battery: map['battery'] != false,
        temp: map['temp'] != false,
        auto: map['auto'] != false,
        boot: map['boot'] == true,
      );
    } on PlatformException {
      return const OverlayOptions();
    } on MissingPluginException {
      return const OverlayOptions();
    }
  }

  /// Opens another app by package name (same call the Games tab uses).
  Future<bool> launchApp(String packageName) async {
    try {
      final result = await _games.invokeMethod<bool>(
        'launchApp',
        <String, dynamic>{'packageName': packageName},
      );
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }
}
