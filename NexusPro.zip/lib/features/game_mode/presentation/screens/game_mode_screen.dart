import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/tokens/app_radius.dart';
import '../../../../core/theme/tokens/app_spacing.dart';
import '../../../../shared/widgets/app_bars/nexuspro_app_bar.dart';
import '../../../../shared/widgets/section_header.dart';
import '../../../games/domain/entities/game_entity.dart';
import '../../../games/presentation/providers/game_library_provider.dart';
import '../../../games/presentation/widgets/add_game_sheet.dart';
import '../../data/overlay_bridge.dart';

/// Game Mode: a floating bubble over any game (system status, RAM boost,
/// cache cleaning, Do Not Disturb, quick-launch apps).
class GameModeScreen extends ConsumerStatefulWidget {
  const GameModeScreen({super.key});

  @override
  ConsumerState<GameModeScreen> createState() => _GameModeScreenState();
}

class _GameModeScreenState extends ConsumerState<GameModeScreen> with WidgetsBindingObserver {
  static const int _maxQuickApps = 8;

  final OverlayBridge _bridge = const OverlayBridge();

  bool _loading = true;
  bool _busy = false;
  bool _hasPermission = false;
  bool _running = false;
  bool _dndAccess = false;
  bool _usageAccess = false;
  OverlayOptions _options = const OverlayOptions();
  Set<String> _quick = <String>{};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // The user comes back from the system settings page: re-check permissions.
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    final permission = await _bridge.hasPermission();
    final running = await _bridge.isRunning();
    final dnd = await _bridge.hasDndAccess();
    final usage = await _bridge.hasUsageAccess();
    final options = await _bridge.getOptions();
    final quick = await _bridge.getQuickApps();
    if (!mounted) return;
    setState(() {
      _hasPermission = permission;
      _running = running;
      _dndAccess = dnd;
      _usageAccess = usage;
      _options = options;
      _quick = quick.toSet();
      _loading = false;
    });
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  Future<void> _toggleOverlay(bool on) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      if (on) {
        if (!_hasPermission) {
          await _bridge.requestPermission();
          _snack('Nyalakan izin "Tampil di atas aplikasi lain" untuk NexusPro, lalu kembali ke sini.');
        } else {
          final started = await _bridge.start();
          await Future<void>.delayed(const Duration(milliseconds: 700));
          final running = await _bridge.isRunning();
          if (!mounted) return;
          setState(() => _running = running);
          if (!started || !running) {
            _snack('Overlay gagal dijalankan. Coba lagi, atau cek izin overlay.');
          } else {
            _snack('Overlay aktif. Cari bubble "N" di layar, lalu ketuk untuk membuka panel.');
          }
        }
      } else {
        await _bridge.stop();
        await Future<void>.delayed(const Duration(milliseconds: 400));
        final running = await _bridge.isRunning();
        if (!mounted) return;
        setState(() => _running = running);
        _snack('Overlay dimatikan.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _setOptions(OverlayOptions options) async {
    setState(() => _options = options);
    await _bridge.setOptions(options);
  }

  Future<void> _toggleQuickApp(GameEntity game, bool selected) async {
    final next = Set<String>.from(_quick);
    if (selected) {
      if (next.length >= _maxQuickApps) {
        _snack('Maksimal $_maxQuickApps aplikasi cepat.');
        return;
      }
      next.add(game.packageName);
    } else {
      next.remove(game.packageName);
    }
    setState(() => _quick = next);
    await _bridge.setQuickApps(next.toList());
    if (_running) {
      _snack('Daftar aplikasi cepat diperbarui. Matikan lalu nyalakan overlay agar tampil di bubble.');
    }
  }

  Future<void> _launchWithOverlay(GameEntity game) async {
    if (_hasPermission && !_running) {
      await _bridge.start();
      await Future<void>.delayed(const Duration(milliseconds: 500));
      final running = await _bridge.isRunning();
      if (mounted) setState(() => _running = running);
    }
    final opened = await _bridge.launchApp(game.packageName);
    if (!opened) _snack('Aplikasi tidak bisa dibuka.');
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final gamesAsync = ref.watch(gameLibraryControllerProvider);

    return Scaffold(
      appBar: const NexusProAppBar(
        title: 'Game Mode',
        subtitle: 'Bubble mengambang di atas game',
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.only(bottom: AppSpacing.xl),
              children: [
                const SectionHeader(
                  title: 'Overlay',
                  subtitle: 'Nyalakan bubble, lalu buka game kamu.',
                  icon: Icons.layers_rounded,
                ),
                Padding(
                  padding: AppSpacing.screenPadding,
                  child: Card(
                    child: Column(
                      children: [
                        ListTile(
                          leading: Icon(
                            _hasPermission ? Icons.check_circle_rounded : Icons.error_outline_rounded,
                            color: _hasPermission ? Colors.green : theme.colorScheme.error,
                          ),
                          title: const Text(
                            'Izin tampil di atas aplikasi lain',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            _hasPermission
                                ? 'Sudah aktif.'
                                : 'Belum aktif. Wajib supaya bubble bisa muncul di atas game.',
                          ),
                          trailing: _hasPermission
                              ? null
                              : FilledButton(
                                  onPressed: _bridge.requestPermission,
                                  child: const Text('Aktifkan'),
                                ),
                        ),
                        const Divider(height: 1),
                        SwitchListTile(
                          value: _running,
                          onChanged: _busy ? null : _toggleOverlay,
                          title: const Text(
                            'Aktifkan overlay Game Mode',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            _running
                                ? 'Berjalan. Cari bubble "N" di layar (bisa digeser).'
                                : 'Mati. Nyalakan untuk menampilkan bubble.',
                          ),
                          secondary: const Icon(Icons.bubble_chart_rounded),
                        ),
                      ],
                    ),
                  ),
                ),
                const SectionHeader(
                  title: 'Perilaku',
                  subtitle: 'Kapan bubble muncul.',
                  icon: Icons.auto_mode_rounded,
                ),
                Padding(
                  padding: AppSpacing.screenPadding,
                  child: Card(
                    child: Column(
                      children: [
                        SwitchListTile(
                          value: _options.auto,
                          onChanged: (v) => _setOptions(_options.copyWith(auto: v)),
                          title: const Text('Muncul otomatis di dalam game'),
                          subtitle: const Text(
                            'Bubble hanya tampil saat game dari daftar kamu dibuka, '
                            'dan hilang saat kamu keluar. Matikan agar bubble selalu tampil.',
                          ),
                          secondary: const Icon(Icons.sports_esports_rounded),
                        ),
                        if (_options.auto && !_usageAccess) ...[
                          const Divider(height: 1),
                          ListTile(
                            leading: Icon(Icons.warning_amber_rounded, color: theme.colorScheme.error),
                            title: const Text(
                              'Butuh "Akses penggunaan aplikasi"',
                              style: TextStyle(fontWeight: FontWeight.w600),
                            ),
                            subtitle: const Text(
                              'Tanpa izin ini NexusPro tidak tahu game mana yang sedang dibuka, '
                              'jadi bubble tampil terus.',
                            ),
                            trailing: FilledButton(
                              onPressed: _bridge.openUsageAccess,
                              child: const Text('Aktifkan'),
                            ),
                          ),
                        ],
                        const Divider(height: 1),
                        SwitchListTile(
                          value: _options.boot,
                          onChanged: (v) => _setOptions(_options.copyWith(boot: v)),
                          title: const Text('Jalan otomatis setelah HP restart'),
                          subtitle: const Text('Overlay menyala sendiri saat HP dihidupkan.'),
                          secondary: const Icon(Icons.restart_alt_rounded),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(AppSpacing.md, AppSpacing.xs, AppSpacing.md, 0),
                  child: Text(
                    'Tidak muncul di game? Tambahkan game di bagian "Aplikasi cepat" di bawah '
                    'atau tab Games, izinkan semua izin di Tools > Pusat Izin, '
                    'dan di Oppo/Xiaomi/Vivo nyalakan "Mulai otomatis" untuk NexusPro.',
                    style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                  ),
                ),
                const SectionHeader(
                  title: 'Isi panel',
                  subtitle: 'Ketuk bubble untuk membuka panel. Pilih info yang mau ditampilkan.',
                  icon: Icons.dashboard_customize_outlined,
                ),
                Padding(
                  padding: AppSpacing.screenPadding,
                  child: Card(
                    child: Column(
                      children: [
                        SwitchListTile(
                          value: _options.ram,
                          onChanged: (v) => _setOptions(_options.copyWith(ram: v)),
                          title: const Text('Pemakaian RAM'),
                          subtitle: const Text('RAM terpakai dan total, dalam MB dan persen.'),
                          secondary: const Icon(Icons.memory_rounded),
                        ),
                        const Divider(height: 1),
                        SwitchListTile(
                          value: _options.battery,
                          onChanged: (v) => _setOptions(_options.copyWith(battery: v)),
                          title: const Text('Baterai'),
                          subtitle: const Text('Persen baterai dan status mengisi.'),
                          secondary: const Icon(Icons.battery_std_rounded),
                        ),
                        const Divider(height: 1),
                        SwitchListTile(
                          value: _options.temp,
                          onChanged: (v) => _setOptions(_options.copyWith(temp: v)),
                          title: const Text('Suhu baterai'),
                          subtitle: const Text('Pantau panas HP saat main game.'),
                          secondary: const Icon(Icons.thermostat_rounded),
                        ),
                        const Divider(height: 1),
                        const _FeatureRow(
                          icon: Icons.bolt_rounded,
                          title: 'Boost RAM',
                          text: 'Menutup aplikasi latar belakang. Hasil MB yang lega ditampilkan.',
                        ),
                        const _FeatureRow(
                          icon: Icons.cleaning_services_rounded,
                          title: 'Hapus cache',
                          text: 'Cache semua aplikasi dibersihkan kalau Shizuku aktif. Tanpa Shizuku, hanya cache NexusPro.',
                        ),
                        _FeatureRow(
                          icon: Icons.do_not_disturb_on_rounded,
                          title: 'Jangan ganggu (DND)',
                          text: _dndAccess
                              ? 'Izin sudah aktif. Tombol DND di panel bisa dipakai.'
                              : 'Butuh izin "Jangan ganggu". Ketuk tombol DND di panel untuk memberi izin.',
                          action: _dndAccess
                              ? null
                              : TextButton(
                                  onPressed: _bridge.openDndSettings,
                                  child: const Text('Beri izin'),
                                ),
                        ),
                      ],
                    ),
                  ),
                ),
                SectionHeader(
                  title: 'Aplikasi cepat',
                  subtitle: 'Maksimal $_maxQuickApps. Muncul sebagai ikon di panel bubble.',
                  icon: Icons.apps_rounded,
                  trailing: TextButton.icon(
                    onPressed: () => AddGameSheet.show(context),
                    icon: const Icon(Icons.add_rounded, size: 18),
                    label: const Text('Tambah'),
                  ),
                ),
                gamesAsync.when(
                  data: (games) => _buildGames(context, games),
                  loading: () => const Padding(
                    padding: EdgeInsets.all(AppSpacing.lg),
                    child: Center(child: CircularProgressIndicator()),
                  ),
                  error: (_, __) => const Padding(
                    padding: AppSpacing.screenPadding,
                    child: Text('Daftar game gagal dimuat. Coba buka tab Games dulu.'),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildGames(BuildContext context, List<GameEntity> games) {
    final theme = Theme.of(context);
    if (games.isEmpty) {
      return Padding(
        padding: AppSpacing.screenPadding,
        child: Card(
          child: Padding(
            padding: AppSpacing.cardPadding,
            child: Text(
              'Belum ada game di daftar. Ketuk "Tambah" untuk memilih game atau aplikasi.',
              style: theme.textTheme.bodyMedium,
            ),
          ),
        ),
      );
    }
    return Padding(
      padding: AppSpacing.screenPadding,
      child: Card(
        child: Column(
          children: [
            for (int i = 0; i < games.length; i++) ...[
              if (i > 0) const Divider(height: 1),
              _GameRow(
                game: games[i],
                selected: _quick.contains(games[i].packageName),
                onToggle: (v) => _toggleQuickApp(games[i], v),
                onPlay: () => _launchWithOverlay(games[i]),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _GameRow extends StatelessWidget {
  const _GameRow({
    required this.game,
    required this.selected,
    required this.onToggle,
    required this.onPlay,
  });

  final GameEntity game;
  final bool selected;
  final ValueChanged<bool> onToggle;
  final VoidCallback onPlay;

  @override
  Widget build(BuildContext context) {
    final bytes = game.iconBytes;
    return ListTile(
      leading: ClipRRect(
        borderRadius: AppRadius.radiusSm,
        child: bytes == null
            ? const SizedBox(width: 36, height: 36, child: Icon(Icons.sports_esports_rounded))
            : Image.memory(bytes, width: 36, height: 36, gaplessPlayback: true),
      ),
      title: Text(game.appName, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: const Text('Main + nyalakan overlay'),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            tooltip: 'Main dengan overlay',
            icon: const Icon(Icons.play_circle_fill_rounded),
            onPressed: onPlay,
          ),
          Switch(value: selected, onChanged: onToggle),
        ],
      ),
    );
  }
}

class _FeatureRow extends StatelessWidget {
  const _FeatureRow({
    required this.icon,
    required this.title,
    required this.text,
    this.action,
  });

  final IconData icon;
  final String title;
  final String text;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.xs),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: theme.colorScheme.primary),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(
                  text,
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
          if (action != null) action!,
        ],
      ),
    );
  }
}
