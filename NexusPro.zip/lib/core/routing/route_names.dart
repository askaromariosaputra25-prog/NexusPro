/// Route name constants for GoRouter.
///
/// Use these constants instead of raw strings throughout the codebase
/// to prevent typo-related navigation bugs.
library;

abstract final class RouteNames {
  RouteNames._();

  static const String home = '/';
  static const String games = '/games';
  static const String optimization = '/optimization';
  static const String performance = '/performance';
  static const String diagnostics = '/diagnostics';
  static const String settings = '/settings';
  static const String about = '/about';
  static const String network = '/network';
  static const String dataManagement = '/settings/data';
  static const String onboarding = '/onboarding';

  // Tools tab and full-screen tools (pushed outside the shell so tests use the whole screen).
  static const String tools = '/tools';
  static const String toolPing = '/tool-ping';
  static const String toolTouch = '/tool-touch';
  static const String toolGhost = '/tool-ghost';
  static const String toolScreen = '/tool-screen';
  static const String toolFps = '/tool-fps';
  static const String gameMode = '/game-mode';
  static const String toolPermissions = '/tool-permissions';
  static const String toolQuickSettings = '/tool-quick-settings';
}
