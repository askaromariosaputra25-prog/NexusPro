import 'dart:async';

import 'package:flutter/services.dart';

/// AI-style voice for the loading screen and tutorials.
///
/// Uses Android's built-in text-to-speech. Every call is safe: if the phone has
/// no speech engine, nothing happens and nothing throws.
class Voice {
  const Voice._();

  static const MethodChannel _channel = MethodChannel('com.nexuspro.optimization/speech');

  /// Turn the voice off for the current run (the tutorial mute button).
  static bool muted = false;

  static Completer<void>? _started;
  static bool _handlerSet = false;

  static void _ensureHandler() {
    if (_handlerSet) return;
    _handlerSet = true;
    _channel.setMethodCallHandler((call) async {
      if (call.method == 'started') {
        final c = _started;
        if (c != null && !c.isCompleted) c.complete();
      }
    });
  }

  /// Speaks and completes when the voice actually starts (or after [timeout]).
  /// The loading screen uses this so the logo appears exactly as the voice begins.
  static Future<void> speakAndWaitStart(
    String text, {
    String lang = 'id',
    double rate = 0.95,
    double pitch = 0.9,
    Duration timeout = const Duration(milliseconds: 1800),
  }) async {
    if (muted) return;
    _ensureHandler();
    final c = Completer<void>();
    _started = c;
    await speak(text, lang: lang, rate: rate, pitch: pitch);
    await c.future.timeout(timeout, onTimeout: () {});
  }

  /// [lang] is "id" (Indonesian) or "en". A lower pitch and slower rate give the
  /// calm "assistant" sound.
  static Future<void> speak(
    String text, {
    String lang = 'id',
    double rate = 0.95,
    double pitch = 0.9,
  }) async {
    if (muted || text.trim().isEmpty) return;
    try {
      await _channel.invokeMethod<bool>('speak', <String, dynamic>{
        'text': text,
        'lang': lang,
        'rate': rate,
        'pitch': pitch,
      });
    } on PlatformException {
      // No speech engine: stay silent.
    } on MissingPluginException {
      // Not running on Android (tests, web): stay silent.
    }
  }

  static Future<void> stop() async {
    try {
      await _channel.invokeMethod<bool>('stop');
    } on PlatformException {
      // ignore
    } on MissingPluginException {
      // ignore
    }
  }
}
