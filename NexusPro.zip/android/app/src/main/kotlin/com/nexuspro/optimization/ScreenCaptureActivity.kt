package com.nexuspro.optimization

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast

/**
 * Invisible activity that shows Android's "start recording" dialog on top of the game and
 * hands the result to [ScreenRecordService].
 */
class ScreenCaptureActivity : Activity() {

    private val requestCode = 4242

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mgr.createScreenCaptureIntent(), requestCode)
        } catch (t: Throwable) {
            Toast.makeText(this, "Perekam layar tidak didukung di HP ini", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ScreenRecordService::class.java)
                .setAction(ScreenRecordService.ACTION_START)
                .putExtra(ScreenRecordService.EXTRA_CODE, resultCode)
                .putExtra(ScreenRecordService.EXTRA_DATA, data)
            runCatching { startForegroundService(intent) }
        } else {
            Toast.makeText(this, "Perekaman dibatalkan", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
