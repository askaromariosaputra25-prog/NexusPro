package com.nexuspro.optimization

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Records the screen (video only) to Movies/NexusPro using MediaProjection. */
class ScreenRecordService : Service() {

    companion object {
        const val ACTION_START = "com.nexuspro.optimization.rec.START"
        const val ACTION_STOP = "com.nexuspro.optimization.rec.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "nexuspro_record"
        private const val NOTIF_ID = 4731

        @Volatile
        var recording: Boolean = false
            private set

        fun stop(context: Context) {
            if (!recording) return
            runCatching {
                context.startService(Intent(context, ScreenRecordService::class.java).setAction(ACTION_STOP))
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var file: File? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            finishRecording()
            stopSelf()
            return START_NOT_STICKY
        }
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        if (data == null || recording) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        try {
            startRecording(code, data)
        } catch (t: Throwable) {
            toast("Gagal merekam: ${t.message ?: "tidak diketahui"}")
            finishRecording(save = false)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Perekam layar", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stop = PendingIntent.getService(
            this, 3, Intent(this, ScreenRecordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        val n = builder
            .setContentTitle("NexusPro sedang merekam layar")
            .setContentText("Ketuk Berhenti untuk menyimpan rekaman.")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Berhenti", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun startRecording(code: Int, data: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mgr.getMediaProjection(code, data) ?: throw IllegalStateException("Izin ditolak")
        projection = proj
        // Required on Android 14+ before creating the virtual display.
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handler.post {
                    finishRecording()
                    stopSelf()
                }
            }
        }, handler)

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val scale = minOf(1f, 1280f / maxOf(dm.widthPixels, dm.heightPixels).toFloat())
        val w = ((dm.widthPixels * scale).toInt() / 2) * 2
        val h = ((dm.heightPixels * scale).toInt() / 2) * 2

        val name = "NexusPro_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        recorder = rec
        rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        rec.setVideoSize(w, h)
        rec.setVideoFrameRate(30)
        rec.setVideoEncodingBitRate(6_000_000)
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/NexusPro")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak bisa membuat file")
            uri = u
            val p = contentResolver.openFileDescriptor(u, "w") ?: throw IllegalStateException("Tidak bisa menulis file")
            pfd = p
            rec.setOutputFile(p.fileDescriptor)
        } else {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
            dir.mkdirs()
            val f = File(dir, name)
            file = f
            rec.setOutputFile(f.absolutePath)
        }
        rec.prepare()
        display = proj.createVirtualDisplay(
            "NexusProRecord", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, null
        )
        rec.start()
        recording = true
        toast("Merekam layar. Berhenti lewat bubble atau notifikasi.")
    }

    private fun finishRecording(save: Boolean = true) {
        val wasRecording = recording
        recording = false
        var ok = wasRecording && save
        runCatching { recorder?.stop() }.onFailure { ok = false }
        runCatching { recorder?.reset() }
        runCatching { recorder?.release() }
        recorder = null
        runCatching { display?.release() }
        display = null
        runCatching { projection?.stop() }
        projection = null
        runCatching { pfd?.close() }
        pfd = null
        val u = uri
        if (u != null) {
            runCatching {
                if (ok) {
                    val values = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(u, values, null, null)
                } else {
                    contentResolver.delete(u, null, null)
                }
            }
        }
        uri = null
        val f = file
        if (f != null && !ok) runCatching { f.delete() }
        file = null
        if (wasRecording) {
            toast(if (ok) "Rekaman disimpan di Movies/NexusPro" else "Rekaman gagal disimpan")
        }
        runCatching { stopForeground(true) }
    }

    override fun onDestroy() {
        if (recording) finishRecording()
        super.onDestroy()
    }

    private fun toast(message: String) {
        handler.post { Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show() }
    }
}
