package com.nexuspro.optimization

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.Executors

/**
 * Permission Center + Quick Settings bridge.
 *
 * Channel: com.nexuspro.optimization/system_tools
 *   getPermissions()                 -> Map<String, Boolean>
 *   open(target)                     -> Boolean   (opens the matching system settings page)
 *   grantSecureSettings()            -> {ok, message}  (self-grant through Shizuku or root)
 *   getToggles()                     -> Map<String, Boolean?>
 *   setToggle(id, enabled)           -> {ok, message}
 *   getDisplay()                     -> {brightness, timeoutMs, autoBrightness}
 *   setBrightness(value)             -> {ok, message}   value 1..255
 *   setScreenTimeout(ms)             -> {ok, message}
 */
internal class SystemToolsChannel(
    private val activity: Activity,
    messenger: BinaryMessenger,
) {
    companion object {
        const val CHANNEL = "com.nexuspro.optimization/system_tools"
        private const val SECURE_PERMISSION = "android.permission.WRITE_SECURE_SETTINGS"

        private data class Toggle(
            val ns: String,
            val key: String,
            val onValue: Int,
            val offValue: Int,
        )

        private val TOGGLES = mapOf(
            "show_touches" to Toggle("system", "show_touches", 1, 0),
            "pointer_location" to Toggle("system", "pointer_location", 1, 0),
            "auto_rotate" to Toggle("system", "accelerometer_rotation", 1, 0),
            "auto_brightness" to Toggle("system", "screen_brightness_mode", 1, 0),
            "haptic" to Toggle("system", "haptic_feedback_enabled", 1, 0),
            "touch_sounds" to Toggle("system", "sound_effects_enabled", 1, 0),
            "stay_awake" to Toggle("global", "stay_on_while_plugged_in", 7, 0),
        )
    }

    private val channel = MethodChannel(messenger, CHANNEL)
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private fun pkg(): String = activity.packageName

    fun register() {
        channel.setMethodCallHandler { call, result ->
            io.execute {
                val reply: Any? = try {
                    when (call.method) {
                        "getPermissions" -> permissions()
                        "open" -> open(call.argument<String>("target") ?: "")
                        "grantSecureSettings" -> grantSecureSettings()
                        "getToggles" -> toggles()
                        "setToggle" -> setToggle(
                            call.argument<String>("id") ?: "",
                            call.argument<Boolean>("enabled") ?: false,
                        )
                        "getDisplay" -> display()
                        "setBrightness" -> setBrightness(call.argument<Int>("value") ?: 128)
                        "setScreenTimeout" -> setScreenTimeout(call.argument<Int>("ms") ?: 60000)
                        else -> NOT_IMPLEMENTED
                    }
                } catch (t: Throwable) {
                    outcome(false, t.message ?: "Terjadi kesalahan")
                }
                main.post {
                    if (reply === NOT_IMPLEMENTED) result.notImplemented() else result.success(reply)
                }
            }
        }
    }

    private val NOT_IMPLEMENTED = Any()

    private fun outcome(ok: Boolean, message: String): Map<String, Any> =
        mapOf("ok" to ok, "message" to message)

    // ------------------------------------------------------------ permissions

    private fun hasSecure(): Boolean =
        activity.checkSelfPermission(SECURE_PERMISSION) == PackageManager.PERMISSION_GRANTED

    private fun permissions(): Map<String, Boolean> {
        val nm = activity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pm = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
        return mapOf(
            "overlay" to OverlayService.canDraw(activity),
            "usageAccess" to OverlayService.hasUsageAccess(activity),
            "writeSettings" to Settings.System.canWrite(activity),
            "secureSettings" to hasSecure(),
            "dnd" to nm.isNotificationPolicyAccessGranted,
            "battery" to pm.isIgnoringBatteryOptimizations(pkg()),
            "notifications" to nm.areNotificationsEnabled(),
            "shizukuRunning" to PrivShell.shizukuRunning(),
            "shizukuGranted" to PrivShell.shizukuReady(),
        )
    }

    private fun start(intent: Intent): Boolean =
        runCatching { activity.startActivity(intent) }.isSuccess

    private fun appDetails(): Boolean = start(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg()))
    )

    private fun open(target: String): Boolean = when (target) {
        "overlay" -> start(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + pkg()))
        )
        "usageAccess" -> start(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        "writeSettings" -> start(
            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + pkg()))
        )
        "dnd" -> start(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        "battery" -> start(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + pkg()))
        ) || start(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        "notifications" -> {
            if (Build.VERSION.SDK_INT >= 33 &&
                activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                activity.runOnUiThread {
                    activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9001)
                }
                true
            } else {
                start(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, pkg())
                )
            }
        }
        "autostart" -> openAutostart()
        "appDetails" -> appDetails()
        else -> false
    }

    /** Vendor "auto start" pages (Oppo/Realme, Xiaomi, Vivo, ...). Falls back to app info. */
    private fun openAutostart(): Boolean {
        val candidates = listOf(
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
        )
        for ((p, c) in candidates) {
            val intent = Intent().setComponent(ComponentName(p, c))
            if (start(intent)) return true
        }
        return appDetails()
    }

    /** Grants WRITE_SECURE_SETTINGS to this app using Shizuku or root, once. */
    private fun grantSecureSettings(): Map<String, Any> {
        if (hasSecure()) return outcome(true, "Izin sudah aktif.")
        val r = PrivShell.exec("pm grant " + pkg() + " " + SECURE_PERMISSION)
        return if (hasSecure()) {
            outcome(true, "Berhasil. NexusPro sekarang bisa mengubah pengaturan lanjutan tanpa Shizuku.")
        } else {
            val why = if (r.output.isBlank()) "Aktifkan Shizuku (atau root) lalu coba lagi." else r.output
            outcome(false, why)
        }
    }

    // ------------------------------------------------------------ settings I/O

    private fun readInt(ns: String, key: String): Int? = try {
        val cr = activity.contentResolver
        val missing = Int.MIN_VALUE
        val v = when (ns) {
            "system" -> Settings.System.getInt(cr, key, missing)
            "global" -> Settings.Global.getInt(cr, key, missing)
            else -> Settings.Secure.getInt(cr, key, missing)
        }
        if (v == missing) null else v
    } catch (t: Throwable) {
        null
    }

    /** Writes a setting directly, then through the privileged shell, and verifies it. */
    private fun writeInt(ns: String, key: String, value: Int): Map<String, Any> {
        try {
            val cr = activity.contentResolver
            when (ns) {
                "system" -> Settings.System.putInt(cr, key, value)
                "global" -> Settings.Global.putInt(cr, key, value)
                else -> Settings.Secure.putInt(cr, key, value)
            }
            if (readInt(ns, key) == value) return outcome(true, "Berhasil diubah.")
        } catch (t: Throwable) {
            // Not permitted directly: fall through to the privileged shell.
        }
        val r = PrivShell.exec("settings put $ns $key $value")
        if (r.ok && readInt(ns, key) == value) return outcome(true, "Berhasil diubah (via Shizuku/root).")
        return if (ns == "system") {
            outcome(false, "Butuh izin \"Ubah pengaturan sistem\". Aktifkan di Pusat Izin.")
        } else {
            outcome(false, "Butuh izin pengaturan lanjutan. Beri lewat Pusat Izin (Shizuku/root).")
        }
    }

    private fun toggles(): Map<String, Boolean?> {
        val out = HashMap<String, Boolean?>()
        for ((id, t) in TOGGLES) {
            val v = readInt(t.ns, t.key)
            out[id] = if (v == null) null else v != t.offValue
        }
        return out
    }

    private fun setToggle(id: String, enabled: Boolean): Map<String, Any> {
        val t = TOGGLES[id] ?: return outcome(false, "Pengaturan tidak dikenal.")
        return writeInt(t.ns, t.key, if (enabled) t.onValue else t.offValue)
    }

    private fun display(): Map<String, Any?> = mapOf(
        "brightness" to readInt("system", "screen_brightness"),
        "timeoutMs" to readInt("system", "screen_off_timeout"),
        "autoBrightness" to (readInt("system", "screen_brightness_mode") == 1),
    )

    private fun setBrightness(value: Int): Map<String, Any> {
        val v = value.coerceIn(1, 255)
        val mode = writeInt("system", "screen_brightness_mode", 0)
        if (mode["ok"] != true) return mode
        return writeInt("system", "screen_brightness", v)
    }

    private fun setScreenTimeout(ms: Int): Map<String, Any> =
        writeInt("system", "screen_off_timeout", ms.coerceIn(15000, 1800000))
}
