package com.nexuspro.optimization

import android.content.Context
import android.speech.tts.TextToSpeech
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import java.util.Locale

/**
 * Text-to-speech through Android's built-in engine (no extra package).
 *
 * Channel: com.nexuspro.optimization/speech
 *   speak(text, lang, rate, pitch) -> Boolean
 *   stop()                          -> Boolean
 */
internal class SpeechChannel(
    context: Context,
    messenger: BinaryMessenger,
) {
    companion object {
        const val CHANNEL = "com.nexuspro.optimization/speech"
    }

    private val appContext = context.applicationContext
    private val channel = MethodChannel(messenger, CHANNEL)
    private var tts: TextToSpeech? = null
    private var ready = false

    // Last request made before the engine finished starting.
    private var pending: Request? = null

    private data class Request(val text: String, val lang: String, val rate: Float, val pitch: Float)

    fun register() {
        ensureEngine()
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "speak" -> {
                    val text = (call.argument<String>("text") ?: "").trim()
                    val lang = call.argument<String>("lang") ?: "id"
                    val rate = (call.argument<Double>("rate") ?: 0.95).toFloat()
                    val pitch = (call.argument<Double>("pitch") ?: 1.0).toFloat()
                    if (text.isEmpty()) {
                        result.success(false)
                    } else {
                        result.success(speak(Request(text.take(900), lang, rate, pitch)))
                    }
                }
                "stop" -> {
                    pending = null
                    runCatching { tts?.stop() }
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun ensureEngine() {
        if (tts != null) return
        tts = runCatching {
            TextToSpeech(appContext) { status ->
                ready = status == TextToSpeech.SUCCESS
                if (ready) {
                    pending?.let { speak(it) }
                    pending = null
                }
            }
        }.getOrNull()
    }

    private fun speak(req: Request): Boolean {
        val engine = tts ?: return false
        if (!ready) {
            pending = req
            return true
        }
        return runCatching {
            val locale = if (req.lang == "en") Locale.US else Locale("id", "ID")
            val avail = engine.setLanguage(locale)
            if (avail == TextToSpeech.LANG_MISSING_DATA || avail == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine.setLanguage(Locale.getDefault())
            }
            engine.setSpeechRate(req.rate)
            engine.setPitch(req.pitch)
            engine.speak(req.text, TextToSpeech.QUEUE_FLUSH, null, "nexuspro")
            true
        }.getOrDefault(false)
    }
}
