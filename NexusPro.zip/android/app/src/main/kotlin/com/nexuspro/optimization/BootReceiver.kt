package com.nexuspro.optimization

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts the Game Mode overlay after the phone boots, when the user enabled it. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences(OverlayService.PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(OverlayService.KEY_BOOT, false) && OverlayService.canDraw(context)) {
            try {
                OverlayService.start(context)
            } catch (t: Throwable) {
                // Some ROMs forbid starting services from the boot broadcast; ignore.
            }
        }
    }
}
