package com.nexuspro.optimization

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * Tiny privileged-shell helper: runs a command through Shizuku when it is ready,
 * otherwise through `su` when the phone is rooted.
 */
internal object PrivShell {

    data class Result(val ok: Boolean, val output: String)

    fun shizukuRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (t: Throwable) {
        false
    }

    fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    /** Runs [command] with elevated rights. Never throws. */
    fun exec(command: String): Result {
        if (shizukuReady()) {
            return try {
                @Suppress("DEPRECATION")
                val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                collect(process)
            } catch (t: Throwable) {
                Result(false, t.message ?: "Shizuku error")
            }
        }
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            collect(process)
        } catch (t: Throwable) {
            Result(false, "Butuh Shizuku aktif atau akses root")
        }
    }

    private fun collect(process: Process): Result {
        val out = StringBuilder()
        val err = StringBuilder()
        val outThread = Thread {
            runCatching { out.append(process.inputStream.readBytes().toString(Charsets.UTF_8)) }
        }
        val errThread = Thread {
            runCatching { err.append(process.errorStream.readBytes().toString(Charsets.UTF_8)) }
        }
        outThread.start()
        errThread.start()
        outThread.join(15000)
        if (outThread.isAlive) {
            runCatching { process.destroy() }
            return Result(false, "Waktu habis")
        }
        errThread.join(2000)
        val code = try {
            process.waitFor()
        } catch (t: Throwable) {
            -1
        }
        val text = if (code == 0) out.toString() else err.toString().ifBlank { out.toString() }
        return Result(code == 0, text.trim())
    }
}
