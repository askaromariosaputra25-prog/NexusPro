package com.nexuspro.optimization

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Game Mode overlay: a draggable bubble that expands into a small panel on top of
 * any app (system status, RAM boost, cache cleaning, Do Not Disturb, quick launch).
 *
 * Needs the "Display over other apps" permission. Runs as a foreground service so
 * Android does not kill it while a game is in the foreground.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.nexuspro.optimization.overlay.STOP"
        const val PREFS = "nexuspro_overlay"
        const val KEY_QUICK_APPS = "quick_apps"
        const val KEY_SHOW_RAM = "show_ram"
        const val KEY_SHOW_BATTERY = "show_battery"
        const val KEY_SHOW_TEMP = "show_temp"
        const val KEY_AUTO = "auto_show"
        const val KEY_BOOT = "start_on_boot"
        const val KEY_GAMES = "game_packages"
        const val KEY_MANUAL = "manual_games"
        const val KEY_ENABLED = "overlay_enabled"
        const val ACTION_MARK = "com.nexuspro.optimization.overlay.MARK_GAME"
        private const val KEY_POS_X = "pos_x"
        private const val KEY_POS_Y = "pos_y"
        private const val CHANNEL_ID = "nexuspro_overlay"
        private const val NOTIF_ID = 4721

        // Value of ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE (Android 14+).
        private const val FGS_TYPE_SPECIAL_USE = 0x40000000

        @Volatile
        var running: Boolean = false
            private set

        /** Last app seen in the foreground, and how it was detected (for diagnostics). */
        @Volatile
        var currentFg: String? = null

        @Volatile
        var currentSource: String = "-"

        /** Prefixes of well-known games, used when the app has no "game" category. */
        private val KNOWN_GAMES = listOf(
            "com.mobile.legends", "com.mobilelegends", "com.moonton.", "com.tencent.ig",
            "com.tencent.tmgp", "com.pubg.", "com.vng.pubg", "com.rekoo.pubgm", "com.dts.freefire",
            "com.garena.game", "com.garena.", "com.activision.", "com.miHoYo.", "com.HoYoverse.",
            "com.levelinfinite.", "com.roblox.", "com.supercell.", "com.riotgames.", "com.mojang.",
            "com.ea.game", "com.gameloft.", "com.netease.", "com.proximabeta.", "com.krafton.",
            "com.epicgames.", "com.nianticlabs.", "com.kiloo.", "com.king.", "com.lilithgame.",
            "com.fanatee.", "com.hypergryph.", "com.kurogame.", "com.ngame.", "com.unity3d.",
        )

        private fun csv(prefs: android.content.SharedPreferences, key: String): Set<String> =
            (prefs.getString(key, "") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

        /** True when [pkg] is a game: in the user's lists, flagged as a game, or well known. */
        fun isGamePackage(context: Context, pkg: String?): Boolean {
            if (pkg.isNullOrEmpty()) return false
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (pkg in csv(prefs, KEY_GAMES) || pkg in csv(prefs, KEY_MANUAL)) return true
            try {
                val ai = context.packageManager.getApplicationInfo(pkg, 0)
                if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) return true
                @Suppress("DEPRECATION")
                if (ai.flags and ApplicationInfo.FLAG_IS_GAME != 0) return true
            } catch (t: Throwable) {
                // not installed / hidden: fall through to the name list
            }
            return KNOWN_GAMES.any { pkg.startsWith(it) }
        }

        fun markGame(context: Context, pkg: String, game: Boolean) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val set = csv(prefs, KEY_MANUAL).toMutableSet()
            if (game) set.add(pkg) else set.remove(pkg)
            prefs.edit().putString(KEY_MANUAL, set.joinToString(",")).apply()
        }

        /** Called by the accessibility service the moment another app comes to the front. */
        fun onForegroundChanged(context: Context, pkg: String) {
            currentFg = pkg
            currentSource = "aksesibilitas"
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (!running &&
                prefs.getBoolean(KEY_ENABLED, false) &&
                prefs.getBoolean(KEY_AUTO, true) &&
                canDraw(context) &&
                isGamePackage(context, pkg)
            ) {
                runCatching { start(context) }
            }
        }

        fun canDraw(context: Context): Boolean =
            Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context)

        /** "Usage access": lets the overlay see which app is in the foreground. */
        fun hasUsageAccess(context: Context): Boolean = try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (t: Throwable) {
            false
        }

        fun start(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, true).apply()
            val intent = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, false).apply()
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var rootView: LinearLayout? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var statusText: TextView? = null
    private var dndButton: TextView? = null
    private var panelOpen = false
    private var previousDndFilter = NotificationManager.INTERRUPTION_FILTER_ALL

    private var lastForeground: String? = null
    private var lastEventTime = 0L
    private var tick = 0
    @Volatile private var pingMs = -1
    @Volatile private var pinging = false

    private val ticker = object : Runnable {
        override fun run() {
            updateVisibility()
            tick++
            if (panelOpen && tick % 2 == 0) refreshStatus()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (intent?.action == ACTION_MARK) {
            markCurrentAsGame()
        }
        if (!canDraw(this)) {
            toast("Izin 'Tampil di atas aplikasi lain' belum aktif")
            stopSelf()
            return START_NOT_STICKY
        }
        if (rootView == null) {
            try {
                buildOverlay()
            } catch (e: Exception) {
                toast("Overlay gagal dibuat: ${e.message ?: "tidak diketahui"}")
                stopSelf()
                return START_NOT_STICKY
            }
        }
        running = true
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        // Sticky: if a strict ROM kills the service, Android brings it back.
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removeOverlay()
        super.onDestroy()
    }

    /** Some ROMs kill the service when the app is swiped away; bring it back. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (running && getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)) {
            runCatching {
                val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent(applicationContext, OverlayService::class.java)
                val flags = PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                val pi = if (Build.VERSION.SDK_INT >= 26) {
                    PendingIntent.getForegroundService(applicationContext, 7, intent, flags)
                } else {
                    PendingIntent.getService(applicationContext, 7, intent, flags)
                }
                am.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 1500L, pi)
            }
        }
        super.onTaskRemoved(rootIntent)
    }

    // ---------------------------------------------------------------- foreground

    private fun startAsForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, FGS_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Game Mode Overlay", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = Intent(this, OverlayService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val markIntent = Intent(this, OverlayService::class.java).setAction(ACTION_MARK)
        val markPending = PendingIntent.getService(
            this, 2, markIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("NexusPro Game Mode aktif")
            .setContentText("Bubble tidak muncul di game? Buka game, tarik notifikasi, ketuk \"Ini game\".")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(openPending)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_add, "Ini game", markPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Matikan", stopPending)
            .build()
    }

    // ---------------------------------------------------------------- overlay UI

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun roundedBg(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun buildOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt(KEY_POS_X, dp(8))
        lp.y = prefs.getInt(KEY_POS_Y, dp(120))
        overlayParams = lp

        // Bubble = the NexusPro logo, cropped to a circle with a glowing blue ring.
        val bubble = ImageView(this).apply {
            setImageResource(R.drawable.nexus_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#FF0B1220"))
                setStroke(dp(2), Color.parseColor("#CC00E5FF"))
            }
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            elevation = dp(6).toFloat()
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }

        val panelView = buildPanel()
        panelView.visibility = View.GONE
        panel = panelView

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bubble)
            addView(panelView)
        }
        rootView = root

        attachDrag(bubble, lp, wm, root)
        wm.addView(root, lp)
    }

    private fun buildPanel(): LinearLayout {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBg(Color.parseColor("#F2141A22"), 16)
            setPadding(dp(12), dp(10), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(dp(250), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
            }
        }

        container.addView(TextView(this).apply {
            text = "NexusPro Game Mode"
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
        })

        val status = TextView(this).apply {
            setTextColor(Color.parseColor("#B8C4D0"))
            textSize = 12f
            setPadding(0, dp(6), 0, dp(8))
            setLineSpacing(0f, 1.15f)
        }
        statusText = status
        container.addView(status)

        val row1 = actionRow()
        row1.addView(actionButton("Boost RAM") { boostRam() })
        row1.addView(actionButton("Hapus cache") { cleanCache() })
        container.addView(row1)

        val row2 = actionRow()
        val dnd = actionButton("DND: ...") { toggleDnd() }
        dndButton = dnd
        row2.addView(dnd)
        row2.addView(actionButton("Tutup") {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, false).apply()
            stopSelf()
        })
        container.addView(row2)

        val row3 = actionRow()
        row3.addView(actionButton("Screenshot") { takeScreenshot() })
        row3.addView(actionButton("Buka NexusPro") { launchPackage(packageName) })
        container.addView(row3)

        container.addView(TextView(this).apply {
            text = "Aplikasi cepat"
            setTextColor(Color.parseColor("#B8C4D0"))
            textSize = 11f
            setPadding(0, dp(8), 0, dp(4))
        })
        container.addView(buildQuickApps(prefs.getString(KEY_QUICK_APPS, "") ?: ""))

        return container
    }

    private fun actionRow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) }
    }

    private fun actionButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        textSize = 12f
        setTypeface(typeface, Typeface.BOLD)
        background = roundedBg(Color.parseColor("#FF2A3340"), 10)
        setPadding(dp(6), dp(9), dp(6), dp(9))
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(3)
            marginEnd = dp(3)
        }
        setOnClickListener { onClick() }
    }

    private fun buildQuickApps(csv: String): View {
        val packages = csv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (packages.isEmpty()) {
            return TextView(this).apply {
                text = "Belum ada. Tambahkan di NexusPro → Tools → Game Mode."
                setTextColor(Color.parseColor("#8896A5"))
                textSize = 11f
            }
        }
        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pm = packageManager
        for (pkg in packages) {
            val icon = try {
                pm.getApplicationIcon(pkg)
            } catch (e: Exception) {
                null
            } ?: continue
            val iv = ImageView(this).apply {
                setImageDrawable(icon)
                contentDescription = pkg
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(8) }
                setOnClickListener { launchPackage(pkg) }
            }
            strip.addView(iv)
        }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(strip)
        }
    }

    private fun attachDrag(
        handle: View,
        lp: WindowManager.LayoutParams,
        wm: WindowManager,
        root: View,
    ) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        val slop = dp(8)
        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = (startX + dx).coerceAtLeast(0)
                        lp.y = (startY + dy).coerceAtLeast(0)
                        runCatching { wm.updateViewLayout(root, lp) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                            .putInt(KEY_POS_X, lp.x)
                            .putInt(KEY_POS_Y, lp.y)
                            .apply()
                    } else {
                        togglePanel()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun togglePanel() {
        val p = panel ?: return
        val rv = rootView ?: return
        val lp = overlayParams ?: return
        val wm = windowManager ?: return
        panelOpen = !panelOpen
        p.visibility = if (panelOpen) View.VISIBLE else View.GONE
        if (panelOpen) {
            // Keep the expanded panel on screen.
            val maxX = resources.displayMetrics.widthPixels - dp(250) - dp(8)
            lp.x = lp.x.coerceAtMost(maxX).coerceAtLeast(0)
            runCatching { wm.updateViewLayout(rv, lp) }
            refreshStatus()
        } else {
            runCatching { wm.updateViewLayout(rv, lp) }
        }
    }

    private fun removeOverlay() {
        val v = rootView
        if (v != null) {
            runCatching { windowManager?.removeView(v) }
        }
        rootView = null
        panel = null
        statusText = null
        dndButton = null
    }

    // ---------------------------------------------------------------- auto show

    /**
     * Auto mode: the bubble is visible while a game is in the foreground. If the foreground
     * app cannot be determined it stays visible (never hide by mistake). With auto mode off
     * the bubble is always visible.
     */
    private fun updateVisibility() {
        val rv = rootView ?: return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        var show = true
        val fg = currentForeground()
        if (prefs.getBoolean(KEY_AUTO, true) && fg != null) {
            show = fg == packageName || isGamePackage(this, fg)
        }
        val target = if (show) View.VISIBLE else View.GONE
        if (rv.visibility != target) {
            rv.visibility = target
            if (!show && panelOpen) togglePanel()
        }
    }

    /** Best available answer to "which app is open now": accessibility first, usage stats second. */
    private fun currentForeground(): String? {
        if (NexusAccessibilityService.isEnabled(this)) {
            val a11y = NexusAccessibilityService.foreground
            if (a11y != null) {
                currentFg = a11y
                currentSource = "aksesibilitas"
                return a11y
            }
        }
        if (hasUsageAccess(this)) {
            val fg = foregroundPackage()
            if (fg != null) {
                currentFg = fg
                currentSource = "akses penggunaan"
                return fg
            }
        }
        return null
    }

    private fun markCurrentAsGame() {
        val fg = currentForeground() ?: currentFg
        if (fg == null || fg == packageName) {
            toast("Buka dulu game-nya, lalu tarik notifikasi dan ketuk \"Ini game\"")
            return
        }
        markGame(this, fg, true)
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(fg, 0)).toString()
        } catch (t: Throwable) {
            fg
        }
        toast("$label ditandai sebagai game")
        updateVisibility()
    }

    @Suppress("DEPRECATION")
    private fun foregroundPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return lastForeground
        val now = System.currentTimeMillis()
        val from = if (lastEventTime == 0L) now - 24L * 60L * 60L * 1000L else lastEventTime
        val events = try {
            usm.queryEvents(from, now)
        } catch (t: Throwable) {
            null
        } ?: return lastForeground
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND &&
                e.packageName != "com.android.systemui" &&
                e.packageName != "android"
            ) {
                lastForeground = e.packageName
            }
            if (e.timeStamp > lastEventTime) lastEventTime = e.timeStamp
        }
        if (lastForeground == null) {
            // Quiet phone: use the most recently used app instead.
            lastForeground = try {
                usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 3600_000L, now)
                    ?.maxByOrNull { it.lastTimeUsed }?.packageName
            } catch (t: Throwable) {
                null
            }
        }
        return lastForeground
    }

    private fun takeScreenshot() {
        if (!NexusAccessibilityService.isEnabled(this)) {
            toast("Aktifkan Aksesibilitas NexusPro di Tools > Pusat Izin untuk screenshot")
            return
        }
        if (panelOpen) togglePanel()
        handler.postDelayed({
            if (!NexusAccessibilityService.screenshot()) toast("Screenshot tidak didukung di HP ini")
        }, 350L)
    }

    private fun pingOnce() {
        if (pinging) return
        pinging = true
        Thread {
            pingMs = try {
                val t0 = SystemClock.elapsedRealtime()
                java.net.Socket().use { sock ->
                    sock.connect(java.net.InetSocketAddress("1.1.1.1", 443), 1500)
                }
                (SystemClock.elapsedRealtime() - t0).toInt()
            } catch (t: Throwable) {
                -1
            }
            pinging = false
        }.start()
    }

    // ---------------------------------------------------------------- status

    private fun availRam(): Long {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
    }

    private fun refreshStatus() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lines = ArrayList<String>()

        if (prefs.getBoolean(KEY_SHOW_RAM, true)) {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
            val totalMb = info.totalMem / (1024 * 1024)
            val usedMb = (info.totalMem - info.availMem) / (1024 * 1024)
            val pct = if (totalMb > 0) (usedMb * 100 / totalMb) else 0
            lines.add("RAM: $usedMb / $totalMb MB ($pct%)")
        }

        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (battery != null) {
            val level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val tempTenths = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            val status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (prefs.getBoolean(KEY_SHOW_BATTERY, true) && level >= 0 && scale > 0) {
                val pct = level * 100 / scale
                lines.add("Baterai: $pct%" + if (charging) " (mengisi)" else "")
            }
            if (prefs.getBoolean(KEY_SHOW_TEMP, true) && tempTenths != Int.MIN_VALUE) {
                lines.add("Suhu baterai: ${tempTenths / 10.0}°C")
            }
        }

        pingOnce()
        lines.add("Ping: " + if (pingMs >= 0) "$pingMs ms" else "tidak ada koneksi")
        val fg = currentFg
        if (fg != null) {
            val name = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(fg, 0)).toString()
            } catch (t: Throwable) {
                fg
            }
            lines.add("Aplikasi: $name")
        }
        lines.add("Jam: " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
        statusText?.text = lines.joinToString("\n")
        updateDndLabel()
    }

    // ---------------------------------------------------------------- actions

    private fun toast(message: String) {
        handler.post { Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show() }
    }

    private fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    private fun shizukuExec(command: String): Boolean = try {
        @Suppress("DEPRECATION")
        val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
        val drain = Thread { runCatching { process.errorStream.readBytes() } }
        drain.start()
        runCatching { process.inputStream.readBytes() }
        val code = process.waitFor()
        drain.join(2000)
        code == 0
    } catch (t: Throwable) {
        false
    }

    private fun boostRam() {
        toast("Membersihkan RAM...")
        Thread {
            val before = availRam()
            var done = false
            if (shizukuReady()) {
                done = shizukuExec("am kill-all")
            }
            if (!done) {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                for (app in packageManager.getInstalledApplications(0)) {
                    if (app.flags and ApplicationInfo.FLAG_SYSTEM == 0 && app.packageName != packageName) {
                        runCatching { am.killBackgroundProcesses(app.packageName) }
                    }
                }
            }
            Thread.sleep(1200)
            val freedMb = (availRam() - before).coerceAtLeast(0) / (1024 * 1024)
            toast("Boost RAM selesai: $freedMb MB lega")
        }.start()
    }

    private fun availStorage(): Long =
        StatFs(Environment.getDataDirectory().path).let { it.availableBlocksLong * it.blockSizeLong }

    private fun cleanCache() {
        toast("Membersihkan cache...")
        Thread {
            val before = availStorage()
            runCatching { cacheDir?.deleteRecursively() }
            runCatching { externalCacheDir?.deleteRecursively() }
            if (shizukuReady()) {
                shizukuExec("pm trim-caches 999G")
                Thread.sleep(800)
                val freedMb = (availStorage() - before).coerceAtLeast(0) / (1024 * 1024)
                toast("Cache semua aplikasi dibersihkan: $freedMb MB")
            } else {
                toast("Cache NexusPro dibersihkan. Aktifkan Shizuku untuk bersihkan cache semua aplikasi.")
            }
        }.start()
    }

    private fun updateDndLabel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val label = if (!nm.isNotificationPolicyAccessGranted) {
            "DND: beri izin"
        } else if (nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL ||
            nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        ) {
            "DND: mati"
        } else {
            "DND: aktif"
        }
        dndButton?.text = label
    }

    private fun toggleDnd() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Beri izin 'Jangan ganggu' untuk NexusPro, lalu kembali ke game")
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { startActivity(intent) }
            return
        }
        val current = nm.currentInterruptionFilter
        if (current == NotificationManager.INTERRUPTION_FILTER_ALL ||
            current == NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        ) {
            previousDndFilter = NotificationManager.INTERRUPTION_FILTER_ALL
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            toast("Jangan ganggu aktif")
        } else {
            nm.setInterruptionFilter(previousDndFilter)
            toast("Jangan ganggu dimatikan")
        }
        updateDndLabel()
    }

    private fun launchPackage(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            toast("Aplikasi tidak bisa dibuka")
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(intent) }
    }
}
