package com.nexuspro.optimization

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Game Mode overlay: a draggable bubble that expands into a small panel on top of
 * any app (system status, RAM boost, cache cleaning, Do Not Disturb, quick launch).
 *
 * Needs the "Display over other apps" permission. Runs as a foreground service so
 * Android does not kill it while a game is in the foreground.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.nexuspro.optimization.overlay.STOP"
        const val PREFS = "nexuspro_overlay"
        const val KEY_QUICK_APPS = "quick_apps"
        const val KEY_SHOW_RAM = "show_ram"
        const val KEY_SHOW_BATTERY = "show_battery"
        const val KEY_SHOW_TEMP = "show_temp"
        const val KEY_AUTO = "auto_show"
        const val KEY_BOOT = "start_on_boot"
        const val KEY_GAMES = "game_packages"
        const val KEY_MANUAL = "manual_games"
        const val KEY_ENABLED = "overlay_enabled"
        const val ACTION_MARK = "com.nexuspro.optimization.overlay.MARK_GAME"

        /** Game that was opened from inside NexusPro; the bubble belongs to this game only. */
        const val KEY_ARMED = "armed_game"
        const val KEY_ARMED_AT = "armed_at"

        /** true (default): the bubble shows only in a game opened through NexusPro. */
        const val KEY_ONLY_NEXUS = "only_via_nexus"
        private const val KEY_POS_X = "pos_x"
        private const val KEY_POS_Y = "pos_y"
        private const val CHANNEL_ID = "nexuspro_overlay"
        private const val NOTIF_ID = 4721

        // Value of ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE (Android 14+).
        private const val FGS_TYPE_SPECIAL_USE = 0x40000000

        @Volatile
        var running: Boolean = false
            private set

        /** Last app seen in the foreground, and how it was detected (for diagnostics). */
        @Volatile
        var currentFg: String? = null

        @Volatile
        var currentSource: String = "-"

        /** Prefixes of well-known games, used when the app has no "game" category. */
        private val KNOWN_GAMES = listOf(
            "com.mobile.legends", "com.mobilelegends", "com.moonton.", "com.tencent.ig",
            "com.tencent.tmgp", "com.pubg.", "com.vng.pubg", "com.rekoo.pubgm", "com.dts.freefire",
            "com.garena.game", "com.garena.", "com.activision.", "com.miHoYo.", "com.HoYoverse.",
            "com.levelinfinite.", "com.roblox.", "com.supercell.", "com.riotgames.", "com.mojang.",
            "com.ea.game", "com.gameloft.", "com.netease.", "com.proximabeta.", "com.krafton.",
            "com.epicgames.", "com.nianticlabs.", "com.kiloo.", "com.king.", "com.lilithgame.",
            "com.fanatee.", "com.hypergryph.", "com.kurogame.", "com.ngame.", "com.unity3d.",
        )

        private fun csv(prefs: android.content.SharedPreferences, key: String): Set<String> =
            (prefs.getString(key, "") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

        /** True when [pkg] is a game: in the user's lists, flagged as a game, or well known. */
        fun isGamePackage(context: Context, pkg: String?): Boolean {
            if (pkg.isNullOrEmpty()) return false
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (pkg in csv(prefs, KEY_GAMES) || pkg in csv(prefs, KEY_MANUAL)) return true
            try {
                val ai = context.packageManager.getApplicationInfo(pkg, 0)
                if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) return true
                @Suppress("DEPRECATION")
                if (ai.flags and ApplicationInfo.FLAG_IS_GAME != 0) return true
            } catch (t: Throwable) {
                // not installed / hidden: fall through to the name list
            }
            return KNOWN_GAMES.any { pkg.startsWith(it) }
        }

        fun armedPackage(context: Context): String =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ARMED, "") ?: ""

        /**
         * Called when a game is opened from inside NexusPro. Remembers the game and starts the
         * overlay so the bubble is ready the moment the game reaches the screen.
         */
        fun armGame(context: Context, pkg: String): Boolean {
            if (!canDraw(context)) return false
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_ARMED, pkg)
                .putLong(KEY_ARMED_AT, System.currentTimeMillis())
                .apply()
            return runCatching { start(context) }.isSuccess
        }

        fun markGame(context: Context, pkg: String, game: Boolean) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val set = csv(prefs, KEY_MANUAL).toMutableSet()
            if (game) set.add(pkg) else set.remove(pkg)
            prefs.edit().putString(KEY_MANUAL, set.joinToString(",")).apply()
        }

        /** Called by the accessibility service the moment another app comes to the front. */
        fun onForegroundChanged(context: Context, pkg: String) {
            currentFg = pkg
            currentSource = "aksesibilitas"
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val onlyNexus = prefs.getBoolean(KEY_ONLY_NEXUS, true)
            val armed = prefs.getString(KEY_ARMED, "") ?: ""
            val allowed = if (onlyNexus) pkg == armed else isGamePackage(context, pkg)
            if (!running &&
                prefs.getBoolean(KEY_ENABLED, false) &&
                prefs.getBoolean(KEY_AUTO, true) &&
                canDraw(context) &&
                allowed
            ) {
                runCatching { start(context) }
            }
        }

        fun canDraw(context: Context): Boolean =
            Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context)

        /** "Usage access": lets the overlay see which app is in the foreground. */
        fun hasUsageAccess(context: Context): Boolean = try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (t: Throwable) {
            false
        }

        fun start(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, true).apply()
            val intent = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, false).remove(KEY_ARMED).apply()
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var rootView: LinearLayout? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var panelOpen = false
    private var keepScreenOn = false
    private var torchOn = false
    private var savedX = 0
    private var savedY = 0
    private var movedWhileOpen = false
    private var draggingBar: SeekBar? = null
    private var currentTab = 0
    private val tabButtons = ArrayList<LinearLayout>()
    private val pages = ArrayList<View>()
    private var headerSub: TextView? = null
    private var boostButton: TextView? = null
    private var boostBusy = false
    private var statRam: Stat? = null
    private var statBattery: Stat? = null
    private var statCpu: Stat? = null
    private var statGpu: Stat? = null
    private var statFps: Stat? = null
    private var statPing: Stat? = null
    private var statTemp: Stat? = null
    private var statClock: Stat? = null
    private var perfHint: TextView? = null
    private var infoText: TextView? = null
    private var tileDnd: Tile? = null
    private var tileKeep: Tile? = null
    private var tileRot: Tile? = null
    private var tileTorch: Tile? = null
    private var brightBar: SeekBar? = null
    private var brightLabel: TextView? = null
    private var volBar: SeekBar? = null
    private var volLabel: TextView? = null

    // Live numbers from the privileged shell (Shizuku / root). -1 = not available.
    @Volatile private var cpuPct = -1
    @Volatile private var gpuPct = -1
    @Volatile private var fpsNow = -1
    @Volatile private var cpuMaxMhz = -1
    @Volatile private var cpuTempC = -1f
    @Volatile private var privAvailable = false
    @Volatile private var sampling = false
    private var nextPrivTry = 0L
    private var prevCpuTotal = 0L
    private var prevCpuIdle = 0L
    private var previousDndFilter = NotificationManager.INTERRUPTION_FILTER_ALL

    private var lastForeground: String? = null
    private var lastEventTime = 0L
    private var tick = 0
    @Volatile private var pingMs = -1
    @Volatile private var pinging = false

    private val ticker = object : Runnable {
        override fun run() {
            updateVisibility()
            tick++
            if (panelOpen && tick % 2 == 0) {
                refreshStatus()
                sampleSystem()
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, false).remove(KEY_ARMED).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (intent?.action == ACTION_MARK) {
            markCurrentAsGame()
        }
        if (!canDraw(this)) {
            toast("Izin 'Tampil di atas aplikasi lain' belum aktif")
            stopSelf()
            return START_NOT_STICKY
        }
        if (rootView == null) {
            try {
                buildOverlay()
            } catch (e: Exception) {
                toast("Overlay gagal dibuat: ${e.message ?: "tidak diketahui"}")
                stopSelf()
                return START_NOT_STICKY
            }
        }
        running = true
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        // Sticky: if a strict ROM kills the service, Android brings it back.
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removeOverlay()
        super.onDestroy()
    }

    /** Some ROMs kill the service when the app is swiped away; bring it back. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (running && getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)) {
            runCatching {
                val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent(applicationContext, OverlayService::class.java)
                val flags = PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                val pi = if (Build.VERSION.SDK_INT >= 26) {
                    PendingIntent.getForegroundService(applicationContext, 7, intent, flags)
                } else {
                    PendingIntent.getService(applicationContext, 7, intent, flags)
                }
                am.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 1500L, pi)
            }
        }
        super.onTaskRemoved(rootIntent)
    }

    // ---------------------------------------------------------------- foreground

    private fun startAsForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, FGS_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Game Mode Overlay", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = Intent(this, OverlayService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val markIntent = Intent(this, OverlayService::class.java).setAction(ACTION_MARK)
        val markPending = PendingIntent.getService(
            this, 2, markIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("NexusPro Game Mode aktif")
            .setContentText("Bubble tidak muncul di game? Buka game, tarik notifikasi, ketuk \"Ini game\".")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(openPending)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_add, "Ini game", markPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Matikan", stopPending)
            .build()
    }

    // ---------------------------------------------------------------- overlay UI

    private val cRed = Color.parseColor("#FFE4002B")
    private val cRedDark = Color.parseColor("#FF7A0016")
    private val cBg = Color.parseColor("#F40A0A0D")
    private val cCard = Color.parseColor("#FF17171C")
    private val cCardHi = Color.parseColor("#FF2A0A10")
    private val cMuted = Color.parseColor("#FF9A9AA6")
    private val cLine = Color.parseColor("#FF2B2B33")

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun roundedBg(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
        }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun screenSize(): Pair<Int, Int> {
        val wm = windowManager ?: (getSystemService(Context.WINDOW_SERVICE) as WindowManager)
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private fun panelWidth(): Int {
        val (w, h) = screenSize()
        return if (w > h) minOf(dp(470), w - dp(24)) else minOf(dp(390), w - dp(16))
    }

    private fun panelHeight(): Int {
        val (w, h) = screenSize()
        return if (w > h) minOf(dp(300), h - dp(40)) else minOf(dp(400), (h * 0.72f).toInt())
    }

    private fun buildOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt(KEY_POS_X, dp(8))
        lp.y = prefs.getInt(KEY_POS_Y, dp(120))
        overlayParams = lp

        // Bubble = the NexusPro logo in a circle with a red glowing ring.
        val bubble = ImageView(this).apply {
            setImageResource(R.drawable.nexus_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#FF0A0A0D"))
                setStroke(dp(2), cRed)
            }
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            elevation = dp(8).toFloat()
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }

        val panelView = buildPanel()
        panelView.visibility = View.GONE
        panel = panelView

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bubble)
            addView(panelView)
        }
        rootView = root

        attachDrag(bubble, lp, wm, root)
        wm.addView(root, lp)
    }

    private val tabGlyphs = listOf("⚡", "✦", "▦", "ⓘ")
    private val tabNames = listOf("Performa", "Alat", "Aplikasi", "Info")

    private fun buildPanel(): LinearLayout {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = roundedBg(cBg, 14, cRed, 1)
            layoutParams = LinearLayout.LayoutParams(panelWidth(), panelHeight()).apply { topMargin = dp(6) }
            elevation = dp(10).toFloat()
        }

        // ---- left tab rail
        val rail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
            background = roundedBg(Color.parseColor("#FF101014"), 14)
            layoutParams = LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.MATCH_PARENT)
        }
        tabButtons.clear()
        for (i in tabNames.indices) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(2), dp(8), dp(2), dp(8))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
                ).apply { bottomMargin = dp(4) }
                addView(tv(tabGlyphs[i], 18f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
                addView(tv(tabNames[i], 9f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
                setOnClickListener { selectTab(i) }
            }
            tabButtons.add(item)
            rail.addView(item)
        }
        outer.addView(rail)

        // ---- right column: header + pages
        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        right.addView(buildHeader())
        right.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cRed, Color.TRANSPARENT)
            )
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)).apply {
                topMargin = dp(4); bottomMargin = dp(6)
            }
        })

        val host = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        pages.clear()
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        pages.add(scroll(buildPerformPage()))
        pages.add(scroll(buildToolsPage()))
        pages.add(scroll(buildAppsPage(prefs.getString(KEY_QUICK_APPS, "") ?: "")))
        pages.add(scroll(buildInfoPage()))
        for (p in pages) host.addView(p)
        right.addView(host)
        outer.addView(right)

        selectTab(0)
        return outer
    }

    private fun buildHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titles.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(tv("NEXUS", 15f, Color.WHITE, true))
            addView(tv("PRO", 15f, cRed, true))
            addView(tv("  GAME PANEL", 9f, cMuted, true).apply { setPadding(0, dp(5), 0, 0) })
        })
        val sub = tv("Siap bermain", 10f, cMuted)
        headerSub = sub
        titles.addView(sub)
        row.addView(titles)
        row.addView(tv("✕", 16f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = roundedBg(cCard, 8)
            layoutParams = LinearLayout.LayoutParams(dp(30), dp(30))
            setOnClickListener { if (panelOpen) togglePanel() }
        })
        return row
    }

    private fun scroll(content: View): ScrollView = ScrollView(this).apply {
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        addView(content)
    }

    private fun selectTab(index: Int) {
        currentTab = index
        for (i in tabButtons.indices) {
            val on = i == index
            tabButtons[i].background =
                if (on) roundedBg(cCardHi, 10, cRed, 1) else roundedBg(Color.TRANSPARENT, 10)
            tabButtons[i].alpha = if (on) 1f else 0.55f
        }
        for (i in pages.indices) pages[i].visibility = if (i == index) View.VISIBLE else View.GONE
        if (panelOpen) refreshStatus()
    }

    // ---- page: Performa

    private class Stat(val card: LinearLayout, val value: TextView, val sub: TextView, val bar: BarView?)

    private class BarView(ctx: Context, private val fillColor: Int) : View(ctx) {
        var fraction = 0f
            set(v) {
                field = v.coerceIn(0f, 1f)
                invalidate()
            }
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF2A2A33") }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fillColor }
        override fun onDraw(c: Canvas) {
            val r = height / 2f
            c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, track)
            if (fraction > 0f) c.drawRoundRect(0f, 0f, width * fraction, height.toFloat(), r, r, fill)
        }
    }

    private fun statCard(label: String, withBar: Boolean = false): Stat {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBg(cCard, 10, cLine, 1)
            setPadding(dp(10), dp(7), dp(10), dp(8))
        }
        card.addView(tv(label.uppercase(), 9f, cMuted, true).apply { letterSpacing = 0.1f })
        val value = tv("--", 20f, Color.WHITE, true)
        card.addView(value)
        var bar: BarView? = null
        if (withBar) {
            bar = BarView(this, cRed).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)).apply {
                    topMargin = dp(2); bottomMargin = dp(3)
                }
            }
            card.addView(bar)
        }
        val sub = tv("", 10f, cMuted)
        card.addView(sub)
        return Stat(card, value, sub, bar)
    }

    private fun twoCol(a: View, b: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) }
        addView(a, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(3) })
        addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(3) })
    }

    private fun buildPerformPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val ram = statCard("RAM", true).also { statRam = it }
        val bat = statCard("Baterai").also { statBattery = it }
        val cpu = statCard("CPU").also { statCpu = it }
        val gpu = statCard("GPU").also { statGpu = it }
        val fps = statCard("FPS").also { statFps = it }
        val ping = statCard("Ping").also { statPing = it }
        val temp = statCard("Suhu").also { statTemp = it }
        val clock = statCard("Jam").also { statClock = it }

        val first = twoCol(ram.card, bat.card)
        (first.layoutParams as LinearLayout.LayoutParams).topMargin = 0
        col.addView(first)
        col.addView(twoCol(cpu.card, gpu.card))
        col.addView(twoCol(fps.card, ping.card))
        col.addView(twoCol(temp.card, clock.card))

        val hint = tv("", 10f, cMuted).apply { setPadding(dp(2), dp(6), dp(2), 0) }
        perfHint = hint
        col.addView(hint)

        val boost = TextView(this).apply {
            text = "BOOST"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 20f
            letterSpacing = 0.25f
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cRed, cRedDark)
            ).apply { cornerRadius = dp(12).toFloat() }
            setPadding(dp(8), dp(14), dp(8), dp(14))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10); bottomMargin = dp(4) }
            setOnClickListener { boostRam() }
        }
        boostButton = boost
        col.addView(boost)
        return col
    }

    // ---- page: Alat

    private class Tile(val view: LinearLayout, val glyph: TextView, val label: TextView)

    private fun toolTile(glyph: String, label: String, onClick: () -> Unit): Tile {
        val g = tv(glyph, 20f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        val l = tv(label, 10f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            maxLines = 2
        }
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = roundedBg(cCard, 10, cLine, 1)
            setPadding(dp(4), dp(10), dp(4), dp(8))
            addView(g)
            addView(l)
            setOnClickListener { onClick() }
        }
        return Tile(v, g, l)
    }

    private fun setTileActive(tile: Tile?, on: Boolean, label: String? = null) {
        tile ?: return
        tile.view.background =
            if (on) roundedBg(cCardHi, 10, cRed, 1) else roundedBg(cCard, 10, cLine, 1)
        tile.glyph.setTextColor(if (on) cRed else Color.WHITE)
        if (label != null) tile.label.text = label
    }

    private fun tileGrid(tiles: List<Tile>): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (chunk in tiles.chunked(3)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
            }
            for (i in 0 until 3) {
                val lpTile = LinearLayout.LayoutParams(0, dp(66), 1f).apply {
                    marginStart = dp(3); marginEnd = dp(3)
                }
                if (i < chunk.size) row.addView(chunk[i].view, lpTile)
                else row.addView(View(this), lpTile)
            }
            col.addView(row)
        }
        return col
    }

    private fun buildToolsPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val cache = toolTile("🧹", "Hapus cache") { cleanCache() }
        val dnd = toolTile("🔕", "DND: ...") { toggleDnd() }.also { tileDnd = it }
        val shot = toolTile("📸", "Screenshot") { takeScreenshot() }
        val keep = toolTile("☀", "Layar nyala") { toggleKeepScreen() }.also { tileKeep = it }
        val rot = toolTile("⟳", "Rotasi") { toggleRotationLock() }.also { tileRot = it }
        val torch = toolTile("🔦", "Senter") { toggleTorch() }.also { tileTorch = it }
        val openTile = toolTile("🚀", "Buka NexusPro") { launchPackage(packageName) }
        val closeTile = toolTile("⏻", "Tutup bubble") { closeBubble() }
        col.addView(tileGrid(listOf(cache, dnd, shot, keep, rot, torch, openTile, closeTile)))

        // Sliders
        col.addView(sectionTitle("KECERAHAN"))
        val bl = tv("--", 11f, Color.WHITE, true).also { brightLabel = it }
        val bb = SeekBar(this).also { brightBar = it }
        styleSeek(bb, 100)
        bb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                bl.text = "$p%"
                if (fromUser) setBrightnessPercent(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) { draggingBar = s }
            override fun onStopTrackingTouch(s: SeekBar?) { draggingBar = null }
        })
        col.addView(sliderRow("☀", bb, bl))

        col.addView(sectionTitle("VOLUME MEDIA"))
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val vl = tv("--", 11f, Color.WHITE, true).also { volLabel = it }
        val vb = SeekBar(this).also { volBar = it }
        styleSeek(vb, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1))
        vb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val max = vb.max.coerceAtLeast(1)
                vl.text = "${p * 100 / max}%"
                if (fromUser) runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0) }
            }
            override fun onStartTrackingTouch(s: SeekBar?) { draggingBar = s }
            override fun onStopTrackingTouch(s: SeekBar?) { draggingBar = null }
        })
        col.addView(sliderRow("♪", vb, vl))
        return col
    }

    private fun sectionTitle(text: String): TextView =
        tv(text, 9f, cMuted, true).apply {
            letterSpacing = 0.12f
            setPadding(dp(2), dp(8), 0, dp(2))
        }

    private fun styleSeek(bar: SeekBar, max: Int) {
        bar.max = max
        bar.progressTintList = ColorStateList.valueOf(cRed)
        bar.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        bar.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#FF3A3A44"))
        // Dragging a slider must not scroll the page.
        bar.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) v.parent?.requestDisallowInterceptTouchEvent(true)
            false
        }
    }

    private fun sliderRow(glyph: String, bar: SeekBar, label: TextView): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundedBg(cCard, 10, cLine, 1)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            addView(tv(glyph, 16f, cRed, true).apply { setPadding(0, 0, dp(6), 0) })
            addView(bar, LinearLayout.LayoutParams(0, dp(36), 1f))
            addView(label.apply { setPadding(dp(8), 0, 0, 0); minWidth = dp(40); gravity = Gravity.END })
        }

    // ---- page: Aplikasi

    private fun buildAppsPage(csv: String): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(sectionTitle("APLIKASI CEPAT"))
        val packages = csv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val pm = packageManager
        val entries = ArrayList<Triple<String, String, android.graphics.drawable.Drawable>>()
        for (pkg in packages) {
            try {
                val icon = pm.getApplicationIcon(pkg)
                val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                entries.add(Triple(pkg, label, icon))
            } catch (e: Exception) {
                // uninstalled: skip
            }
        }
        if (entries.isEmpty()) {
            col.addView(tv("Belum ada aplikasi. Tambahkan di NexusPro → Tools → Game Mode → Aplikasi cepat.", 11f, cMuted).apply {
                setPadding(dp(2), dp(4), dp(2), 0)
            })
            return col
        }
        for (chunk in entries.chunked(4)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(8) }
            }
            for (i in 0 until 4) {
                val cell = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                }
                if (i < chunk.size) {
                    val (pkg, label, icon) = chunk[i]
                    cell.addView(ImageView(this).apply {
                        setImageDrawable(icon)
                        layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
                    })
                    cell.addView(tv(label, 9f, Color.WHITE).apply {
                        maxLines = 1
                        gravity = Gravity.CENTER
                        ellipsize = android.text.TextUtils.TruncateAt.END
                    })
                    cell.setOnClickListener { launchPackage(pkg) }
                }
                row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            col.addView(row)
        }
        return col
    }

    // ---- page: Info

    private fun buildInfoPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(sectionTitle("SESI & PERANGKAT"))
        val t = tv("", 12f, Color.WHITE).apply {
            setLineSpacing(0f, 1.25f)
            background = roundedBg(cCard, 10, cLine, 1)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        infoText = t
        col.addView(t)
        return col
    }

    // ---- open / close / drag

    private fun attachDrag(
        handle: View,
        lp: WindowManager.LayoutParams,
        wm: WindowManager,
        root: View,
    ) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        val slop = dp(8)
        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true
                    if (moved) {
                        if (panelOpen) movedWhileOpen = true
                        lp.x = (startX + dx).coerceAtLeast(0)
                        lp.y = (startY + dy).coerceAtLeast(0)
                        runCatching { wm.updateViewLayout(root, lp) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        if (!panelOpen) {
                            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                                .putInt(KEY_POS_X, lp.x)
                                .putInt(KEY_POS_Y, lp.y)
                                .apply()
                        }
                    } else {
                        togglePanel()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun togglePanel() {
        val p = panel ?: return
        val rv = rootView ?: return
        val lp = overlayParams ?: return
        val wm = windowManager ?: return
        panelOpen = !panelOpen
        if (panelOpen) {
            savedX = lp.x
            savedY = lp.y
            movedWhileOpen = false
            // Re-measure for the current orientation (portrait or landscape game).
            val w = panelWidth()
            val h = panelHeight()
            p.layoutParams = (p.layoutParams as LinearLayout.LayoutParams).also {
                it.width = w
                it.height = h
            }
            p.visibility = View.VISIBLE
            val (sw, sh) = screenSize()
            val margin = dp(8)
            lp.x = lp.x.coerceAtMost(sw - w - margin).coerceAtLeast(0)
            val needed = dp(52) + dp(6) + h
            lp.y = lp.y.coerceAtMost(sh - needed - margin).coerceAtLeast(0)
            runCatching { wm.updateViewLayout(rv, lp) }
            refreshStatus()
            sampleSystem()
        } else {
            p.visibility = View.GONE
            if (!movedWhileOpen) {
                lp.x = savedX
                lp.y = savedY
            } else {
                getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putInt(KEY_POS_X, lp.x).putInt(KEY_POS_Y, lp.y).apply()
            }
            runCatching { wm.updateViewLayout(rv, lp) }
        }
    }

    private fun closeBubble() {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ENABLED, false).remove(KEY_ARMED).apply()
        stopSelf()
    }

    private fun removeOverlay() {
        if (torchOn) setTorch(false)
        val v = rootView
        if (v != null) {
            runCatching { windowManager?.removeView(v) }
        }
        rootView = null
        panel = null
        tabButtons.clear()
        pages.clear()
        statRam = null; statBattery = null; statCpu = null; statGpu = null
        statFps = null; statPing = null; statTemp = null; statClock = null
        tileDnd = null; tileKeep = null; tileRot = null; tileTorch = null
        brightBar = null; volBar = null; brightLabel = null; volLabel = null
        infoText = null; boostButton = null; headerSub = null; perfHint = null
    }

    // ---------------------------------------------------------------- auto show

    /**
     * Auto mode: the bubble is visible while a game is in the foreground. If the foreground
     * app cannot be determined it stays visible (never hide by mistake). With auto mode off
     * the bubble is always visible.
     */
    private fun updateVisibility() {
        val rv = rootView ?: return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        var show = true
        val fg = currentForeground()
        if (prefs.getBoolean(KEY_AUTO, true)) {
            show = if (prefs.getBoolean(KEY_ONLY_NEXUS, true)) {
                // Only the game that was opened from inside NexusPro gets the bubble.
                val armed = prefs.getString(KEY_ARMED, "") ?: ""
                when {
                    armed.isEmpty() -> false
                    fg == null -> true
                    else -> fg == armed
                }
            } else if (fg != null) {
                fg == packageName || isGamePackage(this, fg)
            } else {
                true
            }
        }
        val target = if (show) View.VISIBLE else View.GONE
        if (rv.visibility != target) {
            rv.visibility = target
            if (!show && panelOpen) togglePanel()
        }
    }

    /** Best available answer to "which app is open now": accessibility first, usage stats second. */
    private fun currentForeground(): String? {
        if (NexusAccessibilityService.isEnabled(this)) {
            val a11y = NexusAccessibilityService.foreground
            if (a11y != null) {
                currentFg = a11y
                currentSource = "aksesibilitas"
                return a11y
            }
        }
        if (hasUsageAccess(this)) {
            val fg = foregroundPackage()
            if (fg != null) {
                currentFg = fg
                currentSource = "akses penggunaan"
                return fg
            }
        }
        return null
    }

    private fun markCurrentAsGame() {
        val fg = currentForeground() ?: currentFg
        if (fg == null || fg == packageName) {
            toast("Buka dulu game-nya, lalu tarik notifikasi dan ketuk \"Ini game\"")
            return
        }
        markGame(this, fg, true)
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(fg, 0)).toString()
        } catch (t: Throwable) {
            fg
        }
        toast("$label ditandai sebagai game")
        updateVisibility()
    }

    @Suppress("DEPRECATION")
    private fun foregroundPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return lastForeground
        val now = System.currentTimeMillis()
        val from = if (lastEventTime == 0L) now - 24L * 60L * 60L * 1000L else lastEventTime
        val events = try {
            usm.queryEvents(from, now)
        } catch (t: Throwable) {
            null
        } ?: return lastForeground
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND &&
                e.packageName != "com.android.systemui" &&
                e.packageName != "android"
            ) {
                lastForeground = e.packageName
            }
            if (e.timeStamp > lastEventTime) lastEventTime = e.timeStamp
        }
        if (lastForeground == null) {
            // Quiet phone: use the most recently used app instead.
            lastForeground = try {
                usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 3600_000L, now)
                    ?.maxByOrNull { it.lastTimeUsed }?.packageName
            } catch (t: Throwable) {
                null
            }
        }
        return lastForeground
    }

    private fun takeScreenshot() {
        if (!NexusAccessibilityService.isEnabled(this)) {
            toast("Aktifkan Aksesibilitas NexusPro di Tools > Pusat Izin untuk screenshot")
            return
        }
        if (panelOpen) togglePanel()
        handler.postDelayed({
            if (!NexusAccessibilityService.screenshot()) toast("Screenshot tidak didukung di HP ini")
        }, 350L)
    }

    // ---------------------------------------------------------------- status

    private fun availRam(): Long {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
    }

    private fun gameLabel(pkg: String?): String {
        if (pkg.isNullOrEmpty()) return ""
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (t: Throwable) {
            pkg
        }
    }

    /** The game this bubble belongs to (opened from NexusPro), or whatever is in front. */
    private fun activeGamePackage(): String {
        val armed = armedPackage(this)
        if (armed.isNotEmpty()) return armed
        val fg = currentFg
        return if (fg != null && fg != packageName) fg else ""
    }

    private fun refreshStatus() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        // ---- RAM
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val totalMb = mem.totalMem / (1024 * 1024)
        val usedMb = (mem.totalMem - mem.availMem) / (1024 * 1024)
        val ramPct = if (totalMb > 0) (usedMb * 100 / totalMb).toInt() else 0
        statRam?.let {
            it.value.text = "$ramPct%"
            it.sub.text = String.format(Locale.US, "%.1f / %.1f GB", usedMb / 1024.0, totalMb / 1024.0)
            it.bar?.fraction = ramPct / 100f
            it.card.visibility = if (prefs.getBoolean(KEY_SHOW_RAM, true)) View.VISIBLE else View.INVISIBLE
        }

        // ---- battery
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        var battTemp = Float.NaN
        var battPct = -1
        var charging = false
        if (battery != null) {
            val level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val tenths = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            val status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (level >= 0 && scale > 0) battPct = level * 100 / scale
            if (tenths != Int.MIN_VALUE) battTemp = tenths / 10f
        }
        statBattery?.let {
            it.value.text = if (battPct >= 0) "$battPct%" else "--"
            it.sub.text = if (charging) "mengisi" else "memakai baterai"
            it.card.visibility = if (prefs.getBoolean(KEY_SHOW_BATTERY, true)) View.VISIBLE else View.INVISIBLE
        }

        // ---- CPU / GPU / FPS (real values only, from the privileged shell)
        statCpu?.let {
            it.value.text = if (cpuPct >= 0) "$cpuPct%" else "--"
            it.sub.text = if (cpuMaxMhz > 0) {
                String.format(Locale.US, "maks %.2f GHz", cpuMaxMhz / 1000.0)
            } else {
                "butuh Shizuku"
            }
        }
        statGpu?.let {
            it.value.text = if (gpuPct >= 0) "$gpuPct%" else "--"
            it.sub.text = if (gpuPct >= 0) "beban GPU" else "tidak terbaca"
        }
        statFps?.let {
            it.value.text = if (fpsNow >= 0) "$fpsNow" else "--"
            it.sub.text = if (fpsNow >= 0) "frame/detik" else "butuh Shizuku"
        }

        // ---- ping
        pingOnce()
        statPing?.let {
            it.value.text = if (pingMs >= 0) "$pingMs" else "--"
            it.sub.text = if (pingMs >= 0) "ms" else "tidak ada koneksi"
        }

        // ---- temperature
        statTemp?.let {
            val cpuT = cpuTempC
            if (cpuT > 0f) {
                it.value.text = String.format(Locale.US, "%.0f°C", cpuT)
                it.sub.text = if (!battTemp.isNaN()) {
                    String.format(Locale.US, "CPU · bat %.1f°C", battTemp)
                } else {
                    "CPU"
                }
            } else {
                it.value.text = if (!battTemp.isNaN()) String.format(Locale.US, "%.1f°C", battTemp) else "--"
                it.sub.text = "baterai"
            }
            it.card.visibility = if (prefs.getBoolean(KEY_SHOW_TEMP, true)) View.VISIBLE else View.INVISIBLE
        }
        statClock?.let {
            it.value.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            it.sub.text = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date())
        }

        perfHint?.text = if (privAvailable) "" else
            "CPU, GPU, dan FPS dibaca lewat Shizuku atau root. Tanpa itu Android menutup datanya, jadi kolomnya kosong, bukan angka palsu."

        // ---- header + info
        val game = gameLabel(activeGamePackage())
        headerSub?.text = if (game.isNotEmpty()) game else "Siap bermain"

        infoText?.let { t ->
            val sb = StringBuilder()
            sb.append("Game: ").append(if (game.isNotEmpty()) game else "-").append('\n')
            val at = prefs.getLong(KEY_ARMED_AT, 0L)
            if (at > 0L) {
                val mins = ((System.currentTimeMillis() - at) / 60000L).coerceAtLeast(0)
                sb.append("Sesi: ").append(if (mins >= 60) "${mins / 60} j ${mins % 60} mnt" else "$mins menit").append('\n')
            }
            sb.append("Perangkat: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
            sb.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
            sb.append("RAM total: ").append(String.format(Locale.US, "%.1f GB", totalMb / 1024.0)).append('\n')
            sb.append("Penyimpanan kosong: ").append(String.format(Locale.US, "%.1f GB", availStorage() / 1073741824.0)).append('\n')
            sb.append("Sumber deteksi: ").append(currentSource).append('\n')
            sb.append("Shizuku/root: ").append(if (privAvailable) "aktif" else "tidak aktif")
            t.text = sb.toString()
        }

        updateDndLabel()
        refreshToolStates()
    }

    private fun refreshToolStates() {
        setTileActive(tileKeep, keepScreenOn, if (keepScreenOn) "Layar nyala: ON" else "Layar nyala")
        val locked = try {
            Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        } catch (t: Throwable) {
            false
        }
        setTileActive(tileRot, locked, if (locked) "Rotasi: kunci" else "Rotasi: auto")
        setTileActive(tileTorch, torchOn, if (torchOn) "Senter: ON" else "Senter")

        if (draggingBar != brightBar) {
            brightBar?.let { b ->
                val v = try {
                    Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
                } catch (t: Throwable) {
                    -1
                }
                if (v >= 0) {
                    val pct = (v * 100 / 255).coerceIn(1, 100)
                    b.progress = pct
                    brightLabel?.text = "$pct%"
                }
            }
        }
        if (draggingBar != volBar) {
            volBar?.let { b ->
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                b.progress = cur
                volLabel?.text = "${cur * 100 / b.max.coerceAtLeast(1)}%"
            }
        }
    }

    // ---------------------------------------------------------------- privileged sampler

    private fun buildSampleScript(pkg: String): String {
        val fps = if (pkg.isNotEmpty() && Regex("^[a-zA-Z0-9_.]+$").matches(pkg)) {
            "L=\$(dumpsys SurfaceFlinger --list 2>/dev/null | grep -F '$pkg' | grep -i surfaceview | tail -n 1); " +
                "if [ -z \"\$L\" ]; then L=\$(dumpsys SurfaceFlinger --list 2>/dev/null | grep -F '$pkg' | " +
                "grep -v -i 'bounds for' | grep -v -i 'background for' | tail -n 1); fi; " +
                "if [ -n \"\$L\" ]; then dumpsys SurfaceFlinger --latency \"\$L\" 2>/dev/null; fi; "
        } else {
            ""
        }
        return "echo '#CPU'; head -n 1 /proc/stat; " +
            "echo '#GPU'; for f in /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage /sys/class/kgsl/kgsl-3d0/gpubusy " +
            "/sys/class/devfreq/*gpu*/load /sys/class/devfreq/*mali*/load /sys/kernel/gpu/gpu_busy " +
            "/sys/module/ged/parameters/gpu_loading; do if [ -r \"\$f\" ]; then echo \"\$f\"; cat \"\$f\" 2>/dev/null; break; fi; done; " +
            "echo '#FREQ'; cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq 2>/dev/null; " +
            "echo '#TEMP'; for z in /sys/class/thermal/thermal_zone*; do t=\$(cat \$z/type 2>/dev/null); " +
            "v=\$(cat \$z/temp 2>/dev/null); echo \"\$t \$v\"; done; " +
            "echo '#FPS'; " + fps + "true"
    }

    private fun sampleSystem() {
        val now = SystemClock.elapsedRealtime()
        if (sampling || now < nextPrivTry) return
        sampling = true
        val pkg = activeGamePackage()
        Thread {
            try {
                val r = PrivShell.exec(buildSampleScript(pkg))
                if (!r.ok || r.output.isBlank()) {
                    privAvailable = false
                    cpuPct = -1; gpuPct = -1; fpsNow = -1; cpuMaxMhz = -1; cpuTempC = -1f
                    nextPrivTry = SystemClock.elapsedRealtime() + 20_000L
                } else {
                    privAvailable = true
                    parseSample(r.output)
                }
            } catch (t: Throwable) {
                privAvailable = false
                nextPrivTry = SystemClock.elapsedRealtime() + 20_000L
            } finally {
                sampling = false
            }
        }.start()
    }

    private fun parseSample(out: String) {
        val sections = HashMap<String, MutableList<String>>()
        var cur = ""
        for (line in out.lines()) {
            val l = line.trim()
            if (l.startsWith("#") && l.length <= 6) {
                cur = l
                sections[cur] = ArrayList()
            } else if (cur.isNotEmpty() && l.isNotEmpty()) {
                sections[cur]?.add(l)
            }
        }

        // CPU usage from two /proc/stat samples.
        sections["#CPU"]?.firstOrNull()?.let { line ->
            val p = line.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (p.size >= 4) {
                val idle = p[3] + (p.getOrNull(4) ?: 0L)
                val total = p.take(8).sum()
                if (prevCpuTotal > 0L && total > prevCpuTotal) {
                    val dT = total - prevCpuTotal
                    val dI = idle - prevCpuIdle
                    cpuPct = (100L * (dT - dI) / dT).toInt().coerceIn(0, 100)
                }
                prevCpuTotal = total
                prevCpuIdle = idle
            }
        }

        // GPU load: first readable file wins.
        val gpu = sections["#GPU"]
        gpuPct = -1
        if (gpu != null && gpu.size >= 2) {
            val path = gpu[0]
            val value = gpu[1]
            val nums = Regex("\\d+").findAll(value).map { it.value.toLong() }.toList()
            gpuPct = when {
                path.endsWith("gpubusy") && nums.size >= 2 && nums[1] > 0L ->
                    (nums[0] * 100 / nums[1]).toInt()
                nums.isNotEmpty() -> nums[0].toInt()
                else -> -1
            }.let { if (it in 0..100) it else -1 }
        }

        // CPU max current frequency across cores (kHz -> MHz).
        val freqs = sections["#FREQ"]?.mapNotNull { it.toLongOrNull() } ?: emptyList()
        cpuMaxMhz = if (freqs.isNotEmpty()) ((freqs.maxOrNull() ?: 0L) / 1000L).toInt() else -1

        // CPU / SoC temperature: hottest CPU-like thermal zone.
        var best = -1f
        for (line in sections["#TEMP"] ?: emptyList()) {
            val parts = line.split(" ")
            if (parts.size < 2) continue
            val type = parts[0].lowercase(Locale.US)
            if (!(type.contains("cpu") || type.contains("soc") || type.contains("tsens") ||
                    type.contains("cluster") || type.contains("mtk"))
            ) continue
            val raw = parts[1].toFloatOrNull() ?: continue
            val c = if (raw > 1000f) raw / 1000f else raw
            if (c in 15f..120f && c > best) best = c
        }
        cpuTempC = best

        // FPS: presented frames in the last second of the game's layer.
        fpsNow = -1
        val fpsLines = sections["#FPS"]
        if (fpsLines != null && fpsLines.size > 2) {
            val times = ArrayList<Long>()
            for (row in fpsLines.drop(1)) {
                val cols = row.split(Regex("\\s+"))
                if (cols.size < 3) continue
                val t = cols[2].toLongOrNull() ?: continue
                if (t > 0L && t != Long.MAX_VALUE) times.add(t)
            }
            if (times.size > 2) {
                val newest = times.maxOrNull() ?: 0L
                val recent = times.count { it > newest - 1_000_000_000L }
                val span = newest - (times.minOrNull() ?: newest)
                fpsNow = if (span >= 1_000_000_000L) recent else
                    ((times.size - 1) * 1_000_000_000L / span.coerceAtLeast(1L)).toInt()
                if (fpsNow > 240) fpsNow = -1
            }
        }
    }

    private fun pingOnce() {
        if (pinging) return
        pinging = true
        Thread {
            pingMs = try {
                val t0 = SystemClock.elapsedRealtime()
                java.net.Socket().use { sock ->
                    sock.connect(java.net.InetSocketAddress("1.1.1.1", 443), 1500)
                }
                (SystemClock.elapsedRealtime() - t0).toInt()
            } catch (t: Throwable) {
                -1
            }
            pinging = false
        }.start()
    }

    // ---------------------------------------------------------------- tools

    private fun writeSettingsReady(): Boolean {
        if (Settings.System.canWrite(this)) return true
        toast("Aktifkan izin \"Ubah pengaturan sistem\" untuk NexusPro, lalu kembali ke game")
        val intent = Intent(
            Settings.ACTION_MANAGE_WRITE_SETTINGS,
            android.net.Uri.parse("package:$packageName")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(intent) }
        return false
    }

    private fun setBrightnessPercent(pct: Int) {
        val v = (pct * 255 / 100).coerceIn(1, 255)
        if (Settings.System.canWrite(this)) {
            runCatching {
                Settings.System.putInt(
                    contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
            }
        } else if (PrivShell.shizukuReady()) {
            Thread {
                PrivShell.exec("settings put system screen_brightness_mode 0; settings put system screen_brightness $v")
            }.start()
        } else if (draggingBar == null || brightBar?.tag != "warned") {
            brightBar?.tag = "warned"
            writeSettingsReady()
        }
    }

    private fun toggleRotationLock() {
        if (!writeSettingsReady()) return
        val locked = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        runCatching {
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (locked) 1 else 0)
        }
        toast(if (locked) "Rotasi otomatis aktif" else "Rotasi dikunci")
        refreshToolStates()
    }

    private fun toggleKeepScreen() {
        val lp = overlayParams ?: return
        val rv = rootView ?: return
        keepScreenOn = !keepScreenOn
        lp.flags = if (keepScreenOn) {
            lp.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        } else {
            lp.flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.inv()
        }
        runCatching { windowManager?.updateViewLayout(rv, lp) }
        toast(if (keepScreenOn) "Layar tetap menyala selama bubble aktif" else "Layar kembali normal")
        refreshToolStates()
    }

    private fun torchCameraId(): String? = try {
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    } catch (t: Throwable) {
        null
    }

    private fun setTorch(on: Boolean) {
        val id = torchCameraId()
        if (id == null) {
            toast("HP ini tidak punya lampu senter")
            return
        }
        try {
            (getSystemService(Context.CAMERA_SERVICE) as CameraManager).setTorchMode(id, on)
            torchOn = on
        } catch (t: Throwable) {
            toast("Senter tidak bisa dinyalakan sekarang")
        }
    }

    private fun toggleTorch() {
        setTorch(!torchOn)
        refreshToolStates()
    }

    // ---------------------------------------------------------------- actions

    private fun toast(message: String) {
        handler.post { Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show() }
    }

    private fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    private fun shizukuExec(command: String): Boolean = try {
        @Suppress("DEPRECATION")
        val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
        val drain = Thread { runCatching { process.errorStream.readBytes() } }
        drain.start()
        runCatching { process.inputStream.readBytes() }
        val code = process.waitFor()
        drain.join(2000)
        code == 0
    } catch (t: Throwable) {
        false
    }

    private fun boostRam() {
        if (boostBusy) return
        boostBusy = true
        boostButton?.text = "MEMBERSIHKAN..."
        Thread {
            val before = availRam()
            var done = false
            if (shizukuReady()) {
                done = shizukuExec("am kill-all")
            }
            if (!done) {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                for (app in packageManager.getInstalledApplications(0)) {
                    if (app.flags and ApplicationInfo.FLAG_SYSTEM == 0 && app.packageName != packageName) {
                        runCatching { am.killBackgroundProcesses(app.packageName) }
                    }
                }
            }
            Thread.sleep(1200)
            val freedMb = (availRam() - before).coerceAtLeast(0) / (1024 * 1024)
            handler.post {
                boostButton?.text = "+$freedMb MB LEGA"
                refreshStatus()
            }
            toast("Boost RAM selesai: $freedMb MB lega")
            handler.postDelayed({
                boostButton?.text = "BOOST"
                boostBusy = false
            }, 2500L)
        }.start()
    }

    private fun availStorage(): Long =
        StatFs(Environment.getDataDirectory().path).let { it.availableBlocksLong * it.blockSizeLong }

    private fun cleanCache() {
        toast("Membersihkan cache...")
        Thread {
            val before = availStorage()
            runCatching { cacheDir?.deleteRecursively() }
            runCatching { externalCacheDir?.deleteRecursively() }
            if (shizukuReady()) {
                shizukuExec("pm trim-caches 999G")
                Thread.sleep(800)
                val freedMb = (availStorage() - before).coerceAtLeast(0) / (1024 * 1024)
                toast("Cache semua aplikasi dibersihkan: $freedMb MB")
            } else {
                toast("Cache NexusPro dibersihkan. Aktifkan Shizuku untuk bersihkan cache semua aplikasi.")
            }
        }.start()
    }

    private fun updateDndLabel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val granted = nm.isNotificationPolicyAccessGranted
        val on = granted && nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL &&
            nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        val label = when {
            !granted -> "DND: beri izin"
            on -> "DND: aktif"
            else -> "DND: mati"
        }
        setTileActive(tileDnd, on, label)
    }

    private fun toggleDnd() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Beri izin 'Jangan ganggu' untuk NexusPro, lalu kembali ke game")
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { startActivity(intent) }
            return
        }
        val current = nm.currentInterruptionFilter
        if (current == NotificationManager.INTERRUPTION_FILTER_ALL ||
            current == NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        ) {
            previousDndFilter = NotificationManager.INTERRUPTION_FILTER_ALL
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            toast("Jangan ganggu aktif")
        } else {
            nm.setInterruptionFilter(previousDndFilter)
            toast("Jangan ganggu dimatikan")
        }
        updateDndLabel()
    }

    private fun launchPackage(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            toast("Aplikasi tidak bisa dibuka")
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(intent) }
    }
}
