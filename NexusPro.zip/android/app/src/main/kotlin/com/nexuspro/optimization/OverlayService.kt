package com.nexuspro.optimization

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.ActivityOptions
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.ProgressBar
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import kotlin.math.roundToInt
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Game Mode overlay: a draggable bubble that expands into a small panel on top of
 * any app (system status, RAM boost, cache cleaning, Do Not Disturb, quick launch).
 *
 * Needs the "Display over other apps" permission. Runs as a foreground service so
 * Android does not kill it while a game is in the foreground.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.nexuspro.optimization.overlay.STOP"
        const val PREFS = "nexuspro_overlay"
        const val KEY_QUICK_APPS = "quick_apps"
        const val KEY_SHOW_RAM = "show_ram"
        const val KEY_SHOW_BATTERY = "show_battery"
        const val KEY_SHOW_TEMP = "show_temp"
        const val KEY_AUTO = "auto_show"
        const val KEY_BOOT = "start_on_boot"
        const val KEY_GAMES = "game_packages"
        const val KEY_MANUAL = "manual_games"
        const val KEY_ENABLED = "overlay_enabled"
        const val ACTION_MARK = "com.nexuspro.optimization.overlay.MARK_GAME"
        private const val KEY_BUBBLE_DP = "bubble_dp"
        private const val KEY_ALPHA = "bubble_alpha"
        private const val KEY_HUD = "hud_on"
        private const val KEY_SNAP = "snap_edge"
        private const val KEY_WELLBEING = "wellbeing_min"
        private const val KEY_CROSS = "crosshair"
        private const val KEY_NET = "net_boost"
        private const val KEY_EDGE = "edge_lock"
        private const val KEY_FLOAT = "float_window"
        private val WELLBEING_STEPS = intArrayOf(0, 30, 45, 60, 90)
        private const val KEY_POS_X = "pos_x"
        private const val KEY_POS_Y = "pos_y"
        private const val CHANNEL_ID = "nexuspro_overlay"
        private const val NOTIF_ID = 4721

        // Value of ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE (Android 14+).
        private const val FGS_TYPE_SPECIAL_USE = 0x40000000

        @Volatile
        var running: Boolean = false
            private set

        /** Last app seen in the foreground, and how it was detected (for diagnostics). */
        @Volatile
        var currentFg: String? = null

        @Volatile
        var currentSource: String = "-"

        /** Prefixes of well-known games, used when the app has no "game" category. */
        private val KNOWN_GAMES = listOf(
            "com.mobile.legends", "com.mobilelegends", "com.moonton.", "com.tencent.ig",
            "com.tencent.tmgp", "com.pubg.", "com.vng.pubg", "com.rekoo.pubgm", "com.dts.freefire",
            "com.garena.game", "com.garena.", "com.activision.", "com.miHoYo.", "com.HoYoverse.",
            "com.levelinfinite.", "com.roblox.", "com.supercell.", "com.riotgames.", "com.mojang.",
            "com.ea.game", "com.gameloft.", "com.netease.", "com.proximabeta.", "com.krafton.",
            "com.epicgames.", "com.nianticlabs.", "com.kiloo.", "com.king.", "com.lilithgame.",
            "com.fanatee.", "com.hypergryph.", "com.kurogame.", "com.ngame.", "com.unity3d.",
        )

        private fun csv(prefs: android.content.SharedPreferences, key: String): Set<String> =
            (prefs.getString(key, "") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

        /** True when [pkg] is a game: in the user's lists, flagged as a game, or well known. */
        fun isGamePackage(context: Context, pkg: String?): Boolean {
            if (pkg.isNullOrEmpty()) return false
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (pkg in csv(prefs, KEY_GAMES) || pkg in csv(prefs, KEY_MANUAL)) return true
            try {
                val ai = context.packageManager.getApplicationInfo(pkg, 0)
                if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) return true
                @Suppress("DEPRECATION")
                if (ai.flags and ApplicationInfo.FLAG_IS_GAME != 0) return true
            } catch (t: Throwable) {
                // not installed / hidden: fall through to the name list
            }
            return KNOWN_GAMES.any { pkg.startsWith(it) }
        }

        fun markGame(context: Context, pkg: String, game: Boolean) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val set = csv(prefs, KEY_MANUAL).toMutableSet()
            if (game) set.add(pkg) else set.remove(pkg)
            prefs.edit().putString(KEY_MANUAL, set.joinToString(",")).apply()
        }

        /**
         * A game was opened from inside NexusPro (Games tab / Game Mode). Remember it as a game
         * and make sure the bubble service is running, so the bubble is there when the game appears.
         */
        fun onGameLaunched(context: Context, pkg: String) {
            markGame(context, pkg, true)
            currentFg = pkg
            currentSource = "peluncur NexusPro"
            if (canDraw(context)) runCatching { start(context) }
        }

        /** Called by the accessibility service the moment another app comes to the front. */
        fun onForegroundChanged(context: Context, pkg: String) {
            currentFg = pkg
            currentSource = "aksesibilitas"
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (!running &&
                prefs.getBoolean(KEY_ENABLED, false) &&
                prefs.getBoolean(KEY_AUTO, true) &&
                canDraw(context) &&
                isGamePackage(context, pkg)
            ) {
                runCatching { start(context) }
            }
        }

        fun canDraw(context: Context): Boolean =
            Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context)

        /** "Usage access": lets the overlay see which app is in the foreground. */
        fun hasUsageAccess(context: Context): Boolean = try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (t: Throwable) {
            false
        }

        fun start(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, true).apply()
            val intent = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, false).apply()
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var rootView: LinearLayout? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var statRam: TextView? = null
    private var statBattery: TextView? = null
    private var statTemp: TextView? = null
    private var statPing: TextView? = null
    private var statClock: TextView? = null
    private var statApp: TextView? = null
    private var dndButton: TextView? = null
    private var awakeLabel: TextView? = null
    private var rotateLabel: TextView? = null
    private val tabPages = ArrayList<View>()
    private val tabButtons = ArrayList<TextView>()
    private var keepAwake = false
    private var statFps: TextView? = null
    private var statCpu: TextView? = null
    private var statGpu: TextView? = null
    private var statDisplay: TextView? = null
    private var statPlay: TextView? = null
    private var statCurrent: TextView? = null
    private var statStorage: TextView? = null
    private var hudView: TextView? = null
    private var privHint: TextView? = null
    private val modeButtons = ArrayList<TextView>()
    private val sampler by lazy { StatsSampler(this) }
    private var playingPkg: String? = null
    private var playStart = 0L
    private var crosshairView: CrosshairView? = null
    private val edgeViews = ArrayList<View>()
    private var fullShield: View? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var focusOn = false
    private var wellbeingNotified = 0
    private var sparkView: SparkView? = null
    private var fpsStatsText: TextView? = null
    private var netText: TextView? = null
    private var ramDetailText: TextView? = null
    private val coreRows = ArrayList<Pair<TextView, ProgressBar>>()
    private var recLabel: TextView? = null
    private var edgeLabel: TextView? = null
    private var lockLabel: TextView? = null
    private var focusLabel: TextView? = null
    private var netLabel: TextView? = null
    private var crossLabel: TextView? = null
    private var hudLabel: TextView? = null
    private var snapLabel: TextView? = null
    private var wellbeingLabel: TextView? = null
    private var floatLabel: TextView? = null
    private var panelOpen = false
    private var previousDndFilter = NotificationManager.INTERRUPTION_FILTER_ALL

    private var lastForeground: String? = null
    private var lastEventTime = 0L
    private var tick = 0
    @Volatile private var pingMs = -1
    @Volatile private var pinging = false

    private val ticker = object : Runnable {
        override fun run() {
            updateVisibility()
            tick++
            if (tick % 2 == 0) requestSample()
            updateHud()
            checkWellbeing()
            if (panelOpen && tick % 2 == 0) refreshStatus()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (intent?.action == ACTION_MARK) {
            markCurrentAsGame()
        }
        if (!canDraw(this)) {
            toast("Izin 'Tampil di atas aplikasi lain' belum aktif")
            stopSelf()
            return START_NOT_STICKY
        }
        if (rootView == null) {
            try {
                buildOverlay()
            } catch (e: Exception) {
                toast("Overlay gagal dibuat: ${e.message ?: "tidak diketahui"}")
                stopSelf()
                return START_NOT_STICKY
            }
        }
        running = true
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        // Sticky: if a strict ROM kills the service, Android brings it back.
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removeOverlay()
        removeAuxWindows()
        runCatching { wifiLock?.let { if (it.isHeld) it.release() } }
        super.onDestroy()
    }

    /** Some ROMs kill the service when the app is swiped away; bring it back. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (running && getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)) {
            runCatching {
                val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent(applicationContext, OverlayService::class.java)
                val flags = PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                val pi = if (Build.VERSION.SDK_INT >= 26) {
                    PendingIntent.getForegroundService(applicationContext, 7, intent, flags)
                } else {
                    PendingIntent.getService(applicationContext, 7, intent, flags)
                }
                am.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 1500L, pi)
            }
        }
        super.onTaskRemoved(rootIntent)
    }

    // ---------------------------------------------------------------- foreground

    private fun startAsForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, FGS_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Game Mode Overlay", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = Intent(this, OverlayService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val markIntent = Intent(this, OverlayService::class.java).setAction(ACTION_MARK)
        val markPending = PendingIntent.getService(
            this, 2, markIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("NexusPro Game Mode aktif")
            .setContentText("Bubble tidak muncul di game? Buka game, tarik notifikasi, ketuk \"Ini game\".")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(openPending)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_add, "Ini game", markPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Matikan", stopPending)
            .build()
    }

    // ---------------------------------------------------------------- overlay UI

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun roundedBg(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun buildOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt(KEY_POS_X, dp(8))
        lp.y = prefs.getInt(KEY_POS_Y, dp(120))
        overlayParams = lp

        // Bubble = the NexusPro logo, cropped to a circle with a glowing blue ring.
        val bubble = ImageView(this).apply {
            setImageResource(R.drawable.nexus_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#FF0B1220"))
                setStroke(dp(2), RED)
            }
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            elevation = dp(6).toFloat()
            alpha = prefs.getInt(KEY_ALPHA, 100).coerceIn(30, 100) / 100f
            layoutParams = LinearLayout.LayoutParams(bubbleSize(), bubbleSize())
        }

        val panelView = buildPanel()
        panelView.visibility = View.GONE
        panel = panelView

        val hud = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            background = roundedBg(Color.parseColor("#B3000000"), 8)
            setPadding(dp(6), dp(2), dp(6), dp(2))
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(3) }
        }
        hudView = hud

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bubble)
            addView(hud)
            addView(panelView)
        }
        rootView = root

        attachDrag(bubble, lp, wm, root)
        wm.addView(root, lp)

        // Features that live in their own windows.
        applyCrosshair()
        applyEdgeLock()
        if (prefs.getBoolean(KEY_NET, false)) setNetBoost(true, silent = true)
    }

    private fun bubbleSize(): Int =
        dp(getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_BUBBLE_DP, 52).coerceIn(36, 80))

    /** Rebuilds the bubble after a size / transparency change. */
    private fun rebuildOverlay() {
        panelOpen = false
        removeOverlay()
        runCatching { buildOverlay() }
        updateVisibility()
    }

    // ROG Game Genie style: black and red, tab rail on the left, three pages.
    private val RED = Color.parseColor("#FFE4002B")
    private val PANEL_BG = Color.parseColor("#F2101014")
    private val CARD_BG = Color.parseColor("#FF1B1B22")
    private val TEXT_DIM = Color.parseColor("#FF9A9AA8")

    private fun panelWidth() = dp(310)
    private fun panelHeight() = dp(290)

    private fun lay(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams =
        if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)

    private fun buildPanel(): LinearLayout {
        tabPages.clear()
        tabButtons.clear()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBg(PANEL_BG, 14).apply { setStroke(dp(1), Color.parseColor("#55E4002B")) }
            layoutParams = LinearLayout.LayoutParams(panelWidth(), panelHeight()).apply { topMargin = dp(6) }
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(4))
        }
        header.addView(TextView(this).apply {
            text = "NEXUSPRO"
            setTextColor(RED)
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.15f
        })
        header.addView(TextView(this).apply {
            text = "  GAME GENIE"
            setTextColor(Color.WHITE)
            textSize = 11f
            letterSpacing = 0.1f
            layoutParams = lay(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        header.addView(TextView(this).apply {
            text = "\u2582"
            setTextColor(TEXT_DIM)
            textSize = 14f
            setPadding(dp(10), dp(2), dp(10), dp(2))
            setOnClickListener { minimizePanel() }
        })
        header.addView(TextView(this).apply {
            text = "\u2715"
            setTextColor(TEXT_DIM)
            textSize = 16f
            setPadding(dp(10), dp(2), dp(10), dp(2))
            setOnClickListener { if (panelOpen) togglePanel() }
        })
        container.addView(header)

        // Body = tab rail + pages
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = lay(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val rail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(4))
            layoutParams = lay(dp(60), ViewGroup.LayoutParams.MATCH_PARENT)
        }
        val pages = FrameLayout(this).apply {
            layoutParams = lay(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        }

        val tabNames = listOf(
            "\u26A1" to "Performa",
            "\uD83D\uDCCA" to "Detail",
            "\uD83D\uDEE0" to "Alat",
            "\uD83C\uDFAE" to "Aplikasi",
            "\u2699\uFE0F" to "Setelan",
        )
        val pageViews = listOf(
            buildPerformPage(), buildDetailPage(), buildToolsPage(), buildAppsPage(), buildSettingsPage()
        )
        for ((idx, pair) in tabNames.withIndex()) {
            val tab = TextView(this).apply {
                text = pair.first + "\n" + pair.second
                gravity = Gravity.CENTER
                textSize = 9f
                setPadding(dp(1), dp(6), dp(1), dp(6))
                layoutParams = lay(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(3)
                }
                setOnClickListener { selectTab(idx) }
            }
            tabButtons.add(tab)
            rail.addView(tab)
            val page = pageViews[idx]
            page.visibility = View.GONE
            tabPages.add(page)
            pages.addView(page)
        }
        body.addView(rail)
        body.addView(pages)
        container.addView(body)
        selectTab(0)
        return container
    }

    private fun selectTab(index: Int) {
        for (i in tabPages.indices) {
            tabPages[i].visibility = if (i == index) View.VISIBLE else View.GONE
        }
        for (i in tabButtons.indices) {
            val on = i == index
            tabButtons[i].setTextColor(if (on) Color.WHITE else TEXT_DIM)
            tabButtons[i].background = if (on) roundedBg(Color.parseColor("#66E4002B"), 10) else null
        }
    }

    private fun scrollPage(content: LinearLayout): ScrollView = ScrollView(this).apply {
        isVerticalScrollBarEnabled = false
        layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        content.setPadding(dp(4), dp(2), dp(8), dp(8))
        addView(content)
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(TEXT_DIM)
        textSize = 10f
        letterSpacing = 0.1f
        setPadding(dp(2), dp(8), 0, dp(4))
    }

    private fun statCard(label: String, holder: (TextView) -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = roundedBg(CARD_BG, 10)
            setPadding(dp(4), dp(8), dp(4), dp(8))
            layoutParams = lay(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            }
        }
        val value = TextView(this).apply {
            text = "--"
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
        }
        box.addView(value)
        box.addView(TextView(this).apply {
            text = label
            setTextColor(TEXT_DIM)
            textSize = 10f
            gravity = Gravity.CENTER
        })
        holder(value)
        return box
    }

    private fun hRow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = lay(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(4)
        }
    }

    private fun buildPerformPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        col.addView(sectionLabel("MODE PERFORMA"))
        val modes = hRow()
        modeButtons.clear()
        for ((key, label) in listOf("hemat" to "HEMAT", "seimbang" to "SEIMBANG", "gamer" to "GAMER PRO")) {
            val b = TextView(this).apply {
                text = label
                tag = key
                gravity = Gravity.CENTER
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(2), dp(9), dp(2), dp(9))
                layoutParams = lay(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                }
                setOnClickListener { applyMode(key) }
            }
            modeButtons.add(b)
            modes.addView(b)
        }
        col.addView(modes)
        updateModeButtons()

        col.addView(sectionLabel("LIVE"))
        val r1 = hRow()
        r1.addView(statCard("FPS") { statFps = it })
        r1.addView(statCard("CPU") { statCpu = it })
        r1.addView(statCard("GPU") { statGpu = it })
        col.addView(r1)
        val r2 = hRow()
        r2.addView(statCard("RAM") { statRam = it })
        r2.addView(statCard("SUHU") { statTemp = it })
        r2.addView(statCard("BATERAI") { statBattery = it })
        col.addView(r2)
        val r3 = hRow()
        r3.addView(statCard("PING") { statPing = it })
        r3.addView(statCard("LAYAR") { statDisplay = it })
        r3.addView(statCard("MAIN") { statPlay = it })
        col.addView(r3)
        val r4 = hRow()
        r4.addView(statCard("ARUS") { statCurrent = it })
        r4.addView(statCard("PENYIMPANAN") { statStorage = it })
        r4.addView(statCard("JAM") { statClock = it })
        col.addView(r4)

        col.addView(TextView(this).apply {
            setTextColor(TEXT_DIM)
            textSize = 10f
            setPadding(dp(2), dp(8), 0, dp(2))
            statApp = this
        })
        col.addView(TextView(this).apply {
            text = "FPS, CPU, dan GPU asli butuh Shizuku atau root. Ketuk untuk membuka NexusPro > Tools > Pusat Izin."
            setTextColor(Color.parseColor("#FFFFB74D"))
            textSize = 10f
            setPadding(dp(2), dp(2), 0, dp(4))
            visibility = View.GONE
            privHint = this
            setOnClickListener { launchPackage(packageName) }
        })

        col.addView(TextView(this).apply {
            text = "BOOST"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 15f
            letterSpacing = 0.2f
            setTypeface(typeface, Typeface.BOLD)
            background = roundedBg(RED, 12)
            setPadding(dp(8), dp(12), dp(8), dp(12))
            layoutParams = lay(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
            }
            setOnClickListener { boostRam() }
        })
        return scrollPage(col)
    }

    // ---- performance modes, live stats and HUD

    private fun updateModeButtons() {
        val cur = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("perf_mode", "seimbang")
        for (b in modeButtons) {
            val on = b.tag == cur
            b.setTextColor(if (on) Color.WHITE else TEXT_DIM)
            b.background = roundedBg(if (on) RED else CARD_BG, 10)
        }
    }

    private fun setDnd(on: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return
        val current = nm.currentInterruptionFilter
        if (on) {
            if (current == NotificationManager.INTERRUPTION_FILTER_ALL ||
                current == NotificationManager.INTERRUPTION_FILTER_UNKNOWN
            ) {
                previousDndFilter = NotificationManager.INTERRUPTION_FILTER_ALL
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            }
        } else if (current != NotificationManager.INTERRUPTION_FILTER_ALL) {
            nm.setInterruptionFilter(previousDndFilter)
        }
        updateDndLabel()
    }

    private fun applyMode(mode: String) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("perf_mode", mode).apply()
        updateModeButtons()
        val cmd = when (mode) {
            "gamer" -> "cmd power set-fixed-performance-mode-enabled true; settings put global low_power 0"
            "hemat" -> "cmd power set-fixed-performance-mode-enabled false; settings put global low_power 1"
            else -> "cmd power set-fixed-performance-mode-enabled false; settings put global low_power 0"
        }
        when (mode) {
            "gamer" -> {
                setDnd(true)
                boostRam()
            }
            "seimbang" -> setDnd(false)
        }
        Thread {
            val r = PrivShell.exec(cmd)
            val label = when (mode) {
                "gamer" -> "GAMER PRO"
                "hemat" -> "HEMAT"
                else -> "SEIMBANG"
            }
            if (r.ok) {
                toast("Mode $label aktif")
            } else {
                // Without Shizuku/root only the parts that need no special access can run.
                val fallback = runCatching {
                    if (checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") ==
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        Settings.Global.putInt(contentResolver, "low_power", if (mode == "hemat") 1 else 0)
                        true
                    } else {
                        false
                    }
                }.getOrDefault(false)
                toast(
                    if (fallback) "Mode $label aktif (sebagian)"
                    else "Mode $label sebagian aktif. Aktifkan Shizuku/root untuk efek penuh"
                )
            }
        }.start()
    }

    private fun requestSample() {
        val rv = rootView ?: return
        if (rv.visibility != View.VISIBLE) return
        val fg = currentFg
        val gamePkg = if (fg != null && fg != packageName && isGamePackage(this, fg)) fg else null
        sampler.request(gamePkg)
    }

    private fun playTime(): String {
        if (playingPkg == null) return "--:--"
        val sec = ((SystemClock.elapsedRealtime() - playStart) / 1000L).coerceAtLeast(0)
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val ss = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, ss)
        else String.format(Locale.US, "%02d:%02d", m, ss)
    }

    private fun fpsColor(fps: Int): Int = when {
        fps >= 50 -> Color.parseColor("#FF4CAF50")
        fps >= 30 -> Color.parseColor("#FFFFC107")
        else -> Color.parseColor("#FFFF5252")
    }

    private fun loadColor(pct: Int): Int = when {
        pct >= 90 -> Color.parseColor("#FFFF5252")
        pct >= 70 -> Color.parseColor("#FFFFC107")
        else -> Color.WHITE
    }

    private fun updateHud() {
        val h = hudView ?: return
        val fg = currentFg
        val inGame = fg != null && fg != packageName && isGamePackage(this, fg)
        if (!sp().getBoolean(KEY_HUD, true) || !inGame || panelOpen || rootView?.visibility != View.VISIBLE) {
            h.visibility = View.GONE
            return
        }
        val snap = sampler.snapshot
        if (snap.fps >= 0) {
            h.text = "${snap.fps} FPS" + if (snap.tempC > 0) " \u00B7 ${snap.tempC.roundToInt()}\u00B0" else ""
            h.setTextColor(fpsColor(snap.fps))
        } else {
            h.text = "\u25B6 " + playTime()
            h.setTextColor(Color.WHITE)
        }
        h.visibility = View.VISIBLE
    }

    private fun tile(emoji: String, label: String, onClick: () -> Unit): Pair<View, TextView> {
        val labelView = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 10f
            gravity = Gravity.CENTER
            maxLines = 2
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = roundedBg(CARD_BG, 10)
            setPadding(dp(2), dp(8), dp(2), dp(8))
            layoutParams = lay(0, dp(62), 1f).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            }
            addView(TextView(this@OverlayService).apply {
                text = emoji
                textSize = 18f
                gravity = Gravity.CENTER
            })
            addView(labelView)
            setOnClickListener { onClick() }
        }
        return box to labelView
    }

    private fun slider(
        title: String,
        max: Int,
        progress: Int,
        onDone: ((Int) -> Unit)? = null,
        onChange: (Int) -> Unit,
    ): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBg(CARD_BG, 10)
            setPadding(dp(10), dp(6), dp(10), dp(4))
            layoutParams = lay(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
                marginStart = dp(2)
                marginEnd = dp(2)
            }
        }
        box.addView(TextView(this).apply {
            text = title
            setTextColor(TEXT_DIM)
            textSize = 10f
        })
        box.addView(SeekBar(this).apply {
            this.max = max
            this.progress = progress.coerceIn(0, max)
            progressTintList = ColorStateList.valueOf(RED)
            thumbTintList = ColorStateList.valueOf(RED)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser) onChange(value)
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    if (sb != null) onDone?.invoke(sb.progress)
                }
            })
        })
        return box
    }

    /** Tile whose label changes at runtime; [holder] receives the label view. */
    private fun dynTile(emoji: String, label: String, holder: (TextView) -> Unit, onClick: () -> Unit): View {
        val t = tile(emoji, label, onClick)
        holder(t.second)
        return t.first
    }

    private fun infoText(holder: (TextView) -> Unit): TextView = TextView(this).apply {
        setTextColor(Color.WHITE)
        textSize = 11f
        setPadding(dp(4), dp(4), dp(4), dp(2))
        holder(this)
    }

    private fun buildDetailPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(sectionLabel("GRAFIK FPS"))
        val spark = SparkView(this).apply {
            background = roundedBg(CARD_BG, 10)
            layoutParams = lay(ViewGroup.LayoutParams.MATCH_PARENT, dp(72)).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            }
        }
        sparkView = spark
        col.addView(spark)
        col.addView(infoText { fpsStatsText = it })

        col.addView(sectionLabel("CLOCK CPU PER CORE"))
        coreRows.clear()
        val n = Runtime.getRuntime().availableProcessors().coerceIn(1, 12)
        for (i in 0 until n) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(2), 0, dp(2), 0)
                layoutParams = lay(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(3)
                }
            }
            val label = TextView(this).apply {
                text = "C$i  --"
                setTextColor(Color.WHITE)
                textSize = 10f
                layoutParams = lay(dp(92), ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
                progressTintList = ColorStateList.valueOf(RED)
                layoutParams = lay(0, dp(8), 1f)
            }
            row.addView(label)
            row.addView(bar)
            col.addView(row)
            coreRows.add(label to bar)
        }

        col.addView(sectionLabel("MEMORI & JARINGAN"))
        col.addView(infoText { ramDetailText = it })
        col.addView(infoText { netText = it })
        return scrollPage(col)
    }

    private fun updateDetail() {
        val snap = sampler.snapshot
        val hist = sampler.history()
        sparkView?.setValues(hist)
        fpsStatsText?.text = if (hist.isEmpty()) {
            "Belum ada data FPS (butuh Shizuku/root dan game yang sedang berjalan)"
        } else {
            val avg = hist.average().roundToInt()
            val mn = hist.minOrNull() ?: 0
            val mx = hist.maxOrNull() ?: 0
            val sorted = hist.sorted()
            val low = sorted.take(maxOf(1, sorted.size / 100)).average().roundToInt()
            "Kini ${hist.last()}  ·  Rata-rata $avg  ·  Min $mn  ·  Maks $mx  ·  1% low $low"
        }
        for ((i, row) in coreRows.withIndex()) {
            val mhz = snap.cores.getOrNull(i) ?: 0
            val mx = snap.coresMax.getOrNull(i) ?: 0
            row.first.text = if (snap.cores.isEmpty()) "C$i  N/A" else "C$i  ${mhz}MHz"
            row.second.progress = if (mx > 0) (mhz * 100 / mx).coerceIn(0, 100) else 0
        }

        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val totalMb = mi.totalMem / (1024 * 1024)
        val availMb = mi.availMem / (1024 * 1024)
        val usedMb = totalMb - availMb
        val pct = if (totalMb > 0) usedMb * 100 / totalMb else 0
        ramDetailText?.text = "RAM terpakai $usedMb / $totalMb MB ($pct%)  ·  bebas $availMb MB"

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = runCatching { cm.getNetworkCapabilities(cm.activeNetwork) }.getOrNull()
        val type = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Seluler"
            else -> "Lainnya"
        }
        netText?.text = "Jaringan: $type  ·  ping " + if (pingMs >= 0) "$pingMs ms" else "--"
    }

    private fun buildToolsPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(sectionLabel("ALAT CEPAT"))

        val r1 = hRow()
        r1.addView(tile("🧹", "Hapus cache") { cleanCache() }.first)
        val dnd = tile("🔕", "DND") { toggleDnd() }
        dndButton = dnd.second
        r1.addView(dnd.first)
        r1.addView(tile("📸", "Screenshot") { takeScreenshot() }.first)
        col.addView(r1)

        val r2 = hRow()
        r2.addView(dynTile("⏺️", "Rekam layar", { recLabel = it }) { toggleRecord() })
        r2.addView(dynTile("🛡️", "Kunci tepi", { edgeLabel = it }) { toggleEdgeLock() })
        r2.addView(dynTile("🔒", "Kunci layar", { lockLabel = it }) { toggleFullLock() })
        col.addView(r2)

        val r3 = hRow()
        r3.addView(dynTile("🎯", "Mode fokus", { focusLabel = it }) { toggleFocus() })
        r3.addView(dynTile("📶", "Jaringan", { netLabel = it }) { toggleNet() })
        r3.addView(tile("📡", "WLAN on/off") { toggleWifi() }.first)
        col.addView(r3)

        val r4 = hRow()
        val awake = tile("☀️", "Layar nyala: mati") { setKeepAwake(!keepAwake) }
        awakeLabel = awake.second
        r4.addView(awake.first)
        val rotate = tile("🔄", "Rotasi") { toggleRotation() }
        rotateLabel = rotate.second
        r4.addView(rotate.first)
        r4.addView(tile("👆", "Tampilkan sentuhan") { toggleShowTouches() }.first)
        col.addView(r4)

        val r5 = hRow()
        r5.addView(tile("🔆", "Cerah otomatis") { toggleAutoBrightness() }.first)
        r5.addView(tile("🎮", "Kembali ke game") { if (panelOpen) togglePanel() }.first)
        r5.addView(tile("❌", "Tutup bubble") {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, false).apply()
            stopSelf()
        }.first)
        col.addView(r5)

        col.addView(sectionLabel("KECERAHAN & SUARA"))
        col.addView(slider("Kecerahan", 255, currentBrightness()) { setBrightness(it) })
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        col.addView(
            slider("Volume media", am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                am.getStreamVolume(AudioManager.STREAM_MUSIC)) { v ->
                runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0) }
            }
        )
        return scrollPage(col)
    }

    private fun buildAppsPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(sectionLabel("SIDEBAR APLIKASI (MAKS 20)"))
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val packages = (prefs.getString(KEY_QUICK_APPS, "") ?: "")
            .split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(20)
        if (packages.isEmpty()) {
            col.addView(TextView(this).apply {
                text = "Belum ada. Tambahkan dan atur urutannya di NexusPro → Tools → Game Mode → Aplikasi cepat."
                setTextColor(TEXT_DIM)
                textSize = 11f
                setPadding(dp(2), dp(4), dp(2), 0)
            })
        } else {
            for (chunk in packages.chunked(4)) {
                val row = hRow()
                for (pkg in chunk) {
                    val icon = try {
                        packageManager.getApplicationIcon(pkg)
                    } catch (e: Exception) {
                        null
                    } ?: continue
                    row.addView(ImageView(this).apply {
                        setImageDrawable(icon)
                        contentDescription = pkg
                        layoutParams = lay(0, dp(46), 1f).apply {
                            marginStart = dp(2)
                            marginEnd = dp(2)
                        }
                        setOnClickListener { launchPackage(pkg) }
                    })
                }
                col.addView(row)
            }
        }
        col.addView(TextView(this).apply {
            text = "Tip: nyalakan \"Jendela kecil\" di tab Setelan agar aplikasi dibuka mengambang (jika HP mendukung)."
            setTextColor(TEXT_DIM)
            textSize = 10f
            setPadding(dp(2), dp(8), dp(2), 0)
        })
        return scrollPage(col)
    }

    private fun buildSettingsPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(sectionLabel("SESUAIKAN OVERLAY"))

        val r1 = hRow()
        r1.addView(dynTile("➕", "Bidik", { crossLabel = it }) { cycleCrosshair() })
        r1.addView(dynTile("📈", "HUD FPS", { hudLabel = it }) { toggleHud() })
        r1.addView(dynTile("🧲", "Tempel tepi", { snapLabel = it }) { toggleSnap() })
        col.addView(r1)

        val r2 = hRow()
        r2.addView(dynTile("😴", "Istirahat", { wellbeingLabel = it }) { cycleWellbeing() })
        r2.addView(dynTile("🔲", "Jendela kecil", { floatLabel = it }) { toggleFloat() })
        r2.addView(tile("🏠", "Buka NexusPro") { launchPackage(packageName) }.first)
        col.addView(r2)

        val sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        col.addView(
            slider("Ukuran bubble", 44, sp.getInt(KEY_BUBBLE_DP, 52).coerceIn(36, 80) - 36,
                onDone = { v ->
                    sp.edit().putInt(KEY_BUBBLE_DP, 36 + v).apply()
                    handler.post { rebuildOverlay() }
                }) { }
        )
        col.addView(
            slider("Transparansi bubble", 70, sp.getInt(KEY_ALPHA, 100).coerceIn(30, 100) - 30,
                onDone = { v ->
                    sp.edit().putInt(KEY_ALPHA, 30 + v).apply()
                    handler.post { rebuildOverlay() }
                }) { }
        )
        col.addView(TextView(this).apply {
            text = "NexusPro oleh AskaaBeelGaad\nGratis, dilarang diperjualbelikan."
            setTextColor(TEXT_DIM)
            textSize = 10f
            setPadding(dp(4), dp(10), dp(4), 0)
        })
        return scrollPage(col)
    }

    // ---- new features (all of them run from the panel)

    private fun sp() = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= 26) {
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_PHONE
    }

    private fun updateToolLabels() {
        val p = sp()
        recLabel?.text = if (ScreenRecordService.recording) "Berhenti rekam" else "Rekam layar"
        edgeLabel?.text = "Kunci tepi: " + if (p.getBoolean(KEY_EDGE, false)) "ON" else "off"
        lockLabel?.text = if (fullShield != null) "Buka kunci" else "Kunci layar"
        focusLabel?.text = "Fokus: " + if (focusOn) "ON" else "off"
        netLabel?.text = "Jaringan: " + if (p.getBoolean(KEY_NET, false)) "ON" else "off"
        val styles = listOf("mati", "titik", "silang", "lingkaran", "plus")
        crossLabel?.text = "Bidik: " + styles[p.getInt(KEY_CROSS, 0).coerceIn(0, 4)]
        hudLabel?.text = "HUD FPS: " + if (p.getBoolean(KEY_HUD, true)) "ON" else "off"
        snapLabel?.text = "Tempel tepi: " + if (p.getBoolean(KEY_SNAP, true)) "ON" else "off"
        val w = p.getInt(KEY_WELLBEING, 0)
        wellbeingLabel?.text = if (w == 0) "Istirahat: mati" else "Istirahat: $w mnt"
        floatLabel?.text = "Jendela kecil: " + if (p.getBoolean(KEY_FLOAT, false)) "ON" else "off"
    }

    private fun minimizePanel() {
        if (panelOpen) togglePanel()
        snapToEdge()
    }

    private fun snapToEdge() {
        val lp = overlayParams ?: return
        val wm = windowManager ?: return
        val rv = rootView ?: return
        val sw = resources.displayMetrics.widthPixels
        val w = if (rv.width > 0) rv.width else bubbleSize()
        lp.x = if (lp.x + w / 2 < sw / 2) 0 else (sw - w).coerceAtLeast(0)
        runCatching { wm.updateViewLayout(rv, lp) }
        sp().edit().putInt(KEY_POS_X, lp.x).putInt(KEY_POS_Y, lp.y).apply()
    }

    /** Puts the bubble window back on top of the touch-blocking edge strips. */
    private fun reattachBubble() {
        val rv = rootView ?: return
        val lp = overlayParams ?: return
        val wm = windowManager ?: return
        runCatching { wm.removeViewImmediate(rv) }
        runCatching { wm.addView(rv, lp) }
    }

    private fun toggleRecord() {
        if (ScreenRecordService.recording) {
            ScreenRecordService.stop(this)
            return
        }
        if (panelOpen) togglePanel()
        runCatching {
            startActivity(
                Intent(this, ScreenCaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }.onFailure { toast("Tidak bisa membuka perekam layar") }
    }

    private fun setEdge(on: Boolean) {
        sp().edit().putBoolean(KEY_EDGE, on).apply()
        applyEdgeLock()
        updateToolLabels()
    }

    private fun toggleEdgeLock() {
        val on = !sp().getBoolean(KEY_EDGE, false)
        setEdge(on)
        toast(if (on) "Tepi layar kiri dan kanan dikunci" else "Tepi layar dibuka")
    }

    private fun applyEdgeLock() {
        val wm = windowManager ?: return
        for (v in edgeViews) runCatching { wm.removeView(v) }
        edgeViews.clear()
        if (!sp().getBoolean(KEY_EDGE, false)) return
        for (g in intArrayOf(Gravity.START, Gravity.END)) {
            val v = View(this).apply {
                setBackgroundColor(Color.parseColor("#22E4002B"))
                setOnTouchListener { _, _ -> true }
            }
            val p = WindowManager.LayoutParams(
                dp(24),
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = g or Gravity.TOP
            if (runCatching { wm.addView(v, p) }.isSuccess) edgeViews.add(v)
        }
        handler.post { reattachBubble() }
    }

    private fun toggleFullLock() {
        if (fullShield != null) {
            unlockFull()
            return
        }
        val wm = windowManager ?: return
        if (panelOpen) togglePanel()
        val shield = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#22000000"))
            setOnTouchListener { _, _ -> true }
        }
        val pill = TextView(this).apply {
            text = "🔒 Layar terkunci. Tahan 2 detik di sini untuk membuka"
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            background = roundedBg(Color.parseColor("#CC101014"), 18)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            val unlock = Runnable { unlockFull() }
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        handler.postDelayed(unlock, 2000L)
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        handler.removeCallbacks(unlock)
                        true
                    }
                    else -> true
                }
            }
        }
        shield.addView(
            pill,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = dp(48) }
        )
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        if (runCatching { wm.addView(shield, p) }.isSuccess) {
            fullShield = shield
            toast("Layar terkunci")
        }
        updateToolLabels()
    }

    private fun unlockFull() {
        val v = fullShield ?: return
        runCatching { windowManager?.removeView(v) }
        fullShield = null
        toast("Layar dibuka")
        updateToolLabels()
    }

    private fun toggleFocus() {
        focusOn = !focusOn
        if (focusOn) {
            setDnd(true)
            setEdge(true)
            setKeepAwake(true)
            toast("Mode fokus aktif: DND, tepi terkunci, layar tetap menyala")
        } else {
            setDnd(false)
            setEdge(false)
            setKeepAwake(false)
            toast("Mode fokus dimatikan")
        }
        updateToolLabels()
    }

    private fun toggleNet() = setNetBoost(!sp().getBoolean(KEY_NET, false), silent = false)

    private fun setNetBoost(on: Boolean, silent: Boolean) {
        sp().edit().putBoolean(KEY_NET, on).apply()
        runCatching {
            if (on) {
                if (wifiLock == null) {
                    val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    val mode = if (Build.VERSION.SDK_INT >= 29) {
                        WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                    } else {
                        @Suppress("DEPRECATION")
                        WifiManager.WIFI_MODE_FULL_HIGH_PERF
                    }
                    wifiLock = wm.createWifiLock(mode, "NexusPro:net").apply { setReferenceCounted(false) }
                }
                wifiLock?.acquire()
            } else {
                wifiLock?.let { if (it.isHeld) it.release() }
            }
        }
        // With Shizuku/root the system's own low-latency Wi-Fi mode is switched too.
        Thread { PrivShell.exec("cmd wifi force-low-latency-mode " + if (on) "enabled" else "disabled") }.start()
        if (!silent) toast(if (on) "Jaringan game diprioritaskan (Wi-Fi low latency)" else "Prioritas jaringan dimatikan")
        updateToolLabels()
    }

    private fun toggleWifi() {
        Thread {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val on = runCatching { wm.isWifiEnabled }.getOrDefault(true)
            val r = PrivShell.exec("svc wifi " + if (on) "disable" else "enable")
            if (r.ok) {
                toast(if (on) "Wi-Fi dimatikan" else "Wi-Fi dinyalakan")
            } else {
                // Android 10+ does not let apps switch Wi-Fi; open the system panel instead.
                handler.post {
                    val intent = Intent(
                        if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
                        else Settings.ACTION_WIFI_SETTINGS
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { startActivity(intent) }
                }
            }
        }.start()
    }

    private fun cycleCrosshair() {
        val next = (sp().getInt(KEY_CROSS, 0) + 1) % 5
        sp().edit().putInt(KEY_CROSS, next).apply()
        applyCrosshair()
        updateToolLabels()
    }

    private fun applyCrosshair() {
        val wm = windowManager ?: return
        crosshairView?.let { runCatching { wm.removeView(it) } }
        crosshairView = null
        val kind = sp().getInt(KEY_CROSS, 0)
        if (kind <= 0) return
        val v = CrosshairView(this).apply { this.kind = kind }
        val size = dp(96)
        val p = WindowManager.LayoutParams(
            size,
            size,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.CENTER
        if (runCatching { wm.addView(v, p) }.isSuccess) crosshairView = v
    }

    private fun toggleHud() {
        sp().edit().putBoolean(KEY_HUD, !sp().getBoolean(KEY_HUD, true)).apply()
        updateToolLabels()
    }

    private fun toggleSnap() {
        sp().edit().putBoolean(KEY_SNAP, !sp().getBoolean(KEY_SNAP, true)).apply()
        updateToolLabels()
    }

    private fun toggleFloat() {
        sp().edit().putBoolean(KEY_FLOAT, !sp().getBoolean(KEY_FLOAT, false)).apply()
        updateToolLabels()
    }

    private fun cycleWellbeing() {
        val cur = sp().getInt(KEY_WELLBEING, 0)
        val idx = WELLBEING_STEPS.indexOf(cur).let { if (it < 0) 0 else it }
        val next = WELLBEING_STEPS[(idx + 1) % WELLBEING_STEPS.size]
        sp().edit().putInt(KEY_WELLBEING, next).apply()
        wellbeingNotified = 0
        updateToolLabels()
        toast(if (next == 0) "Pengingat istirahat dimatikan" else "Diingatkan istirahat tiap $next menit main")
    }

    private fun checkWellbeing() {
        val min = sp().getInt(KEY_WELLBEING, 0)
        if (min <= 0 || playingPkg == null) return
        val elapsed = SystemClock.elapsedRealtime() - playStart
        val due = (elapsed / (min * 60_000L)).toInt()
        if (due > wellbeingNotified) {
            wellbeingNotified = due
            remindBreak(min * due)
        }
    }

    @Suppress("DEPRECATION")
    private fun remindBreak(minutes: Int) {
        toast("Sudah $minutes menit main. Istirahat sebentar ya!")
        runCatching {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), -1))
        }
        runCatching {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("nexuspro_wellbeing", "Pengingat istirahat", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val b = if (Build.VERSION.SDK_INT >= 26) {
                Notification.Builder(this, "nexuspro_wellbeing")
            } else {
                Notification.Builder(this)
            }
            nm.notify(
                4722,
                b.setContentTitle("Waktunya istirahat")
                    .setContentText("Kamu sudah main $minutes menit. Minum dan rilekskan mata sebentar.")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setAutoCancel(true)
                    .build()
            )
        }
    }

    private fun removeAuxWindows() {
        val wm = windowManager
        crosshairView?.let { runCatching { wm?.removeView(it) } }
        crosshairView = null
        for (v in edgeViews) runCatching { wm?.removeView(v) }
        edgeViews.clear()
        fullShield?.let { runCatching { wm?.removeView(it) } }
        fullShield = null
    }

    // ---- system helpers used by the tools page

    private fun currentBrightness(): Int = try {
        Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
    } catch (t: Throwable) {
        128
    }

    private fun needWriteSettings(): Boolean {
        if (Settings.System.canWrite(this)) return false
        toast("Beri izin 'Ubah pengaturan sistem' untuk NexusPro (Tools > Pusat Izin)")
        runCatching {
            startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, android.net.Uri.parse("package:$packageName"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        return true
    }

    private fun setBrightness(value: Int) {
        if (needWriteSettings()) return
        runCatching {
            Settings.System.putInt(
                contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, value.coerceIn(1, 255))
        }
    }

    private fun setKeepAwake(on: Boolean) {
        val lp = overlayParams ?: return
        val wm = windowManager ?: return
        val rv = rootView ?: return
        keepAwake = on
        lp.flags = if (keepAwake) {
            lp.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        } else {
            lp.flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.inv()
        }
        runCatching { wm.updateViewLayout(rv, lp) }
        awakeLabel?.text = if (keepAwake) "Layar nyala: aktif" else "Layar nyala: mati"
    }

    private fun toggleShowTouches() {
        if (needWriteSettings()) return
        runCatching {
            val now = Settings.System.getInt(contentResolver, "show_touches", 0)
            Settings.System.putInt(contentResolver, "show_touches", if (now == 1) 0 else 1)
            toast(if (now == 1) "Sentuhan disembunyikan" else "Sentuhan ditampilkan")
        }.onFailure { toast("Gagal mengubah. Coba beri izin lanjutan di Pusat Izin") }
    }

    private fun toggleAutoBrightness() {
        if (needWriteSettings()) return
        runCatching {
            val now = Settings.System.getInt(
                contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            val auto = now == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            Settings.System.putInt(
                contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                if (auto) Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                else Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            )
            toast(if (auto) "Kecerahan manual" else "Kecerahan otomatis")
        }
    }

    private fun toggleRotation() {
        if (needWriteSettings()) return
        runCatching {
            val now = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (now == 1) 0 else 1)
            toast(if (now == 1) "Rotasi dikunci" else "Rotasi otomatis")
            updateRotateLabel()
        }
    }

    private fun updateRotateLabel() {
        val on = try {
            Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 1
        } catch (t: Throwable) {
            true
        }
        rotateLabel?.text = if (on) "Rotasi: otomatis" else "Rotasi: terkunci"
    }

    private fun attachDrag(
        handle: View,
        lp: WindowManager.LayoutParams,
        wm: WindowManager,
        root: View,
    ) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        val slop = dp(8)
        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true
                    if (moved) {
                        val dm = resources.displayMetrics
                        lp.x = (startX + dx).coerceIn(0, (dm.widthPixels - dp(24)).coerceAtLeast(0))
                        lp.y = (startY + dy).coerceIn(0, (dm.heightPixels - dp(48)).coerceAtLeast(0))
                        runCatching { wm.updateViewLayout(root, lp) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                            .putInt(KEY_POS_X, lp.x)
                            .putInt(KEY_POS_Y, lp.y)
                            .apply()
                        if (getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SNAP, true)) {
                            snapToEdge()
                        }
                    } else {
                        togglePanel()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun togglePanel() {
        val p = panel ?: return
        val rv = rootView ?: return
        val lp = overlayParams ?: return
        val wm = windowManager ?: return
        panelOpen = !panelOpen
        p.visibility = if (panelOpen) View.VISIBLE else View.GONE
        if (panelOpen) {
            // Keep the expanded panel on screen.
            val maxX = resources.displayMetrics.widthPixels - panelWidth() - dp(8)
            val maxY = resources.displayMetrics.heightPixels - bubbleSize() - dp(6) - panelHeight() - dp(8)
            lp.x = lp.x.coerceAtMost(maxX).coerceAtLeast(0)
            lp.y = lp.y.coerceAtMost(maxY).coerceAtLeast(0)
            runCatching { wm.updateViewLayout(rv, lp) }
            refreshStatus()
        } else {
            runCatching { wm.updateViewLayout(rv, lp) }
        }
    }

    private fun removeOverlay() {
        val v = rootView
        if (v != null) {
            runCatching { windowManager?.removeView(v) }
        }
        rootView = null
        panel = null
        statRam = null
        statBattery = null
        statTemp = null
        statPing = null
        statClock = null
        statApp = null
        dndButton = null
        awakeLabel = null
        rotateLabel = null
        statFps = null
        statCpu = null
        statGpu = null
        statDisplay = null
        statPlay = null
        statCurrent = null
        statStorage = null
        hudView = null
        privHint = null
        modeButtons.clear()
        tabPages.clear()
        tabButtons.clear()
        sparkView = null
        fpsStatsText = null
        netText = null
        ramDetailText = null
        coreRows.clear()
        recLabel = null
        edgeLabel = null
        lockLabel = null
        focusLabel = null
        netLabel = null
        crossLabel = null
        hudLabel = null
        snapLabel = null
        wellbeingLabel = null
        floatLabel = null
    }

    // ---------------------------------------------------------------- auto show

    /**
     * Auto mode: the bubble is visible while a game is in the foreground. If the foreground
     * app cannot be determined it stays visible (never hide by mistake). With auto mode off
     * the bubble is always visible.
     */
    private fun updateVisibility() {
        val rv = rootView ?: return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        var show = true
        val fg = currentForeground()
        if (fg != null && fg != packageName) {
            if (isGamePackage(this, fg)) {
                if (playingPkg != fg) {
                    playingPkg = fg
                    playStart = SystemClock.elapsedRealtime()
                    wellbeingNotified = 0
                }
            } else {
                playingPkg = null
            }
        }
        if (prefs.getBoolean(KEY_AUTO, true) && fg != null) {
            show = fg == packageName || isGamePackage(this, fg)
        }
        val target = if (show) View.VISIBLE else View.GONE
        if (rv.visibility != target) {
            rv.visibility = target
            if (!show && panelOpen) togglePanel()
        }
    }

    /** Best available answer to "which app is open now": accessibility first, usage stats second. */
    private fun currentForeground(): String? {
        if (NexusAccessibilityService.isEnabled(this)) {
            val a11y = NexusAccessibilityService.foreground
            if (a11y != null) {
                currentFg = a11y
                currentSource = "aksesibilitas"
                return a11y
            }
        }
        if (hasUsageAccess(this)) {
            val fg = foregroundPackage()
            if (fg != null) {
                currentFg = fg
                currentSource = "akses penggunaan"
                return fg
            }
        }
        return null
    }

    private fun markCurrentAsGame() {
        val fg = currentForeground() ?: currentFg
        if (fg == null || fg == packageName) {
            toast("Buka dulu game-nya, lalu tarik notifikasi dan ketuk \"Ini game\"")
            return
        }
        markGame(this, fg, true)
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(fg, 0)).toString()
        } catch (t: Throwable) {
            fg
        }
        toast("$label ditandai sebagai game")
        updateVisibility()
    }

    @Suppress("DEPRECATION")
    private fun foregroundPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return lastForeground
        val now = System.currentTimeMillis()
        val from = if (lastEventTime == 0L) now - 24L * 60L * 60L * 1000L else lastEventTime
        val events = try {
            usm.queryEvents(from, now)
        } catch (t: Throwable) {
            null
        } ?: return lastForeground
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND &&
                e.packageName != "com.android.systemui" &&
                e.packageName != "android"
            ) {
                lastForeground = e.packageName
            }
            if (e.timeStamp > lastEventTime) lastEventTime = e.timeStamp
        }
        if (lastForeground == null) {
            // Quiet phone: use the most recently used app instead.
            lastForeground = try {
                usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 3600_000L, now)
                    ?.maxByOrNull { it.lastTimeUsed }?.packageName
            } catch (t: Throwable) {
                null
            }
        }
        return lastForeground
    }

    private fun takeScreenshot() {
        if (!NexusAccessibilityService.isEnabled(this)) {
            toast("Aktifkan Aksesibilitas NexusPro di Tools > Pusat Izin untuk screenshot")
            return
        }
        if (panelOpen) togglePanel()
        handler.postDelayed({
            if (!NexusAccessibilityService.screenshot()) toast("Screenshot tidak didukung di HP ini")
        }, 350L)
    }

    private fun pingOnce() {
        if (pinging) return
        pinging = true
        Thread {
            pingMs = try {
                val t0 = SystemClock.elapsedRealtime()
                java.net.Socket().use { sock ->
                    sock.connect(java.net.InetSocketAddress("1.1.1.1", 443), 1500)
                }
                (SystemClock.elapsedRealtime() - t0).toInt()
            } catch (t: Throwable) {
                -1
            }
            pinging = false
        }.start()
    }

    // ---------------------------------------------------------------- status

    private fun availRam(): Long {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
    }

    private fun refreshStatus() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val totalMb = info.totalMem / (1024 * 1024)
        val usedMb = (info.totalMem - info.availMem) / (1024 * 1024)
        val pct = if (totalMb > 0) (usedMb * 100 / totalMb) else 0
        statRam?.text = "$pct%"

        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (battery != null) {
            val level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val tempTenths = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            val status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            statBattery?.text = if (level >= 0 && scale > 0) {
                "${level * 100 / scale}%" + if (charging) "\u26A1" else ""
            } else {
                "--"
            }
            statTemp?.text = if (tempTenths != Int.MIN_VALUE) "${tempTenths / 10.0}\u00B0" else "--"
        }

        // The status switches in the app decide which cards are visible.
        (statRam?.parent as? View)?.visibility =
            if (prefs.getBoolean(KEY_SHOW_RAM, true)) View.VISIBLE else View.GONE
        (statBattery?.parent as? View)?.visibility =
            if (prefs.getBoolean(KEY_SHOW_BATTERY, true)) View.VISIBLE else View.GONE
        (statTemp?.parent as? View)?.visibility =
            if (prefs.getBoolean(KEY_SHOW_TEMP, true)) View.VISIBLE else View.GONE

        val snap = sampler.snapshot
        statFps?.text = if (snap.fps >= 0) "${snap.fps}" else "N/A"
        statFps?.setTextColor(if (snap.fps >= 0) fpsColor(snap.fps) else Color.WHITE)
        statCpu?.text = when {
            snap.cpuPct >= 0 -> "${snap.cpuPct}%"
            snap.cpuMhz > 0 -> String.format(Locale.US, "%.1fGHz", snap.cpuMhz / 1000f)
            else -> "N/A"
        }
        statCpu?.setTextColor(if (snap.cpuPct >= 0) loadColor(snap.cpuPct) else Color.WHITE)
        statGpu?.text = if (snap.gpuPct >= 0) "${snap.gpuPct}%" else "N/A"
        statGpu?.setTextColor(if (snap.gpuPct >= 0) loadColor(snap.gpuPct) else Color.WHITE)
        if (snap.tempC > 0) statTemp?.text = "${snap.tempC.roundToInt()}\u00B0"
        privHint?.visibility = if (snap.privileged) View.GONE else View.VISIBLE

        @Suppress("DEPRECATION")
        val hz = (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.refreshRate
        statDisplay?.text = "${hz.roundToInt()}Hz"
        statPlay?.text = playTime()

        val bm = getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val microAmp = bm?.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0L
        statCurrent?.text = if (microAmp != 0L) "${Math.abs(microAmp) / 1000L}mA" else "--"
        val freeGb = availStorage() / (1024.0 * 1024.0 * 1024.0)
        statStorage?.text = String.format(Locale.US, "%.0fGB", freeGb)

        pingOnce()
        statPing?.text = if (pingMs >= 0) "$pingMs ms" else "offline"
        statClock?.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

        val fg = currentFg
        statApp?.text = if (fg != null) {
            val name = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(fg, 0)).toString()
            } catch (t: Throwable) {
                fg
            }
            "Aplikasi aktif: $name"
        } else {
            ""
        }
        updateDndLabel()
        updateRotateLabel()
        updateDetail()
        updateToolLabels()
    }

    // ---------------------------------------------------------------- actions

    private fun toast(message: String) {
        handler.post { Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show() }
    }

    private fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    private fun shizukuExec(command: String): Boolean = try {
        @Suppress("DEPRECATION")
        val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
        val drain = Thread { runCatching { process.errorStream.readBytes() } }
        drain.start()
        runCatching { process.inputStream.readBytes() }
        val code = process.waitFor()
        drain.join(2000)
        code == 0
    } catch (t: Throwable) {
        false
    }

    private fun boostRam() {
        toast("Membersihkan RAM...")
        Thread {
            val before = availRam()
            var done = false
            if (shizukuReady()) {
                done = shizukuExec("am kill-all")
            }
            if (!done) {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                for (app in packageManager.getInstalledApplications(0)) {
                    if (app.flags and ApplicationInfo.FLAG_SYSTEM == 0 && app.packageName != packageName) {
                        runCatching { am.killBackgroundProcesses(app.packageName) }
                    }
                }
            }
            Thread.sleep(1200)
            val freedMb = (availRam() - before).coerceAtLeast(0) / (1024 * 1024)
            toast("Boost RAM selesai: $freedMb MB lega")
        }.start()
    }

    private fun availStorage(): Long =
        StatFs(Environment.getDataDirectory().path).let { it.availableBlocksLong * it.blockSizeLong }

    private fun cleanCache() {
        toast("Membersihkan cache...")
        Thread {
            val before = availStorage()
            runCatching { cacheDir?.deleteRecursively() }
            runCatching { externalCacheDir?.deleteRecursively() }
            if (shizukuReady()) {
                shizukuExec("pm trim-caches 999G")
                Thread.sleep(800)
                val freedMb = (availStorage() - before).coerceAtLeast(0) / (1024 * 1024)
                toast("Cache semua aplikasi dibersihkan: $freedMb MB")
            } else {
                toast("Cache NexusPro dibersihkan. Aktifkan Shizuku untuk bersihkan cache semua aplikasi.")
            }
        }.start()
    }

    private fun updateDndLabel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val label = if (!nm.isNotificationPolicyAccessGranted) {
            "DND: beri izin"
        } else if (nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL ||
            nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        ) {
            "DND: mati"
        } else {
            "DND: aktif"
        }
        dndButton?.text = label
    }

    private fun toggleDnd() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Beri izin 'Jangan ganggu' untuk NexusPro, lalu kembali ke game")
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { startActivity(intent) }
            return
        }
        val current = nm.currentInterruptionFilter
        if (current == NotificationManager.INTERRUPTION_FILTER_ALL ||
            current == NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        ) {
            previousDndFilter = NotificationManager.INTERRUPTION_FILTER_ALL
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            toast("Jangan ganggu aktif")
        } else {
            nm.setInterruptionFilter(previousDndFilter)
            toast("Jangan ganggu dimatikan")
        }
        updateDndLabel()
    }

    private fun launchPackage(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            toast("Aplikasi tidak bisa dibuka")
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val floating = sp().getBoolean(KEY_FLOAT, false) && pkg != packageName
        if (floating && Build.VERSION.SDK_INT >= 24) {
            // Asks for a small window. HP that support freeform windows honour it,
            // others simply open the app normally.
            val dm = resources.displayMetrics
            val w = (dm.widthPixels * 0.6f).toInt()
            val h = (dm.heightPixels * 0.7f).toInt()
            val left = (dm.widthPixels - w) / 2
            val top = (dm.heightPixels - h) / 2
            val opts = ActivityOptions.makeBasic().setLaunchBounds(Rect(left, top, left + w, top + h))
            runCatching { startActivity(intent, opts.toBundle()) }
                .onFailure { runCatching { startActivity(intent) } }
        } else {
            runCatching { startActivity(intent) }
        }
    }
}
