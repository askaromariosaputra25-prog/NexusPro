package com.nexuspro.optimization

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Tells NexusPro instantly which app is in the foreground, and lets the overlay
 * start by itself the moment a game opens. It reads no screen content
 * (canRetrieveWindowContent = false) and sends nothing anywhere.
 */
class NexusAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NexusAccessibilityService? = null
            private set

        @Volatile
        var foreground: String? = null
            private set

        /** System surfaces that appear on top of a game but are not the game. */
        private val IGNORED = setOf(
            "com.android.systemui",
            "android",
            "com.oplus.games",
            "com.coloros.gamespaceui",
            "com.oppo.gamespaceui",
            "com.heytap.speechassist",
            "com.google.android.googlequicksearchbox",
        )

        fun isEnabled(context: Context): Boolean {
            if (instance != null) return true
            return try {
                val enabled = Settings.Secure.getString(
                    context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ) ?: return false
                val me = ComponentName(context, NexusAccessibilityService::class.java)
                enabled.split(':').any {
                    val c = ComponentName.unflattenFromString(it)
                    c != null && c == me
                }
            } catch (t: Throwable) {
                false
            }
        }

        fun screenshot(): Boolean {
            val svc = instance ?: return false
            return if (Build.VERSION.SDK_INT >= 28) {
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            } else {
                false
            }
        }
    }

    private var keyboards: Set<String> = emptySet()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        refreshKeyboards()
    }

    private fun refreshKeyboards() {
        keyboards = try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.enabledInputMethodList.map { it.packageName }.toSet()
        } catch (t: Throwable) {
            emptySet()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg.isEmpty() || pkg in IGNORED || pkg in keyboards) return
        // Our own overlay windows are not an "app switch".
        if (pkg == packageName) {
            val cls = event.className?.toString() ?: ""
            if (!cls.contains("Activity")) return
        }
        if (pkg == foreground) return
        foreground = pkg
        OverlayService.onForegroundChanged(this, pkg)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) instance = null
        foreground = null
        super.onDestroy()
    }
}
