package com.nexuspro.optimization

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** Aim-assist crosshair drawn in the middle of the screen. [kind]: 1 dot, 2 cross, 3 circle, 4 plus + dot. */
internal class CrosshairView(context: Context) : View(context) {

    var kind: Int = 1
        set(value) {
            field = value
            invalidate()
        }

    private val density = resources.displayMetrics.density
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF00E676")
        style = Paint.Style.STROKE
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF00E676")
        style = Paint.Style.FILL
    }
    private val dotOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val u = density
        outline.strokeWidth = 4f * u
        fill.strokeWidth = 2f * u
        when (kind) {
            1 -> {
                canvas.drawCircle(cx, cy, 4f * u, dotOutline)
                canvas.drawCircle(cx, cy, 2.5f * u, dot)
            }
            2 -> {
                drawCross(canvas, cx, cy, 6f * u, 16f * u)
            }
            3 -> {
                canvas.drawCircle(cx, cy, 14f * u, outline)
                canvas.drawCircle(cx, cy, 14f * u, fill)
                canvas.drawCircle(cx, cy, 2f * u, dot)
            }
            else -> {
                drawCross(canvas, cx, cy, 4f * u, 14f * u)
                canvas.drawCircle(cx, cy, 2.5f * u, dotOutline)
                canvas.drawCircle(cx, cy, 1.8f * u, dot)
            }
        }
    }

    private fun drawCross(c: Canvas, cx: Float, cy: Float, gap: Float, len: Float) {
        for (p in listOf(outline, fill)) {
            c.drawLine(cx - len, cy, cx - gap, cy, p)
            c.drawLine(cx + gap, cy, cx + len, cy, p)
            c.drawLine(cx, cy - len, cx, cy - gap, p)
            c.drawLine(cx, cy + gap, cx, cy + len, p)
        }
    }
}
