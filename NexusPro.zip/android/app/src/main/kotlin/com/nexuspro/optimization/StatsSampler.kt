package com.nexuspro.optimization

import android.content.Context
import android.os.SystemClock
import java.io.File

/**
 * Reads real FPS, CPU load, GPU load and temperature for the Game Genie panel.
 *
 * FPS/CPU/GPU come from system files and `dumpsys SurfaceFlinger`, which only the shell
 * user can read, so they need Shizuku or root. Without that, CPU frequency is read
 * directly when the phone allows it and the rest shows "N/A" (never a made-up number).
 */
internal class StatsSampler(@Suppress("unused") private val context: Context) {

    data class Snapshot(
        val fps: Int = -1,
        val cpuPct: Int = -1,
        val gpuPct: Int = -1,
        val tempC: Float = -1f,
        val cpuMhz: Int = -1,
        val privileged: Boolean = false,
        val cores: List<Int> = emptyList(),
        val coresMax: List<Int> = emptyList(),
    )

    @Volatile
    var snapshot: Snapshot = Snapshot()
        private set

    @Volatile
    private var busy = false

    private var prevTotal = 0L
    private var prevIdle = 0L
    private var layerPkg: String? = null
    private var layerName: String? = null
    private var layerAt = 0L
    private var privCache = false
    private var privCheckedAt = 0L

    private val fpsHistory = ArrayList<Int>()

    /** Last ~3 minutes of FPS readings (one per sample), oldest first. */
    fun history(): List<Int> = synchronized(fpsHistory) { ArrayList(fpsHistory) }

    private fun pushFps(v: Int) = synchronized(fpsHistory) {
        fpsHistory.add(v)
        while (fpsHistory.size > 90) fpsHistory.removeAt(0)
    }

    private var maxCache: List<Int> = emptyList()

    private fun directCores(): Pair<List<Int>, List<Int>> {
        val cur = ArrayList<Int>()
        val max = ArrayList<Int>()
        val n = Runtime.getRuntime().availableProcessors().coerceIn(1, 12)
        for (i in 0 until n) {
            cur.add(((readLong("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq") ?: 0L) / 1000L).toInt())
            max.add(((readLong("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq") ?: 0L) / 1000L).toInt())
        }
        return if (cur.any { it > 0 }) cur to max else emptyList<Int>() to emptyList()
    }

    private val pkgRegex = Regex("^[a-zA-Z0-9_.]+$")

    fun request(gamePkg: String?) {
        if (busy) return
        busy = true
        Thread {
            try {
                sample(gamePkg)
            } catch (t: Throwable) {
                // keep the last snapshot
            } finally {
                busy = false
            }
        }.start()
    }

    private fun hasPriv(): Boolean {
        if (PrivShell.shizukuReady()) return true
        val now = SystemClock.elapsedRealtime()
        if (now - privCheckedAt < 60_000L) return privCache
        privCheckedAt = now
        val r = PrivShell.exec("id")
        privCache = r.output.contains("uid=0")
        return privCache
    }

    private fun readLong(path: String): Long? = try {
        File(path).readText().trim().toLongOrNull()
    } catch (t: Throwable) {
        null
    }

    private fun directCpuMhz(): Int {
        var best = -1L
        for (i in 0..11) {
            val khz = readLong("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq") ?: continue
            if (khz > best) best = khz
        }
        return if (best > 0) (best / 1000L).toInt() else -1
    }

    private fun findLayer(pkg: String): String? {
        val now = SystemClock.elapsedRealtime()
        if (layerPkg == pkg && layerName != null && now - layerAt < 30_000L) return layerName
        val r = PrivShell.exec("dumpsys SurfaceFlinger --list 2>/dev/null | grep '$pkg'")
        val lines = r.output.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.contains("'") }
        val pick = lines.firstOrNull { it.contains("SurfaceView") && !it.contains("Background") }
            ?: lines.firstOrNull { !it.contains("Background") }
            ?: lines.firstOrNull()
        layerPkg = pkg
        layerName = pick
        layerAt = now
        return pick
    }

    private fun sample(gamePkg: String?) {
        val priv = hasPriv()
        val mhz = directCpuMhz()
        if (!priv) {
            val (c, m) = directCores()
            snapshot = Snapshot(cpuMhz = mhz, privileged = false, cores = c, coresMax = m)
            return
        }

        val cmd = StringBuilder(
            "head -n1 /proc/stat; " +
                "echo '##GPU'; cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null; " +
                "echo '##GED'; cat /sys/kernel/ged/hal/gpu_utilization 2>/dev/null; " +
                "echo '##TYPES'; cat /sys/class/thermal/thermal_zone*/type 2>/dev/null; " +
                "echo '##TEMPS'; cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null; "
        )
        val n = Runtime.getRuntime().availableProcessors().coerceIn(1, 12)
        cmd.append("echo '##CORES'; ")
        for (i in 0 until n) {
            cmd.append("cat /sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq 2>/dev/null || echo 0; ")
        }
        if (maxCache.size != n) {
            cmd.append("echo '##MAXS'; ")
            for (i in 0 until n) {
                cmd.append("cat /sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 0; ")
            }
        }
        if (gamePkg != null && pkgRegex.matches(gamePkg)) {
            val layer = findLayer(gamePkg)
            if (layer != null) {
                cmd.append("echo '##FPS'; dumpsys SurfaceFlinger --latency '").append(layer).append("' 2>/dev/null")
            }
        }
        val out = PrivShell.exec(cmd.toString()).output

        var section = "STAT"
        val stat = ArrayList<String>()
        val gpu = ArrayList<String>()
        val ged = ArrayList<String>()
        val types = ArrayList<String>()
        val temps = ArrayList<String>()
        val fpsLines = ArrayList<String>()
        val coreLines = ArrayList<String>()
        val maxLines = ArrayList<String>()
        for (raw in out.lines()) {
            val line = raw.trim()
            if (line.startsWith("##")) {
                section = line.removePrefix("##")
                continue
            }
            if (line.isEmpty()) continue
            when (section) {
                "STAT" -> stat.add(line)
                "GPU" -> gpu.add(line)
                "GED" -> ged.add(line)
                "TYPES" -> types.add(line)
                "TEMPS" -> temps.add(line)
                "FPS" -> fpsLines.add(line)
                "CORES" -> coreLines.add(line)
                "MAXS" -> maxLines.add(line)
            }
        }

        // CPU load from two readings of /proc/stat.
        var cpuPct = -1
        stat.firstOrNull { it.startsWith("cpu") }?.let { line ->
            val n = line.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (n.size >= 5) {
                val idle = n[3] + n[4]
                val total = n.take(8).sum()
                if (prevTotal > 0 && total > prevTotal) {
                    val dTotal = total - prevTotal
                    val dIdle = idle - prevIdle
                    cpuPct = ((dTotal - dIdle) * 100 / dTotal).toInt().coerceIn(0, 100)
                }
                prevTotal = total
                prevIdle = idle
            }
        }

        // GPU load: Qualcomm (kgsl) "busy total", MediaTek (ged) first number.
        var gpuPct = -1
        gpu.firstOrNull()?.let { l ->
            val n = l.split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }
            if (n.size >= 2 && n[1] > 0) gpuPct = (n[0] * 100 / n[1]).toInt().coerceIn(0, 100)
        }
        if (gpuPct < 0) {
            ged.firstOrNull()?.let { l ->
                l.split(Regex("[^0-9]+")).firstOrNull { it.isNotEmpty() }?.toIntOrNull()?.let {
                    gpuPct = it.coerceIn(0, 100)
                }
            }
        }

        // Temperature: prefer a CPU/SoC zone, otherwise the hottest sane zone.
        var tempC = -1f
        val zones = ArrayList<Pair<String, Float>>()
        for (i in temps.indices) {
            val raw = temps[i].toLongOrNull() ?: continue
            val c = when {
                raw > 1000L -> raw / 1000f
                raw > 150L -> raw / 10f
                else -> raw.toFloat()
            }
            if (c in 15f..120f) zones.add((types.getOrNull(i) ?: "") to c)
        }
        val cpuZone = zones.firstOrNull { (t, _) ->
            val l = t.lowercase()
            l.contains("cpu") || l.contains("soc") || l.contains("apc") || l.contains("mtk")
        }
        tempC = cpuZone?.second ?: zones.maxByOrNull { it.second }?.second ?: -1f

        // FPS: frames presented during the last second.
        var fps = -1
        if (fpsLines.size > 2) {
            val stamps = ArrayList<Long>()
            for (i in 1 until fpsLines.size) {
                val t = fpsLines[i].split(Regex("\\s+"))
                if (t.size >= 3) {
                    val v = t[1].toLongOrNull() ?: continue
                    if (v > 0L && v < Long.MAX_VALUE / 2) stamps.add(v)
                }
            }
            val newest = stamps.maxOrNull()
            if (newest != null) {
                fps = if (System.nanoTime() - newest > 2_000_000_000L) {
                    0
                } else {
                    stamps.count { it > newest - 1_000_000_000L }.coerceAtMost(240)
                }
            }
        }

        var cores = coreLines.map { ((it.toLongOrNull() ?: 0L) / 1000L).toInt() }
        if (maxLines.isNotEmpty()) maxCache = maxLines.map { ((it.toLongOrNull() ?: 0L) / 1000L).toInt() }
        if (cores.none { it > 0 }) cores = directCores().first
        if (fps >= 0) pushFps(fps)
        snapshot = Snapshot(fps, cpuPct, gpuPct, tempC, mhz, true, cores, maxCache)
    }
}
