package com.nexuspro.optimization

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Small line graph (used for the FPS history). */
internal class SparkView(context: Context) : View(context) {

    private var values: List<Int> = emptyList()
    private val density = resources.displayMetrics.density

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFE4002B")
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        strokeJoin = Paint.Join.ROUND
    }
    private val area = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33E4002B")
        style = Paint.Style.FILL
    }
    private val grid = Paint().apply {
        color = Color.parseColor("#22FFFFFF")
        strokeWidth = 1f
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF9A9AA8")
        textSize = 9f * density
    }

    fun setValues(data: List<Int>) {
        values = data
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val top = maxOf(60, (values.maxOrNull() ?: 0) + 5)
        canvas.drawLine(0f, h * 0.5f, w, h * 0.5f, grid)
        canvas.drawText("$top", 2f * density, 10f * density, label)
        canvas.drawText("${top / 2}", 2f * density, h * 0.5f - 2f * density, label)
        if (values.size < 2) return
        val path = Path()
        val fillPath = Path()
        val step = w / (values.size - 1).coerceAtLeast(1)
        for ((i, v) in values.withIndex()) {
            val x = i * step
            val y = h - (v.coerceIn(0, top) / top.toFloat()) * h
            if (i == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, h)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(w, h)
        fillPath.close()
        canvas.drawPath(fillPath, area)
        canvas.drawPath(path, line)
    }
}
