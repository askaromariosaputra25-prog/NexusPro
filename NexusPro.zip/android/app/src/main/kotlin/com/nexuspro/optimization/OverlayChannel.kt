package com.nexuspro.optimization

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel

/**
 * Flutter <-> native bridge for the Game Mode overlay.
 *
 * Channel: com.nexuspro.optimization/overlay
 *   hasPermission()          -> Boolean  ("Display over other apps" granted)
 *   requestPermission()      -> Boolean  (opens the system settings page)
 *   isRunning()              -> Boolean
 *   start()                  -> Boolean  (false when the permission is missing)
 *   stop()                   -> Boolean
 *   setQuickApps(packages)   -> Boolean
 *   getQuickApps()           -> List<String>
 *   setOptions(ram, battery, temp) -> Boolean
 *   getOptions()             -> Map<String, Boolean>
 *   hasDndAccess()           -> Boolean
 *   openDndSettings()        -> Boolean
 */
internal class OverlayChannel(
    private val activity: Activity,
    messenger: BinaryMessenger,
) {
    companion object {
        const val CHANNEL = "com.nexuspro.optimization/overlay"
        private val PACKAGE_REGEX = Regex("^[a-zA-Z0-9_.]+$")
        private const val MAX_QUICK_APPS = 8
    }

    private val channel = MethodChannel(messenger, CHANNEL)

    private fun prefs() = activity.getSharedPreferences(OverlayService.PREFS, Context.MODE_PRIVATE)

    fun register() {
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "hasPermission" -> result.success(OverlayService.canDraw(activity))
                "requestPermission" -> {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + activity.packageName)
                    )
                    result.success(runCatching { activity.startActivity(intent) }.isSuccess)
                }
                "isRunning" -> result.success(OverlayService.running)
                "start" -> {
                    if (!OverlayService.canDraw(activity)) {
                        result.success(false)
                    } else {
                        result.success(runCatching { OverlayService.start(activity) }.isSuccess)
                    }
                }
                "stop" -> {
                    OverlayService.stop(activity)
                    result.success(true)
                }
                "setQuickApps" -> {
                    val list = call.argument<List<String>>("packages") ?: emptyList()
                    val clean = list
                        .map { it.trim() }
                        .filter { PACKAGE_REGEX.matches(it) }
                        .distinct()
                        .take(MAX_QUICK_APPS)
                    prefs().edit().putString(OverlayService.KEY_QUICK_APPS, clean.joinToString(",")).apply()
                    result.success(true)
                }
                "getQuickApps" -> {
                    val csv = prefs().getString(OverlayService.KEY_QUICK_APPS, "") ?: ""
                    result.success(csv.split(",").map { it.trim() }.filter { it.isNotEmpty() })
                }
                "setOptions" -> {
                    prefs().edit()
                        .putBoolean(OverlayService.KEY_SHOW_RAM, call.argument<Boolean>("ram") ?: true)
                        .putBoolean(OverlayService.KEY_SHOW_BATTERY, call.argument<Boolean>("battery") ?: true)
                        .putBoolean(OverlayService.KEY_SHOW_TEMP, call.argument<Boolean>("temp") ?: true)
                        .putBoolean(OverlayService.KEY_AUTO, call.argument<Boolean>("auto") ?: true)
                        .putBoolean(OverlayService.KEY_BOOT, call.argument<Boolean>("boot") ?: false)
                        .apply()
                    result.success(true)
                }
                "setGamePackages" -> {
                    val list = call.argument<List<String>>("packages") ?: emptyList()
                    val clean = list.map { it.trim() }.filter { PACKAGE_REGEX.matches(it) }.distinct()
                    prefs().edit().putString(OverlayService.KEY_GAMES, clean.joinToString(",")).apply()
                    result.success(true)
                }
                "hasUsageAccess" -> result.success(OverlayService.hasUsageAccess(activity))
                "openUsageAccess" -> {
                    val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                    result.success(runCatching { activity.startActivity(intent) }.isSuccess)
                }
                "getOptions" -> {
                    val p = prefs()
                    result.success(
                        mapOf(
                            "ram" to p.getBoolean(OverlayService.KEY_SHOW_RAM, true),
                            "battery" to p.getBoolean(OverlayService.KEY_SHOW_BATTERY, true),
                            "temp" to p.getBoolean(OverlayService.KEY_SHOW_TEMP, true),
                            "auto" to p.getBoolean(OverlayService.KEY_AUTO, true),
                            "boot" to p.getBoolean(OverlayService.KEY_BOOT, false),
                        )
                    )
                }
                "hasDndAccess" -> {
                    val nm = activity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    result.success(nm.isNotificationPolicyAccessGranted)
                }
                "openDndSettings" -> {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    result.success(runCatching { activity.startActivity(intent) }.isSuccess)
                }
                "hasAccessibility" -> result.success(NexusAccessibilityService.isEnabled(activity))
                "openAccessibility" -> {
                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    result.success(runCatching { activity.startActivity(intent) }.isSuccess)
                }
                "getForeground" -> {
                    val fg = OverlayService.currentFg
                    result.success(
                        mapOf(
                            "running" to OverlayService.running,
                            "package" to (fg ?: ""),
                            "isGame" to (fg != null && OverlayService.isGamePackage(activity, fg)),
                            "source" to OverlayService.currentSource,
                            "label" to (fg?.let {
                                try {
                                    activity.packageManager.getApplicationLabel(
                                        activity.packageManager.getApplicationInfo(it, 0)
                                    ).toString()
                                } catch (t: Throwable) {
                                    it
                                }
                            } ?: ""),
                        )
                    )
                }
                "markGame" -> {
                    val pkg = call.argument<String>("package") ?: ""
                    val game = call.argument<Boolean>("game") ?: true
                    if (PACKAGE_REGEX.matches(pkg)) {
                        OverlayService.markGame(activity, pkg, game)
                        result.success(true)
                    } else {
                        result.success(false)
                    }
                }
                "getManualGames" -> {
                    val csv = prefs().getString(OverlayService.KEY_MANUAL, "") ?: ""
                    result.success(csv.split(",").map { it.trim() }.filter { it.isNotEmpty() })
                }
                else -> result.notImplemented()
            }
        }
    }
}
