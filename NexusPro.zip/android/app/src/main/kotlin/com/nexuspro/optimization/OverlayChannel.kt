package com.nexuspro.optimization

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel

/**
 * Flutter <-> native bridge for the Game Mode overlay.
 *
 * Channel: com.nexuspro.optimization/overlay
 *   hasPermission()          -> Boolean  ("Display over other apps" granted)
 *   requestPermission()      -> Boolean  (opens the system settings page)
 *   isRunning()              -> Boolean
 *   start()                  -> Boolean  (false when the permission is missing)
 *   stop()                   -> Boolean
 *   setQuickApps(packages)   -> Boolean
 *   getQuickApps()           -> List<String>
 *   setOptions(ram, battery, temp) -> Boolean
 *   getOptions()             -> Map<String, Boolean>
 *   hasDndAccess()           -> Boolean
 *   openDndSettings()        -> Boolean
 */
internal class OverlayChannel(
    private val activity: Activity,
    messenger: BinaryMessenger,
) {
    companion object {
        const val CHANNEL = "com.nexuspro.optimization/overlay"
        private val PACKAGE_REGEX = Regex("^[a-zA-Z0-9_.]+$")
        private const val MAX_QUICK_APPS = 8
    }

    private val channel = MethodChannel(messenger, CHANNEL)

    private fun prefs() = activity.getSharedPreferences(OverlayService.PREFS, Context.MODE_PRIVATE)

    fun register() {
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "hasPermission" -> result.success(OverlayService.canDraw(activity))
                "requestPermission" -> {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + activity.packageName)
                    )
                    result.success(runCatching { activity.startActivity(intent) }.isSuccess)
                }
                "isRunning" -> result.success(OverlayService.running)
                "start" -> {
                    if (!OverlayService.canDraw(activity)) {
                        result.success(false)
                    } else {
                        result.success(runCatching { OverlayService.start(activity) }.isSuccess)
                    }
                }
                "stop" -> {
                    OverlayService.stop(activity)
                    result.success(true)
                }
                "setQuickApps" -> {
                    val list = call.argument<List<String>>("packages") ?: emptyList()
                    val clean = list
                        .map { it.trim() }
                        .filter { PACKAGE_REGEX.matches(it) }
                        .distinct()
                        .take(MAX_QUICK_APPS)
                    prefs().edit().putString(OverlayService.KEY_QUICK_APPS, clean.joinToString(",")).apply()
                    result.success(true)
                }
                "getQuickApps" -> {
                    val csv = prefs().getString(OverlayService.KEY_QUICK_APPS, "") ?: ""
                    result.success(csv.split(",").map { it.trim() }.filter { it.isNotEmpty() })
                }
                "setOptions" -> {
                    prefs().edit()
                        .putBoolean(OverlayService.KEY_SHOW_RAM, call.argument<Boolean>("ram") ?: true)
                        .putBoolean(OverlayService.KEY_SHOW_BATTERY, call.argument<Boolean>("battery") ?: true)
                        .putBoolean(OverlayService.KEY_SHOW_TEMP, call.argument<Boolean>("temp") ?: true)
                        .apply()
                    result.success(true)
                }
                "getOptions" -> {
                    val p = prefs()
                    result.success(
                        mapOf(
                            "ram" to p.getBoolean(OverlayService.KEY_SHOW_RAM, true),
                            "battery" to p.getBoolean(OverlayService.KEY_SHOW_BATTERY, true),
                            "temp" to p.getBoolean(OverlayService.KEY_SHOW_TEMP, true),
                        )
                    )
                }
                "hasDndAccess" -> {
                    val nm = activity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    result.success(nm.isNotificationPolicyAccessGranted)
                }
                "openDndSettings" -> {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    result.success(runCatching { activity.startActivity(intent) }.isSuccess)
                }
                else -> result.notImplemented()
            }
        }
    }
}
