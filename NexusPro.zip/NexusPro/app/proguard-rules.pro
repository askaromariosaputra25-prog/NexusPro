# ProGuard rules
-keepattributes *Annotation*
