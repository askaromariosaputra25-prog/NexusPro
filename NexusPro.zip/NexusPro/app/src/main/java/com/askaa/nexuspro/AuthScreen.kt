package com.askaa.nexuspro

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.fragment.app.FragmentActivity
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch

/** Menyimpan akun Google yang sudah terhubung (lokal di perangkat). */
object Account {
    private fun p(c: Context) = c.getSharedPreferences("nexus_account", Context.MODE_PRIVATE)
    fun email(c: Context): String? = p(c).getString("email", null)
    fun save(c: Context, email: String) { p(c).edit().putString("email", email).apply() }
    fun clear(c: Context) { p(c).edit().clear().apply() }
}

@Composable
fun LoginScreen(onLoggedIn: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val configured = BuildConfig.WEB_CLIENT_ID.isNotBlank()

    fun signIn() {
        busy = true
        err = null
        scope.launch {
            try {
                val option = GetSignInWithGoogleOption.Builder(BuildConfig.WEB_CLIENT_ID).build()
                val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                val result = CredentialManager.create(ctx).getCredential(ctx, request)
                val cred = result.credential
                if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val g = GoogleIdTokenCredential.createFrom(cred.data)
                    Account.save(ctx, g.id)
                    onLoggedIn(g.id)
                } else {
                    err = "Jenis kredensial tidak dikenali."
                }
            } catch (e: GetCredentialCancellationException) {
                err = "Login dibatalkan."
            } catch (e: GetCredentialException) {
                err = "Gagal login Google: ${e.message ?: e.type}\n\nCek: Web Client ID benar, OAuth client Android sudah memakai SHA-1 dari panduan, dan emailmu terdaftar sebagai Test user."
            } catch (e: Exception) {
                err = "Gagal login: ${e.message}"
            }
            busy = false
        }
    }

    Column(
        Modifier.fillMaxSize().background(cBG).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Bolt, null, tint = cAcc, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(12.dp))
        Text("NexusPro", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = cWhite)
        Text("Hubungkan akun Google untuk melanjutkan", color = cDim, fontSize = 13.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(32.dp))

        Button(
            onClick = { signIn() },
            enabled = configured && !busy,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = cAcc)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = cBG, strokeWidth = 2.dp)
            else Text("Masuk dengan Google", color = Color00201E, fontWeight = FontWeight.Bold)
        }

        if (!configured) {
            Spacer(Modifier.height(16.dp))
            Text(
                "Login Google belum dikonfigurasi (WEB_CLIENT_ID kosong). Ikuti panduan setup, atau pakai mode setup di bawah untuk sementara.",
                color = cYellow, fontSize = 12.sp, textAlign = TextAlign.Center
            )
            TextButton({ onLoggedIn("mode-setup@local") }) { Text("Lanjut mode setup (tanpa Google)", color = cDim) }
        }

        err?.let {
            Spacer(Modifier.height(16.dp))
            Text(it, color = cRed, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
    }
}

private val Color00201E = androidx.compose.ui.graphics.Color(0xFF00201E)

@Composable
fun LockScreen(email: String, onUnlocked: () -> Unit, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("") }
    var canEnroll by remember { mutableStateOf(false) }
    var noHardware by remember { mutableStateOf(false) }

    fun prompt() {
        val act = ctx as? FragmentActivity
        if (act == null) { msg = "Tidak bisa membuka prompt sidik jari."; return }
        canEnroll = false
        val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK
        when (BiometricManager.from(act).canAuthenticate(auth)) {
            BiometricManager.BIOMETRIC_SUCCESS -> {
                val bp = BiometricPrompt(act, ContextCompat.getMainExecutor(act),
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onUnlocked() }
                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { msg = errString.toString() }
                        override fun onAuthenticationFailed() { msg = "Sidik jari tidak cocok, coba lagi." }
                    })
                val info = BiometricPrompt.PromptInfo.Builder()
                    .setTitle("NexusPro")
                    .setSubtitle("Verifikasi sidik jari untuk masuk")
                    .setNegativeButtonText("Batal")
                    .setAllowedAuthenticators(auth)
                    .build()
                bp.authenticate(info)
            }
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                msg = "Belum ada sidik jari terdaftar di HP ini. Daftarkan dulu di Pengaturan."
                canEnroll = true
            }
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE,
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> {
                msg = "HP ini tidak punya sensor sidik jari yang bisa dipakai."
                noHardware = true
            }
            else -> msg = "Biometrik tidak tersedia saat ini."
        }
    }

    LaunchedEffect(Unit) { prompt() }

    Column(
        Modifier.fillMaxSize().background(cBG).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Fingerprint, null, tint = cAcc, modifier = Modifier.size(80.dp))
        Spacer(Modifier.height(12.dp))
        Text("Terkunci", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = cWhite)
        Text(email, color = cDim, fontSize = 13.sp)
        Spacer(Modifier.height(28.dp))

        Button(
            onClick = { prompt() },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = cAcc)
        ) { Text("Buka dengan sidik jari", color = Color00201E, fontWeight = FontWeight.Bold) }

        if (msg.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            Text(msg, color = cYellow, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
        if (canEnroll) {
            TextButton({ ctx.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                Text("Buka pengaturan keamanan", color = cAcc)
            }
        }
        if (noHardware) {
            TextButton({ onUnlocked() }) { Text("Lanjut tanpa sidik jari", color = cDim) }
        }
        Spacer(Modifier.height(8.dp))
        TextButton({ onLogout() }) { Text("Ganti akun Google", color = cDim, fontSize = 12.sp) }
    }
}
