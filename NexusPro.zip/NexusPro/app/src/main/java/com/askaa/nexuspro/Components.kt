package com.askaa.nexuspro

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun NxCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth().padding(vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = cCard),
        shape = RoundedCornerShape(16.dp),
        content = { Column(Modifier.padding(16.dp), content = content) }
    )
}

@Composable
fun SectionLabel(text: String, icon: ImageVector? = null) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
        icon?.let { Icon(it, null, tint = cAcc, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)) }
        Text(text, color = cAcc, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            letterSpacing = 1.sp)
    }
}

@Composable
fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = cDim, fontSize = 13.sp)
        Text(value, color = cWhite, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) cAcc else cPill
    val fg = if (selected) Color(0xFF00201E) else cWhite
    Box(
        Modifier.clip(RoundedCornerShape(10.dp)).background(bg)
            .clickable { onClick() }.padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = fg, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) }
}

@Composable
fun BoostToggle(title: String, desc: String, checked: Boolean, onCheck: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = cWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(desc, color = cDim, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheck,
            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00201E), checkedTrackColor = cAcc))
    }
}

@Composable
fun Dot(color: Color = cGreen) {
    Box(Modifier.size(8.dp).clip(CircleShape).background(color))
}

@Composable
fun ToolCard(title: String, icon: ImageVector, tint: Color = cAcc, onClick: () -> Unit) {
    Card(
        Modifier.aspectRatio(1f).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = cCard2),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            Modifier.fillMaxSize().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(cPill),
                contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text(title, color = cWhite, fontSize = 11.sp, fontWeight = FontWeight.Medium,
                maxLines = 2, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                lineHeight = 14.sp)
        }
    }
}
