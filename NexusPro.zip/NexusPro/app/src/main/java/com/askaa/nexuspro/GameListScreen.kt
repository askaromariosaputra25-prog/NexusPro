package com.askaa.nexuspro

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ToolItem(val title: String, val icon: ImageVector, val tint: androidx.compose.ui.graphics.Color = cAcc)

val TOOLS = listOf(
    ToolItem("Device Spoof", Icons.Default.PhoneAndroid),
    ToolItem("Benchmark",    Icons.Default.Speed),
    ToolItem("Custom Crosshair", Icons.Default.GpsFixed),
    ToolItem("Ping Test",    Icons.Default.NetworkCheck),
    ToolItem("Deep Freeze",  Icons.Default.AcUnit, cRed),
    ToolItem("FPS Monitor",  Icons.Default.Monitor),
    ToolItem("Debloat",      Icons.Default.DeleteSweep, cRed),
    ToolItem("FPS Stabilizer", Icons.Default.Tune),
    ToolItem("Process Manager", Icons.Default.Memory),
)

@Composable
fun GameListScreen(shizukuState: Int, onGameClick: (GameInfo) -> Unit) {
    val ctx = LocalContext.current
    var games by remember { mutableStateOf<List<GameInfo>?>(null) }
    var query by remember { mutableStateOf("") }
    var toolMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { games = withContext(Dispatchers.IO) { loadGames(ctx.packageManager) } }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        // Header
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("GameBoost", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = cWhite)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.VideogameAsset, null, tint = cAcc, modifier = Modifier.size(26.dp))
        }
        Text(
            "${games?.size ?: 0} games detected",
            color = cDim, fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp)
        )

        // Search
        OutlinedTextField(
            query, { query = it },
            Modifier.fillMaxWidth(),
            placeholder = { Text("Search games...", color = cDim) },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, null, tint = cDim) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = cAcc, unfocusedBorderColor = cPill,
                focusedTextColor = cWhite, unfocusedTextColor = cWhite,
                cursorColor = cAcc
            ),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
        )

        Spacer(Modifier.height(12.dp))

        // Tools grid 3x3
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.height(300.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(TOOLS) { t ->
                ToolCard(t.title, t.icon, t.tint) { toolMsg = "${t.title}: Fitur ini memerlukan Shizuku aktif." }
            }
        }

        toolMsg?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = cDim, fontSize = 11.sp)
        }

        Spacer(Modifier.height(12.dp))
        HorizontalDivider(color = cPill)
        Spacer(Modifier.height(8.dp))

        // Game list
        val g = games
        if (g == null) {
            Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = cAcc)
            }
        } else {
            val filtered = g.filter { it.name.contains(query, true) || it.pkg.contains(query, true) }
            if (filtered.isEmpty()) {
                Text("Belum ada game terdeteksi", color = cDim, modifier = Modifier.padding(16.dp))
            } else {
                Column {
                    filtered.forEach { game ->
                        Card(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            onClick = { onGameClick(game) },
                            colors = CardDefaults.cardColors(containerColor = cCard),
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                        ) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(44.dp)
                                        .let { m -> m.then(Modifier) }
                                        .run {
                                            androidx.compose.foundation.layout.Box(
                                                this
                                            ) {}
                                            this
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.VideogameAsset, null, tint = cAcc, modifier = Modifier.size(30.dp))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(game.name, color = cWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(game.pkg, color = cDim, fontSize = 11.sp)
                                }
                                Icon(Icons.Default.ChevronRight, null, tint = cDim)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(80.dp))
    }
}
