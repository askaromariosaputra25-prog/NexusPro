package com.askaa.nexuspro

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AdvancedScreen(shizukuState: Int) {
    val scope = rememberCoroutineScope()
    var log by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var zstd by remember { mutableStateOf("LZ4") }
    var tcp  by remember { mutableStateOf("cubic") }
    var fsync by remember { mutableStateOf(false) }

    fun run(title: String, cmds: List<String>) {
        if (shizukuState != 2) { log = "Shizuku tidak aktif."; return }
        busy = true
        scope.launch {
            val sb = StringBuilder("── $title ──\n")
            for (c in cmds) {
                val o = withContext(Dispatchers.IO) { Sh.run(c) }
                sb.append("• ").append(c.take(60)).append("\n")
                if (o.isNotBlank()) sb.append("  ").append(o.take(100)).append("\n")
                log = sb.toString()
            }
            log = sb.append("✓ Done.\n").toString()
            busy = false
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp).padding(bottom = 80.dp)
    ) {
        Text("Advanced", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = cWhite,
            modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
        Text("Kernel & system tweaks", color = cDim, fontSize = 13.sp, modifier = Modifier.padding(bottom = 12.dp))

        // ── Zram / Compression ─────────────────────────────────────────────
        NxCard {
            SectionLabel("Zram Compression")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("LZ4","ZSTD","LZO","LZO-RLE","off").forEach { v ->
                    Pill(v, zstd == v) { zstd = v }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ zstd = "LZ4" }, Modifier.weight(1f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, cDim),
                    colors = OutlinedButtonDefaults.outlinedButtonColors(contentColor = cDim)) { Text("Reset") }
                Button({ run("Zram", listOf("echo $zstd > /sys/block/zram0/comp_algorithm")) },
                    Modifier.weight(1f), enabled = !busy,
                    colors = ButtonDefaults.buttonColors(containerColor = cAcc)) { Text("Apply", color = Color(0xFF00201E)) }
            }
        }

        // ── CPU Governor ───────────────────────────────────────────────────
        NxCard {
            var gov by remember { mutableStateOf("schedutil") }
            SectionLabel("CPU Governor")
            Text("CPU Governor", color = cWhite, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("conservative","powersave","performance","schedutil").forEach { v ->
                    Pill(v, gov == v) { gov = v }
                }
            }
            Spacer(Modifier.height(8.dp))
            Button({
                run("CPU Gov", listOf(
                    "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo $gov > \$f; done"
                ))
            }, Modifier.fillMaxWidth(), enabled = !busy,
                colors = ButtonDefaults.buttonColors(containerColor = cAcc)) { Text("Apply", color = Color(0xFF00201E)) }
        }

        // ── Network ────────────────────────────────────────────────────────
        NxCard {
            SectionLabel("Network")
            Text("TCP Congestion Control", color = cWhite, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Text("Network management algorithm. Current: $tcp", color = cDim, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("reno","bic","cubic").forEach { v ->
                    Pill(v, tcp == v) { tcp = v }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ tcp = "cubic" }, Modifier.weight(1f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, cDim),
                    colors = OutlinedButtonDefaults.outlinedButtonColors(contentColor = cDim)) { Text("Reset") }
                Button({
                    run("TCP", listOf("sysctl -w net.ipv4.tcp_congestion_control=$tcp"))
                }, Modifier.weight(1f), enabled = !busy,
                    colors = ButtonDefaults.buttonColors(containerColor = cAcc)) { Text("Apply", color = Color(0xFF00201E)) }
            }
        }

        // ── Miscellaneous ──────────────────────────────────────────────────
        NxCard {
            SectionLabel("Miscellaneous")
            Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Fsync", color = cWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("Sync files to disk after writing. Disable for better performance, risk of data loss on crash.", color = cDim, fontSize = 11.sp, lineHeight = 14.sp)
                }
                Switch(fsync, { fsync = it; run("Fsync", listOf("echo ${if(!fsync) 0 else 1} > /sys/module/sync/parameters/fsync_enabled")) },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00201E), checkedTrackColor = cAcc))
            }
        }

        // ── Log ────────────────────────────────────────────────────────────
        if (busy || log.isNotEmpty()) {
            NxCard {
                if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth(), color = cAcc, trackColor = cPill); Spacer(Modifier.height(6.dp)) }
                Text(log, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = cDim)
            }
        }
    }
}
