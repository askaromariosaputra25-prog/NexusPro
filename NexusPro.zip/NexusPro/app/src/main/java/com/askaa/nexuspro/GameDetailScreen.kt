package com.askaa.nexuspro

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun GameDetailScreen(game: GameInfo, shizukuState: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    // Boost toggles
    var optRam    by remember { mutableStateOf(true) }
    var optPrio   by remember { mutableStateOf(true) }
    var optAnim   by remember { mutableStateOf(true) }
    var optTouch  by remember { mutableStateOf(true) }
    var optMode   by remember { mutableStateOf(true) }
    var optMem    by remember { mutableStateOf(true) }

    // Graphic & FPS
    var execNew   by remember { mutableStateOf(true) }
    var resPct    by remember { mutableStateOf(100) }
    var fpsTgt    by remember { mutableStateOf(0) }
    var lockFps   by remember { mutableStateOf(false) }

    // Expandable sections
    var expandGraphics  by remember { mutableStateOf(false) }
    var expandAdvanced  by remember { mutableStateOf(false) }
    var expandDownscale by remember { mutableStateOf(true) }

    // Log
    var log       by remember { mutableStateOf("") }
    var busy      by remember { mutableStateOf(false) }

    val pkg = game.pkg

    fun exec(title: String, cmds: List<String>) {
        if (shizukuState != 2) { log = "Shizuku tidak aktif atau belum diberi izin."; return }
        busy = true
        scope.launch {
            val sb = StringBuilder("── $title ──\n")
            for (c in cmds) {
                val o = withContext(Dispatchers.IO) { Sh.run(c) }
                sb.append("• ").append(c.take(60)).append("\n")
                if (o.isNotBlank()) sb.append("  ").append(o.take(120)).append("\n")
                log = sb.toString()
            }
            log = sb.append("✓ Selesai.\n").toString()
            busy = false
        }
    }

    fun buildBoostCmds(): List<String> {
        val l = mutableListOf<String>()
        if (optRam)   l += "am kill-all"
        if (optPrio)  { l += "am set-standby-bucket $pkg active"; l += "cmd deviceidle whitelist +$pkg" }
        if (optAnim)  l += "settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5"
        if (optTouch) l += "settings put secure long_press_timeout 250"
        if (optMode)  l += "cmd game mode performance $pkg"
        if (optMem)   l += "for x in \$(pm list packages -3|cut -d: -f2); do [ \"\$x\" != \"$pkg\" ] && am send-trim-memory --user 0 \$x COMPLETE; done; sync"
        return l
    }

    fun buildGraphicCmds(): List<String> {
        val l = mutableListOf<String>()
        val res = if (resPct >= 100) "wm size reset"
            else "s=\$(wm size|grep -oE '[0-9]+x[0-9]+'|head -1);w=\$(echo \$s|cut -dx -f1);h=\$(echo \$s|cut -dx -f2);wm size \$((w*$resPct/100))x\$((h*$resPct/100))"
        l += res
        if (fpsTgt > 0) {
            l += "settings put system peak_refresh_rate $fpsTgt"
            l += "settings put system min_refresh_rate $fpsTgt"
            l += "settings put system user_refresh_rate $fpsTgt"
            if (lockFps) l += "settings put system refresh_rate_mode 1"
        } else {
            l += "settings delete system peak_refresh_rate; settings delete system min_refresh_rate; settings delete system user_refresh_rate"
        }
        return l
    }

    val resetCmds = listOf(
        "settings put global window_animation_scale 1.0",
        "settings put global transition_animation_scale 1.0",
        "settings put global animator_duration_scale 1.0",
        "settings put secure long_press_timeout 400",
        "wm size reset",
        "settings delete system peak_refresh_rate",
        "settings delete system min_refresh_rate",
        "settings delete system user_refresh_rate",
        "cmd game mode standard $pkg"
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp).padding(bottom = 80.dp)
    ) {
        // ── Back + Title ───────────────────────────────────────────────────
        Row(Modifier.padding(top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = cWhite) }
            Text(game.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = cWhite, modifier = Modifier.weight(1f))
        }

        // ── Game banner card ───────────────────────────────────────────────
        Card(
            Modifier.fillMaxWidth().padding(bottom = 10.dp),
            colors = CardDefaults.cardColors(containerColor = cCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(56.dp).clip(RoundedCornerShape(12.dp))
                        .background(cPill), contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.VideogameAsset, null, tint = cAcc, modifier = Modifier.size(32.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(game.name, color = cWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(game.pkg, color = cDim, fontSize = 11.sp)
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(cAcc.copy(0.15f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)) {
                        Text("Game", color = cAcc, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // ── Action buttons ─────────────────────────────────────────────────
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { exec("Boost", buildBoostCmds()) },
                modifier = Modifier.weight(1f), enabled = !busy,
                colors = ButtonDefaults.buttonColors(containerColor = cAcc)
            ) { Icon(Icons.Default.FlashOn, null, tint = Color(0xFF00201E)); Spacer(Modifier.width(4.dp)); Text("Boost!", color = Color(0xFF00201E)) }
            Button(
                onClick = {
                    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
                        ?: run { log = "Tidak bisa membuka $pkg" }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = cCard2)
            ) { Icon(Icons.Default.PlayArrow, null, tint = cWhite); Spacer(Modifier.width(4.dp)); Text("Play!") }
        }

        // ── Boost Options ──────────────────────────────────────────────────
        NxCard {
            SectionLabel("Boost Options")
            BoostToggle("Clear Background RAM",  "Stop all background apps to free RAM", optRam)  { optRam = it }
            BoostToggle("Prioritize Game",       "Give CPU and memory priority to this game", optPrio)  { optPrio = it }
            BoostToggle("Reduce Animations",     "Speed up UI transitions during gaming", optAnim)  { optAnim = it }
            BoostToggle("Touch Boost",           "Improve touch screen responsiveness", optTouch) { optTouch = it }
            BoostToggle("Android Game Mode",     "Enable Android's built-in game mode", optMode)  { optMode = it }
            BoostToggle("Memory Optimization",   "Drop page cache to free up RAM instantly", optMem)   { optMem = it }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { exec("Apply Boost Options", buildBoostCmds()) },
                Modifier.fillMaxWidth(), enabled = !busy,
                colors = ButtonDefaults.buttonColors(containerColor = cAcc)
            ) { Icon(Icons.Default.FlashOn, null, tint = Color(0xFF00201E)); Spacer(Modifier.width(4.dp)); Text("Apply Boost Options", color = Color(0xFF00201E)) }
        }

        // ── Graphics & Frame Performance ───────────────────────────────────
        ExpandSection("Graphics & Frame Performance", expandGraphics, { expandGraphics = !expandGraphics }) {
            Text("Tap to see all options", color = cDim, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
        }

        // ── Advanced Graphics ──────────────────────────────────────────────
        ExpandSection("Advanced Graphics", expandAdvanced, { expandAdvanced = !expandAdvanced }) {
            Text("Tap to see all options", color = cDim, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
        }

        // ── Downscale & FPS ────────────────────────────────────────────────
        NxCard {
            SectionLabel("Downscale & FPS")

            // Execution Method
            Text("Execution Method", color = cWhite, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { execNew = true }, enabled = !execNew,
                    colors = ButtonDefaults.buttonColors(containerColor = if (execNew) cAcc else cPill),
                    modifier = Modifier.weight(1f)
                ) { Icon(Icons.Default.NewReleases, null, tint = if(execNew) Color(0xFF00201E) else cDim, modifier=Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp)); Text("New (Android 15+)", color = if (execNew) Color(0xFF00201E) else cDim, fontSize = 12.sp) }
                Button(
                    onClick = { execNew = false }, enabled = execNew,
                    colors = ButtonDefaults.buttonColors(containerColor = if (!execNew) cAcc else cPill),
                    modifier = Modifier.weight(1f)
                ) { Text("Legacy", color = if (!execNew) Color(0xFF00201E) else cDim) }
            }

            Spacer(Modifier.height(12.dp))

            // Resolution Scale
            Text("Resolution Scale", color = cWhite, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(30 to "0.3x", 40 to "0.4x", 50 to "0.5x", 60 to "0.6x", 70 to "0.7x",
                       75 to "0.75x", 80 to "0.8x", 90 to "0.9x", 100 to "1.0x", 110 to "Off")
                    .forEach { (v, lbl) ->
                        Pill(lbl, resPct == v) { resPct = v }
                    }
            }

            Spacer(Modifier.height(12.dp))

            // FPS Target
            Text("FPS Target", color = cWhite, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0 to "Off", 30 to "30", 60 to "60", 90 to "90", 120 to "120", 144 to "144")
                    .forEach { (v, lbl) -> Pill(lbl, fpsTgt == v) { fpsTgt = v } }
            }

            Spacer(Modifier.height(10.dp))

            // Lock FPS
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Lock FPS", color = cWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("Lock screen refresh rate to target FPS", color = cDim, fontSize = 11.sp)
                }
                Switch(lockFps, { lockFps = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00201E), checkedTrackColor = cAcc))
            }

            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { exec("Reset Grafik", listOf("wm size reset","settings delete system peak_refresh_rate","settings delete system min_refresh_rate","settings delete system user_refresh_rate")); resPct = 100; fpsTgt = 0; lockFps = false },
                    Modifier.weight(1f), enabled = !busy,
                    colors = OutlinedButtonDefaults.outlinedButtonColors(contentColor = cAcc),
                    border = BorderStroke(1.dp, cAcc)
                ) { Text("Reset") }
                Button(
                    onClick = { exec("Apply Grafik & FPS", buildGraphicCmds()) },
                    Modifier.weight(1f), enabled = !busy,
                    colors = ButtonDefaults.buttonColors(containerColor = cAcc)
                ) { Text("Apply", color = Color(0xFF00201E)) }
            }
        }

        // ── Automation Tools label ─────────────────────────────────────────
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, null, tint = cAcc, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(5.dp))
            Text("AUTOMATION TOOLS", color = cAcc, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { exec("Reset Semua", resetCmds) }, Modifier.weight(1f), enabled = !busy,
                colors = OutlinedButtonDefaults.outlinedButtonColors(contentColor = cRed),
                border = BorderStroke(1.dp, cRed)
            ) { Text("Reset Semua") }
            Button(
                onClick = { exec("Force Stop", listOf("am force-stop $pkg")) }, Modifier.weight(1f), enabled = !busy,
                colors = ButtonDefaults.buttonColors(containerColor = cRed)
            ) { Text("Force Stop") }
        }

        // ── Log ────────────────────────────────────────────────────────────
        if (busy || log.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            NxCard {
                if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth(), color = cAcc, trackColor = cPill); Spacer(Modifier.height(6.dp)) }
                Text(log, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = cDim)
            }
        }
    }
}

@Composable
fun ExpandSection(title: String, expanded: Boolean, onToggle: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    NxCard {
        Row(
            Modifier.fillMaxWidth().clickable { onToggle() },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Tune, null, tint = cDim, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(title, color = cWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Icon(
                if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                null, tint = cDim
            )
        }
        if (expanded) { Spacer(Modifier.height(8.dp)); content() }
    }
}
