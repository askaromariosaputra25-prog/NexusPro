package com.askaa.nexuspro

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object Sh {
    fun state(): Int = try {
        if (!Shizuku.pingBinder()) 0
        else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) 2 else 1
    } catch (e: Throwable) { 0 }

    fun request() { try { Shizuku.requestPermission(100) } catch (_: Throwable) {} }

    private val newProc by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
    }

    fun run(cmd: String): String = try {
        val p = newProc.invoke(null, arrayOf("sh","-c","($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor(); out
    } catch (e: Throwable) { "ERR: ${e.cause?.message ?: e.message}" }
}
