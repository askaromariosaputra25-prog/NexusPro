package com.askaa.nexuspro

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

object Sh {
    private const val REQ = 100

    /** 0 = Shizuku tidak aktif, 1 = aktif tapi belum diizinkan, 2 = siap dipakai */
    fun state(): Int = try {
        if (!Shizuku.pingBinder()) 0
        else if (Shizuku.isPreV11()) 0
        else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) 2 else 1
    } catch (e: Throwable) { 0 }

    fun request() { try { Shizuku.requestPermission(REQ) } catch (_: Throwable) {} }

    /** true kalau user pernah memilih "Tolak & jangan tanya lagi" */
    fun deniedForever(): Boolean = try { Shizuku.shouldShowRequestPermissionRationale() } catch (_: Throwable) { false }

    fun uid(): Int = try { Shizuku.getUid() } catch (_: Throwable) { -1 }
    fun isRoot(): Boolean = uid() == 0
    fun version(): Int = try { Shizuku.getVersion() } catch (_: Throwable) { -1 }
    fun mode(): String = when (uid()) {
        0 -> "root"
        2000 -> "ADB (shell)"
        else -> "tidak diketahui"
    }

    private val newProc by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
    }

    /** Jalankan satu perintah shell lewat Shizuku. Error selalu dikembalikan sebagai teks supaya tampil di layar. */
    fun run(cmd: String): String = try {
        val p = newProc.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText().trim()
        val code = p.waitFor()
        p.destroy()
        if (code != 0) "$out\n[exit $code]".trim() else out
    } catch (e: Throwable) {
        "ERR: ${e.cause?.message ?: e.message ?: e.javaClass.simpleName}"
    }

    /** Jalankan beberapa perintah berurutan, kirim log yang terus bertambah lewat onUpdate. */
    suspend fun runAll(title: String, cmds: List<String>, onUpdate: (String) -> Unit): String {
        val sb = StringBuilder("── $title ──\n")
        onUpdate(sb.toString())
        for (c in cmds) {
            val o = withContext(Dispatchers.IO) { run(c) }
            sb.append("• ").append(c.take(60)).append("\n")
            if (o.isNotBlank()) sb.append("  ").append(o.take(160)).append("\n")
            onUpdate(sb.toString())
        }
        sb.append("✓ Selesai.\n")
        onUpdate(sb.toString())
        return sb.toString()
    }
}
