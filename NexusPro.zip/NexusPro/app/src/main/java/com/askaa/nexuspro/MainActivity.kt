package com.askaa.nexuspro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor     = 0xFF080F0D.toInt()
        window.navigationBarColor = 0xFF080F0D.toInt()
        setContent { NexusTheme { NexusApp() } }
    }
}

@Composable
fun NexusApp() {
    var tab      by remember { mutableStateOf(0) }
    var selGame  by remember { mutableStateOf<GameInfo?>(null) }
    var shState  by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) { while (true) { shState = Sh.state(); delay(2000) } }

    BackHandler(enabled = selGame != null) { selGame = null }

    Scaffold(
        containerColor = cBG,
        bottomBar = {
            if (selGame == null) {
                NavigationBar(containerColor = Color(0xFF0E1A18), tonalElevation = 0.dp) {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { tab = 0; selGame = null },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = cAcc, selectedTextColor = cAcc,
                            unselectedIconColor = cDim, unselectedTextColor = cDim,
                            indicatorColor = cPill
                        )
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.VideogameAsset, null) }, label = { Text("Gamelist") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = cAcc, selectedTextColor = cAcc,
                            unselectedIconColor = cDim, unselectedTextColor = cDim,
                            indicatorColor = cPill
                        )
                    )
                    NavigationBarItem(
                        selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Advanced") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = cAcc, selectedTextColor = cAcc,
                            unselectedIconColor = cDim, unselectedTextColor = cDim,
                            indicatorColor = cPill
                        )
                    )
                    NavigationBarItem(
                        selected = tab == 3, onClick = { tab = 3 },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = cAcc, selectedTextColor = cAcc,
                            unselectedIconColor = cDim, unselectedTextColor = cDim,
                            indicatorColor = cPill
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val g = selGame
            when {
                g != null    -> GameDetailScreen(g, shState) { selGame = null }
                tab == 0     -> HomeScreen(shState)
                tab == 1     -> GameListScreen(shState) { selGame = it }
                tab == 2     -> AdvancedScreen(shState)
                else         -> SettingsScreen(shState)
            }
        }
    }
}
