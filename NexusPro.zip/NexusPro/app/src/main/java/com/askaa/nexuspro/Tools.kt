package com.askaa.nexuspro

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class ToolItem(val title: String, val icon: ImageVector, val tint: Color = cAcc)

val TOOLS: List<ToolItem> = listOf(
    ToolItem("Clean RAM", Icons.Default.Memory),
    ToolItem("Boost CPU", Icons.Default.Speed),
    ToolItem("Kill Apps", Icons.Default.Cancel, cRed),
    ToolItem("Clear Cache", Icons.Default.CleaningServices),
    ToolItem("Battery Saver", Icons.Default.BatteryChargingFull, cGreen),
    ToolItem("Network", Icons.Default.Wifi),
    ToolItem("Performance", Icons.Default.Bolt, cYellow),
    ToolItem("Touch Boost", Icons.Default.TouchApp),
    ToolItem("Reset", Icons.Default.RestartAlt)
)
