package com.askaa.nexuspro

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

/** cmds(games, isRoot) -> daftar perintah shell yang dijalankan lewat Shizuku */
data class ToolItem(
    val title: String,
    val icon: ImageVector,
    val tint: Color = cAcc,
    val cmds: (List<GameInfo>, Boolean) -> List<String>
)

fun resCmd(pct: Int): String =
    if (pct >= 100) "wm size reset"
    else "s=\$(wm size|grep -oE '[0-9]+x[0-9]+'|head -1);w=\$(echo \$s|cut -dx -f1);h=\$(echo \$s|cut -dx -f2);wm size \$((w*$pct/100))x\$((h*$pct/100))"

val RESET_CMDS = listOf(
    "settings put global window_animation_scale 1.0",
    "settings put global transition_animation_scale 1.0",
    "settings put global animator_duration_scale 1.0",
    "settings put secure long_press_timeout 400",
    "settings put global low_power 0",
    "cmd wifi force-low-latency-mode disabled",
    "cmd power set-fixed-performance-mode-enabled false",
    "wm size reset",
    "settings delete system peak_refresh_rate",
    "settings delete system min_refresh_rate",
    "settings delete system user_refresh_rate"
)

val TOOLS: List<ToolItem> = listOf(
    ToolItem("Clean RAM", Icons.Default.Memory) { _, root ->
        buildList {
            add("am kill-all")
            add("sync")
            if (root) add("echo 3 > /proc/sys/vm/drop_caches")
        }
    },
    ToolItem("Boost CPU", Icons.Default.Speed) { _, root ->
        buildList {
            add("cmd power set-fixed-performance-mode-enabled true")
            if (root) add("for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo performance > \$f; done")
        }
    },
    ToolItem("Kill Apps", Icons.Default.Cancel, cRed) { _, _ ->
        listOf("for x in \$(pm list packages -3|cut -d: -f2); do [ \"\$x\" != \"com.askaa.nexuspro\" ] && am kill \$x; done; echo selesai")
    },
    ToolItem("Clear Cache", Icons.Default.CleaningServices) { _, _ ->
        listOf("pm trim-caches 4096G")
    },
    ToolItem("Battery Saver", Icons.Default.BatteryChargingFull, cGreen) { _, _ ->
        listOf("settings put global low_power 1")
    },
    ToolItem("Network", Icons.Default.Wifi) { _, _ ->
        listOf("cmd wifi force-low-latency-mode enabled")
    },
    ToolItem("Performance", Icons.Default.Bolt, cYellow) { games, _ ->
        buildList {
            addAll(games.map { "cmd game mode performance ${it.pkg}" })
            add("settings put global window_animation_scale 0.5")
            add("settings put global transition_animation_scale 0.5")
            add("settings put global animator_duration_scale 0.5")
        }
    },
    ToolItem("Touch Boost", Icons.Default.TouchApp) { _, _ ->
        listOf("settings put secure long_press_timeout 250", "settings put system pointer_speed 7")
    },
    ToolItem("Reset", Icons.Default.RestartAlt) { games, _ ->
        RESET_CMDS + games.map { "cmd game mode standard ${it.pkg}" }
    }
)
