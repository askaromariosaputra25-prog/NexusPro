package com.askaa.nexuspro

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

data class GameInfo(val pkg: String, val name: String)

private val KNOWN_GAMES = setOf(
    "com.mobile.legends","com.mobilelegends.hwag","com.tencent.ig","com.pubg.imobile",
    "com.dts.freefireth","com.dts.freefiremax","com.miHoYo.GenshinImpact",
    "com.activision.callofduty.shooter","com.garena.game.codm","com.roblox.client",
    "com.levelinfinite.sgameGlobal","com.mojang.minecraftpe","com.ea.game.pvzfree_row",
    "com.kabam.marvelbattle","com.netease.lztgglobal","com.vng.pubgmobile",
    "com.rekoo.pubgm","com.supercell.clashofclans","com.supercell.clashroyale",
    "com.kiloo.subwaysurf","com.imangi.templerun2","com.innersloth.spacemafia"
)

fun loadGames(pm: PackageManager): List<GameInfo> =
    pm.getInstalledApplications(PackageManager.GET_META_DATA)
        .filter { it.packageName in KNOWN_GAMES || it.category == ApplicationInfo.CATEGORY_GAME }
        .map { GameInfo(it.packageName, pm.getApplicationLabel(it).toString()) }
        .sortedBy { it.name }
