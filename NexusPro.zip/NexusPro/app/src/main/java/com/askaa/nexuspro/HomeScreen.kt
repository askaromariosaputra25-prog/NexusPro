package com.askaa.nexuspro

import android.app.ActivityManager
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun HomeScreen(shizukuState: Int, onNavigate: (Int) -> Unit = {}) {
    val ctx = LocalContext.current
    var cpu by remember { mutableStateOf(0) }
    var prevStat by remember { mutableStateOf<LongArray?>(null) }
    var ramUsed by remember { mutableStateOf(0f) }
    var ramTotal by remember { mutableStateOf(0f) }
    var bat by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    var diag by remember { mutableStateOf("") }

    fun testConn() {
        scope.launch {
            diag = "Menguji..."
            val hint = when (shizukuState) {
                0 -> "Shizuku belum aktif. Buka aplikasi Shizuku lalu start servicenya (ADB nirkabel / root), kemudian kembali ke sini."
                1 -> if (Sh.deniedForever()) "Izin ditolak permanen: buka Shizuku → Authorized apps → aktifkan NexusPro."
                     else "Shizuku aktif tapi NexusPro belum diberi izin. Tap Beri izin."
                else -> ""
            }
            val res = if (shizukuState == 2) withContext(Dispatchers.IO) { Sh.run("id; getprop ro.build.version.sdk") } else ""
            diag = buildString {
                append("Shizuku v${Sh.version()} · mode ${Sh.mode()}\n")
                if (res.isNotBlank()) append(res).append("\n")
                if (hint.isNotBlank()) append(hint)
            }.trim()
        }
    }

    fun monitor() {
        if (shizukuState != 2) { testConn(); return }
        scope.launch {
            diag = "Mengambil data..."
            diag = withContext(Dispatchers.IO) { Sh.run("top -b -n 1 -m 8 | head -n 14") }
        }
    }

    LaunchedEffect(shizukuState) {
        prevStat = null
        while (true) {
            val mi = ActivityManager.MemoryInfo()
            ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
            ramTotal = mi.totalMem / 1e9f
            ramUsed  = (mi.totalMem - mi.availMem) / 1e9f
            bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let {
                it.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 /
                    maxOf(1, it.getIntExtra(BatteryManager.EXTRA_SCALE, 100))
            } ?: 0
            if (shizukuState == 2) {
                val line = withContext(Dispatchers.IO) { Sh.run("head -1 /proc/stat") }
                val n = line.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                if (n.size >= 5) {
                    val tot = n.sum(); val idle = n[3] + n[4]
                    prevStat?.let { p ->
                        val dt = tot - p[0]; val di = idle - p[1]
                        if (dt > 0) cpu = ((100 * (dt - di)) / dt).toInt().coerceIn(0, 100)
                    }
                    prevStat = longArrayOf(tot, idle)
                }
            }
            delay(2000)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp).padding(bottom = 16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("NexusPro", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = cWhite)
            Spacer(Modifier.weight(1f))
            Box(Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFF1A3A2A))
                .padding(horizontal = 10.dp, vertical = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dot(cGreen); Spacer(Modifier.width(5.dp))
                    Text("Alive", color = cGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.Cancel, null, tint = cDim, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.MoreVert, null, tint = cDim, modifier = Modifier.size(22.dp))
        }

        // Banner
        Box(
            Modifier.fillMaxWidth().height(140.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF0D2A26), Color(0xFF1A4A44), Color(0xFF0A1E1C))))
        ) {
            Text("NexusPro", fontSize = 36.sp, fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.08f), modifier = Modifier.align(Alignment.Center))
            Text("NEXUSPRO", fontSize = 11.sp, letterSpacing = 4.sp, color = cAcc.copy(0.5f),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp))
        }

        Spacer(Modifier.height(10.dp))

        // System Health
        NxCard {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 6.dp)) {
                Icon(Icons.Default.MonitorHeart, null, tint = cAcc, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("System Health", color = cAcc, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.sp)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ChevronRight, null, tint = cDim, modifier = Modifier.size(18.dp))
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                CpuGauge(cpu, Modifier.size(100.dp))
                Spacer(Modifier.width(16.dp))
                Column {
                    val cpuLabel = when { cpu < 30 -> "Low" to cGreen; cpu < 70 -> "Medium" to cYellow; else -> "High" to cRed }
                    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(cpuLabel.second.copy(0.2f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)) {
                        Text(cpuLabel.first, color = cpuLabel.second, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("CPU", color = cDim, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Little Core", color = cDim, fontSize = 11.sp)
                    LinearProgressIndicator(
                        progress = { cpu / 100f },
                        modifier = Modifier.fillMaxWidth(0.7f).height(4.dp).clip(RoundedCornerShape(2.dp)),
                        color = cAcc, trackColor = cPill
                    )
                    Spacer(Modifier.height(4.dp))
                    Text("Big Core", color = cDim, fontSize = 11.sp)
                    LinearProgressIndicator(
                        progress = { (cpu * 0.85f) / 100f },
                        modifier = Modifier.fillMaxWidth(0.7f).height(4.dp).clip(RoundedCornerShape(2.dp)),
                        color = cYellow, trackColor = cPill
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = cPill)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                MiniStat(Icons.Default.PhoneAndroid, Build.MODEL.take(9))
                MiniStat(Icons.Default.Android, Build.VERSION.RELEASE)
                MiniStat(Icons.Default.Memory, "%.1fGB".format(ramUsed))
                MiniStat(Icons.Default.BatteryFull, "$bat%")
            }
        }

        // Shortcuts
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ShortcutCard("App Profiles", "Set custom performance per app", Icons.Default.Tune, Modifier.weight(1f)) { onNavigate(1) }
            ShortcutCard("System Monitor", "CPU · GPU · RAM · Storage", Icons.Default.BarChart, Modifier.weight(1f)) { monitor() }
        }

        // Connection Status
        NxCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Link, null, tint = cDim, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Connection Status", color = cWhite, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                        Dot(if (shizukuState == 2) cGreen else cRed)
                        Spacer(Modifier.width(5.dp))
                        Text(
                            if (shizukuState == 2) "Shizuku" else if (shizukuState == 1) "Izin diperlukan" else "Shizuku tidak aktif",
                            color = if (shizukuState == 2) cGreen else cRed, fontSize = 12.sp
                        )
                    }
                }
                if (shizukuState == 1) {
                    TextButton({ Sh.request() }) { Text("Beri izin", color = cAcc, fontSize = 12.sp) }
                }
                TextButton({ testConn() }) { Text("Tes", color = cAcc, fontSize = 12.sp) }
            }
            if (diag.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(diag, color = cDim, fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
            }
        }

        // Exclusive
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
            Icon(Icons.Default.Star, null, tint = cAcc, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(5.dp))
            Text("EXCLUSIVE", color = cAcc, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = cCard),
            shape = RoundedCornerShape(14.dp)
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, null, tint = cDim, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Exclusive Features", color = cWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("Backup, Import & Color Presets", color = cDim, fontSize = 11.sp)
                    Text("5/9 videos for 1-day access", color = cDim, fontSize = 10.sp)
                }
                Spacer(Modifier.width(8.dp))
                Box(Modifier.clip(RoundedCornerShape(6.dp)).background(cAcc).padding(horizontal = 10.dp, vertical = 5.dp)) {
                    Text("FREE", color = Color(0xFF00201E), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun CpuGauge(pct: Int, modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        val sweep = pct * 2.7f
        Canvas(Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 10f, cap = StrokeCap.Round)
            drawArc(cPill, 135f, 270f, false, style = stroke)
            if (pct > 0) drawArc(cAcc, 135f, sweep, false, style = stroke)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$pct%", color = cWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            if (pct == 0) Text("Detecting...", color = cDim, fontSize = 9.sp)
        }
    }
}

@Composable
fun MiniStat(icon: ImageVector, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = cAcc, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(3.dp))
        Text(value, color = cDim, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
fun ShortcutCard(title: String, desc: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    Card(modifier.clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = cCard), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = cAcc, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(4.dp))
            Text(title, color = cWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = cDim, fontSize = 11.sp, lineHeight = 14.sp)
            Spacer(Modifier.height(4.dp))
            Icon(Icons.Default.ChevronRight, null, tint = cDim, modifier = Modifier.size(16.dp))
        }
    }
}
