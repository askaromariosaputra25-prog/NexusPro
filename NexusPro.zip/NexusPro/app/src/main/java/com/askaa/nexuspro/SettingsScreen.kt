package com.askaa.nexuspro

import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(shizukuState: Int, email: String, onLogout: () -> Unit) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("") }
    var showRes by remember { mutableStateOf(false) }
    var showTerm by remember { mutableStateOf(false) }
    var showLogout by remember { mutableStateOf(false) }
    var resPct by remember { mutableStateOf(100) }
    var termCmd by remember { mutableStateOf("id") }
    var termOut by remember { mutableStateOf("") }

    fun runCmds(title: String, cmds: List<String>) {
        if (shizukuState != 2) { status = "Shizuku belum aktif / belum diizinkan. Buka tab Home → Connection Status → Tes."; return }
        scope.launch { Sh.runAll(title, cmds) { status = it } }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp).padding(bottom = 80.dp)
    ) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = cWhite,
            modifier = Modifier.padding(top = 16.dp, bottom = 16.dp))

        // Akun Google
        NxCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, null, tint = cAcc, modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Akun Google", color = cWhite, fontWeight = FontWeight.Bold)
                    Text(email, color = cDim, fontSize = 12.sp)
                }
                TextButton({ showLogout = true }) { Text("Keluar", color = cRed) }
            }
        }

        // Status Shizuku
        SettingRow(
            Icons.Default.Link,
            "Connection Status",
            when (shizukuState) {
                2 -> "● Shizuku terhubung · mode ${Sh.mode()}"
                1 -> "● Shizuku aktif, tap untuk beri izin"
                else -> "● Shizuku tidak aktif"
            },
            tint = if (shizukuState == 2) cGreen else cRed
        ) { if (shizukuState == 1) Sh.request() }

        SettingRow(Icons.Default.Terminal, "Terminal", "Jalankan perintah shell lewat Shizuku") { showTerm = true }
        SettingRow(Icons.Default.ScreenRotation, "Display Resolution", "Ubah resolusi layar (Shizuku)") { showRes = true }

        Spacer(Modifier.height(8.dp))
        Card(
            Modifier.fillMaxWidth().clickable { runCmds("Reset All Settings", RESET_CMDS) },
            colors = CardDefaults.cardColors(containerColor = cRed.copy(0.15f)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Refresh, null, tint = cRed, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Reset All Settings", color = cRed, fontWeight = FontWeight.Bold)
                    Text("Kembalikan animasi, resolusi, refresh rate ke default", color = cRed.copy(0.7f), fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = cRed)
            }
        }

        if (status.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            NxCard { Text(status, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = cDim) }
        }

        Spacer(Modifier.height(12.dp))
        NxCard {
            StatRow("Android", Build.VERSION.RELEASE)
            StatRow("Security Patch Level", Build.VERSION.SECURITY_PATCH)
            StatRow("Perangkat", Build.MODEL)
            StatRow("Shizuku", if (shizukuState == 2) "v${Sh.version()} · ${Sh.mode()}" else "tidak terhubung")
            StatRow("App Version", "1.0.0")
        }
    }

    if (showRes) {
        AlertDialog(
            onDismissRequest = { showRes = false },
            containerColor = cCard,
            title = { Text("Display Resolution", color = cWhite) },
            text = {
                Column {
                    Text("Skala resolusi: $resPct%", color = cDim, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(100, 90, 80, 70).forEach { v -> Pill("$v%", resPct == v) { resPct = v } }
                    }
                }
            },
            confirmButton = {
                TextButton({ showRes = false; runCmds("Resolusi $resPct%", listOf(resCmd(resPct))) }) {
                    Text("Terapkan", color = cAcc)
                }
            },
            dismissButton = { TextButton({ showRes = false }) { Text("Batal", color = cDim) } }
        )
    }

    if (showTerm) {
        AlertDialog(
            onDismissRequest = { showTerm = false },
            containerColor = cCard,
            title = { Text("Terminal (Shizuku)", color = cWhite) },
            text = {
                Column {
                    OutlinedTextField(
                        termCmd, { termCmd = it }, Modifier.fillMaxWidth(), singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = cAcc, unfocusedBorderColor = cPill,
                            focusedTextColor = cWhite, unfocusedTextColor = cWhite, cursorColor = cAcc
                        )
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(termOut, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = cDim,
                        modifier = Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState()))
                }
            },
            confirmButton = {
                TextButton({
                    if (shizukuState != 2) {
                        termOut = "Shizuku belum aktif / belum diizinkan."
                    } else {
                        scope.launch {
                            termOut = "..."
                            termOut = withContext(Dispatchers.IO) { Sh.run(termCmd) }.ifBlank { "(tanpa output)" }
                        }
                    }
                }) { Text("Jalankan", color = cAcc) }
            },
            dismissButton = { TextButton({ showTerm = false }) { Text("Tutup", color = cDim) } }
        )
    }

    if (showLogout) {
        AlertDialog(
            onDismissRequest = { showLogout = false },
            containerColor = cCard,
            title = { Text("Keluar dari akun?", color = cWhite) },
            text = { Text("Kamu perlu login Google lagi untuk memakai NexusPro.", color = cDim) },
            confirmButton = { TextButton({ showLogout = false; onLogout() }) { Text("Keluar", color = cRed) } },
            dismissButton = { TextButton({ showLogout = false }) { Text("Batal", color = cDim) } }
        )
    }
}

@Composable
fun SettingRow(icon: ImageVector, title: String, subtitle: String, tint: Color = cAcc, onClick: () -> Unit = {}) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = cCard),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = cWhite, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(subtitle, color = cDim, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = cDim)
        }
    }
}
