package com.askaa.nexuspro

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(shizukuState: Int) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp).padding(bottom = 80.dp)
    ) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = cWhite,
            modifier = Modifier.padding(top = 16.dp, bottom = 16.dp))

        // Account
        NxCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, null, tint = cAcc, modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("NexusPro User", color = cWhite, fontWeight = FontWeight.Bold)
                    Text("user@nexuspro.app", color = cDim, fontSize = 12.sp)
                }
            }
        }

        // Language
        SettingRow(Icons.Default.Language, "Language / Bahasa", "English  |  English")

        // Shizuku status
        SettingRow(
            Icons.Default.Link,
            "Connection Status",
            if (shizukuState == 2) "● Shizuku Connected" else "● Shizuku Inactive",
            tint = if (shizukuState == 2) cGreen else cRed
        ) { if (shizukuState == 1) Sh.request() }

        // Extras
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = cCard), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.MonetizationOn, null, tint = cYellow, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.height(6.dp))
                    Text("Coin", color = cWhite, fontWeight = FontWeight.Bold)
                    Text("Coin Store", color = cDim, fontSize = 11.sp)
                }
            }
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = cCard), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Terminal, null, tint = cAcc, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.height(6.dp))
                    Text("Terminal", color = cWhite, fontWeight = FontWeight.Bold)
                    Text("⚡ shizuku", color = cDim, fontSize = 11.sp)
                }
            }
        }

        SettingRow(Icons.Default.ScreenRotation, "Display Resolution", "Change display resolution (root/shizuku)")
        SettingRow(Icons.Default.Palette, "Color Calibration", "Tap to see all options")

        Spacer(Modifier.height(8.dp))
        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = cRed.copy(0.15f)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Refresh, null, tint = cRed, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Reset All Settings", color = cRed, fontWeight = FontWeight.Bold)
                    Text("Restore to default", color = cRed.copy(0.7f), fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = cRed)
            }
        }

        Spacer(Modifier.height(8.dp))
        SettingRow(Icons.Default.Security, "App Security", "NexusPro Security Patch Info")

        // Build info
        Spacer(Modifier.height(12.dp))
        NxCard {
            StatRow("Security Patch Level", "2026-09-02")
            StatRow("App Version",          "1.0.0")
            StatRow("Build Type",           "Release")
            StatRow("Min Android",          "Android 10")
            StatRow("Target Android",       "Android 14")
        }

        // Support
        Spacer(Modifier.height(8.dp))
        SectionLabel("SUPPORT")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                Triple(Icons.Default.Favorite, "Donate", cRed),
                Triple(Icons.Default.Send, "Telegram", cAcc),
                Triple(Icons.Default.BugReport, "Report Bug", cYellow),
                Triple(Icons.Default.Info, "Credits", cDim)
            ).forEach { (ic, lbl, cl) ->
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = cCard), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(ic, null, tint = cl, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.height(4.dp))
                        Text(lbl, color = cDim, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingRow(icon: ImageVector, title: String, subtitle: String, tint: Color = cAcc, onClick: () -> Unit = {}) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = cCard),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = cWhite, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(subtitle, color = cDim, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = cDim)
        }
    }
}
