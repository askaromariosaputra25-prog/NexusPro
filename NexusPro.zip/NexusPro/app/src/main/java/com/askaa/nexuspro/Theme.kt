package com.askaa.nexuspro

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val cBG     = Color(0xFF080F0D)
val cCard   = Color(0xFF111C19)
val cCard2  = Color(0xFF162220)
val cAcc    = Color(0xFF86D9D3)
val cAccDim = Color(0xFF3D8C88)
val cDim    = Color(0xFF7A9E9A)
val cPill   = Color(0xFF1E3330)
val cRed    = Color(0xFF8C3A42)
val cGreen  = Color(0xFF2ECC71)
val cYellow = Color(0xFFF0A500)
val cWhite  = Color(0xFFE8F1EF)

@Composable
fun NexusTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary         = cAcc,
            onPrimary       = Color(0xFF00201E),
            background      = cBG,
            onBackground    = cWhite,
            surface         = cCard,
            onSurface       = cWhite,
            surfaceVariant  = cCard2,
            onSurfaceVariant= cDim,
            secondary       = cAccDim,
            secondaryContainer = cPill,
        ),
        content = content
    )
}
