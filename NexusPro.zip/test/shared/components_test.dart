import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:nexuspro_optimization/core/theme/app_theme.dart';
import 'package:nexuspro_optimization/core/theme/tokens/app_sizes.dart';
import 'package:nexuspro_optimization/shared/widgets/shared_widgets.dart';

Widget _wrap(Widget child) {
  return MaterialApp(
    theme: AppTheme.light,
    darkTheme: AppTheme.dark,
    home: Scaffold(body: Center(child: child)),
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  GoogleFonts.config.allowRuntimeFetching = false;

  group('NexusPro Design System - Component Tests', () {
    testWidgets('NexusProStatusBadge renders with label and semantics', (tester) async {
      await tester.pumpWidget(
        _wrap(const NexusProStatusBadge(type: NexusProStatusType.safe)),
      );

      expect(find.text('Safe'), findsOneWidget);
      expect(find.byType(NexusProStatusBadge), findsOneWidget);
    });

    testWidgets('NexusProStatusBadge renders Shizuku tier badge', (tester) async {
      await tester.pumpWidget(
        _wrap(const NexusProStatusBadge(type: NexusProStatusType.shizuku)),
      );

      expect(find.text('Shizuku'), findsOneWidget);
    });

    testWidgets('NexusProActionButton meets minimum touch target and handles tap', (tester) async {
      bool tapped = false;
      await tester.pumpWidget(
        _wrap(
          NexusProActionButton(
            label: 'Optimize Memory',
            onPressed: () => tapped = true,
          ),
        ),
      );

      final buttonFinder = find.byType(NexusProActionButton);
      expect(buttonFinder, findsOneWidget);

      final size = tester.getSize(buttonFinder);
      expect(size.height, greaterThanOrEqualTo(AppSizes.minTouchTarget));

      await tester.tap(buttonFinder);
      await tester.pump();
      expect(tapped, isTrue);
    });

    testWidgets('NexusProSecondaryButton handles tap and displays label', (tester) async {
      bool tapped = false;
      await tester.pumpWidget(
        _wrap(
          NexusProSecondaryButton(
            label: 'Cancel',
            onPressed: () => tapped = true,
          ),
        ),
      );

      expect(find.text('Cancel'), findsOneWidget);
      await tester.tap(find.byType(NexusProSecondaryButton));
      await tester.pump();
      expect(tapped, isTrue);
    });

    testWidgets('NexusProMetricCard renders value, label, and status badge', (tester) async {
      await tester.pumpWidget(
        _wrap(
          const NexusProMetricCard(
            label: 'RAM Available',
            value: '3.8',
            unit: 'GB',
            statusType: NexusProStatusType.optimal,
          ),
        ),
      );

      expect(find.text('RAM Available'), findsOneWidget);
      expect(find.text('3.8'), findsOneWidget);
      expect(find.text('GB'), findsOneWidget);
      expect(find.text('Optimal'), findsOneWidget);
    });

    testWidgets('NexusProGameCard renders title, package name, and status', (tester) async {
      await tester.pumpWidget(
        _wrap(
          const NexusProGameCard(
            title: 'Genshin Impact',
            packageName: 'com.miHoYo.GenshinImpact',
            statusLabel: 'Safe Profile',
          ),
        ),
      );

      expect(find.text('Genshin Impact'), findsOneWidget);
      expect(find.text('com.miHoYo.GenshinImpact'), findsOneWidget);
      expect(find.text('Safe Profile'), findsOneWidget);
    });

    testWidgets('NexusProSettingsSwitchTile toggles value on tap', (tester) async {
      bool currentVal = false;
      await tester.pumpWidget(
        StatefulBuilder(
          builder: (context, setState) {
            return _wrap(
              NexusProSettingsSwitchTile(
                title: 'Do Not Disturb',
                value: currentVal,
                onChanged: (newVal) => setState(() => currentVal = newVal),
              ),
            );
          },
        ),
      );

      expect(find.text('Do Not Disturb'), findsOneWidget);
      final switchFinder = find.byType(Switch);
      expect(switchFinder, findsOneWidget);

      await tester.tap(find.byType(NexusProSettingsSwitchTile));
      await tester.pump();
      expect(currentVal, isTrue);
    });
  });
}
